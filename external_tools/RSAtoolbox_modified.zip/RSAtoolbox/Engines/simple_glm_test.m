function corrvals = simple_glm_test(data,models,mask,userOptions)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

mask_ind = find(mask>0);
good_data = data(mask_ind,:);

nModelRDMs = length(models);

classlabels = cell(1,nModelRDMs);
classlabels_id = cell(1,nModelRDMs);
for i=1:length(models)
    classlabels{i}=models(i).label; 
    classlabels_id{i}=zeros(1,length(classlabels{i}));
    for j=1:length(classlabels{i})
        if strcmp('key',classlabels{i}{j})
            classlabels_id{i}(j) = 1;            
        end
    end
end

good_data=good_data';
classlabels_id{i}=classlabels_id{i}';

for i=1:length(models)
    corrvals{i} = atanh(corr(good_data,classlabels_id{i},'rows', 'pairwise'));
end

end

