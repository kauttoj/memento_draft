function [accuracy,results] = RDM_kNN_classifier(corMat,all_K,groups)

%Simple kNN-classification for ISC matrices.
%--------------------------------------------------------------------------
%
%Inputs:
%corMat     Brain volumes of the upper triangle entries of corr matrices
%Ks         The k-values to be used
%groups     Number of groups or vector giving vector IDs
%
%V.1e-420
%17.1.2014 Juha Lahnakoski
if sum(diag(corMat))>0
    corMat=-corMat+1;
end   

x=length(corMat);
N=(.5+sqrt(.5^2+x*2));
N_k=length(all_K);
results=zeros(1,N);
tempmat = triu(true(N),1);
for sub=1:N
    %fprintf('Classifying subject %i...',sub);
    subs=(1:N)';
    subs(sub)=[];
    grps=groups;
    grps(sub)=[];
    mask=false(N);
    mask(sub,:)=true;
    mask(:,sub)=true;       
    [~,idx]=sort(corMat(mask(tempmat)),'descend');       
    for k=1:N_k
        results(sub)=results(sub) + mode(grps(idx(1:all_K(k))))==groups(sub);
    end
    results(sub)=results(sub)/N_k;
end;
accuracy=mean(sum(results,2))/N;
end