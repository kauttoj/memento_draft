function outfile = bramila_despike(infile)

if ~isunix()
	error('3dDespike only supports linux');
end

outfile=['afnidespiked_',infile];
str = ['~/tools/bin/3dDespike -NEW -cut 3.0 4.5 -nomask -prefix afnidespiked ',infile];
disp(['Command: ',str]);
fprintf('..running 3dDespike...');
unix(['chmod +x 3dDespike']);
[status,cmdout] = unix(str);
if status~=0
    fprintf('failed!\n');
    disp(cmdout)
    error('AFNI 3dDeskipe failed to run')
else
    fprintf('done!\n');
end

end

