function [out,pval]=bramila_mantel_vector(data,model,iter,type,nworker,use_full_matrix)
% [out pval]=bramila_mantel(data,model,iter,type)

% data = time/item x voxel/subject
% model = item/time x 1
if nargin<6
    use_full_matrix=0;
end

if strcmp(type,'spearman')==0 && strcmp(type,'pearson')==0
    error('types allowed are only pearson and spearman');
end
if(iter<=0)
    warning('setting permutations to 1e5');
    iter=1e5;
end

N_voxels = size(data,2);
if size(data,1)~=size(model,1)
    error('bad model size!')
end

if nnz(isnan(data))>0
    error('Data has NaN''s!!!')
end

if nnz(isnan(model))>0
    error('Model has NaN''s!!!')
end

if max(model)>1 || min(model)<0 || length(unique(model))==1
    error('Model matrix is invalid (must be between [0,1] with nonzero variance)')
end

if use_full_matrix==1
    N_elem = (4*length(model) + 1)^(1/2)/2 + 1/2;
else
    N_elem = (1+sqrt(1+8*length(model)))/2;
end

if round(N_elem)~=N_elem
    error('Data has no proper matrix representation (bad dimension)')
end

if use_full_matrix==1
    if N_elem*(N_elem-1)~=length(model)
        error('!!')
    end
    fprintf('Bramila Mantel input: input data has %i samples with %i variables, model matrix is %ix%i (->%i)\n',N_voxels,size(data,1),N_elem,N_elem,N_elem*(N_elem-1));

else
    if N_elem*(N_elem-1)/2~=length(model)
        error('!!')
    end
    fprintf('Bramila Mantel input: input data has %i samples with %i variables, model matrix is %ix%i (->%i)\n',N_voxels,size(data,1),N_elem,N_elem,N_elem*(N_elem-1)/2);
end


if use_full_matrix==1
    mat_ind = find(ones(N_elem,N_elem)-eye(N_elem));
    model_mat = zeros(N_elem,N_elem);
    model_mat(mat_ind)=model;
    if nnz(model_mat(mat_ind)-model)>0
        error('!!!')
    end
else
    mat_ind = find(triu(ones(N_elem,N_elem),1));
    model_mat = zeros(N_elem,N_elem);
    model_mat(mat_ind)=model;
    model_mat = model_mat+model_mat';
    if nnz(model_mat(mat_ind)-model)>0
        error('!!!')
    end
end

out = corr(data,model,'type',type);

%create local cluster
try
    myCluster = gcp('nocreate');
    if isempty(myCluster)
        %delete(gcp)
        myCluster = parcluster('local');
        if nargin>4 && ~isempty(nworker)
            myCluster.NumWorkers=nworker;
        end
        parpool(myCluster);
    end
    N_workers = myCluster.NumWorkers;
catch err % old matlab?
    if ~matlabpool('size')
        if nargin>4 && ~isempty(nworker)
            eval(['matlabpool local ',num2str(nworker)]);
        else
            matlabpool local
        end
    end
    N_workers = matlabpool('size');
end

tic;
fprintf('\nStarting Mantel-test permutations (total %i)\n',iter);
surro=nan(1,iter);
voxel = randsample(N_voxels,iter,true);
parfor i=1:iter
    pe=randperm(N_elem);
    temp=model_mat(pe,pe);
    %surro(:,i)=fast_spearman(xrank(:,vox),xadj(vox),ties,temp(mat_ind));
    surro(i) = corr(data(:,voxel(i)),temp(mat_ind),'type',type);
end
a=toc;
fprintf('Finished permutations (%.1fs)!\n',a);

if nnz(isnan(surro))>0
    error('Permutation distribution has NaN''s (check your data)!!!')
end

tic
fprintf('Computing empirical p-values (positive-tail)...\n')
pval = nan(size(out));
parfor i=1:N_voxels
    pval(i)=nnz(surro>out(i));
end
pval = pval/iter;
a=toc;
fprintf('All done (%.1fs)!\n',a)

end
% 
% function coef = fast_spearman(xrank,xadj,ties,y)
% 
% [n,p1] = size(xrank);
% [yrank, yadj] = tiedrank(y,0);
% ties = ties || any(yadj>0);
% n3const = (n+1)*n*(n-1) ./ 3;
% if ~ties
%     coef = corrPearson(xrank,yrank);
% else
%     coef = zeros(p1,1);
%     for i = 1:p1
%         xranki = xrank(:,i);
%         yrankj = yrank;
%         yadjj = yadj;
%         D = sum(bsxfun(@minus,xranki,yrankj).^2); % sum((xranki - yrankj).^2);
%         meanD = (n3const - (xadj(i)+yadjj)./3) ./ 2;
%         stdD = sqrt((n3const./2 - xadj(i)./3)*(n3const./2 - yadjj./3)./(n-1));
%         
%         % When either of the data vectors is constant, stdD should be
%         % zero, get that exactly.
%         n3const2 = (n+1)*n*(n-1)/2;
%         stdD((xadj(i) == n3const2) | (yadjj == n3const2)) = 0;
%         
%         coef(i) = (meanD - D) ./ (sqrt(n-1)*stdD);
%     end
%     % Limit off-diag correlations to [-1,1].
%     t = find(abs(coef) > 1); coef(t) = coef(t)./abs(coef(t)); % preserves NaNs
% end
%     
% end
% 
% function coef = corrPearson(x,y)
% %CORRPEARSON Computation of Pearson correlation matrix
% [n,p1] = size(x);
% % Computation of linear correlation with column-pairwise NaN removal
% xc = bsxfun(@minus,x,sum(x,1)/n);  % Remove mean
% yc = bsxfun(@minus,y,sum(y,1)/n);  % Remove mean
% coef = xc' * yc; % 1/(n-1) doesn't matter, renormalizing anyway
% dx = sqrt(sum(abs(xc).^2, 1)); % sqrt first to avoid under/overflow
% dy = sqrt(sum(abs(yc).^2, 1)); % sqrt first to avoid under/overflow
% coef = bsxfun(@rdivide,coef,dx'); coef = bsxfun(@rdivide,coef,dy); % coef = coef ./ dx'*dy;
% % Limit off-diag elements to [-1,1], and put exact ones on the diagonal for
% % autocorrelation.
% t = find(abs(coef) > 1);
% coef(t) = coef(t)./abs(coef(t)); % preserves NaNs
% 
% end
% 
% 
