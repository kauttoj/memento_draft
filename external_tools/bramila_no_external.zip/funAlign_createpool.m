function funAlign_createpool( CPUs )
%FUNALIGN_CREATEPOOL Summary of this function goes here
%   Detailed explanation goes here

    try
        myCluster = gcp('nocreate');
        if isempty(myCluster)
            %delete(gcp)
            myCluster = parcluster('local');
            if CPUs<inf                
                myCluster.NumWorkers=CPUs;
            end
            parpool(myCluster);
        end
        N_workers = myCluster.NumWorkers;
    catch err % old matlab?
        if ~matlabpool('size')
            if CPUs<inf
                eval(['matlabpool local ',num2str(CPUs)]);
            else
                eval(['matlabpool local']);
            end
        end
        N_workers = matlabpool('size');
    end
    if CPUs<inf && N_workers<CPUs
        warning('Number of workers is less than requested')
    end
    
end

