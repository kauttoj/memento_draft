function rois = bramila_mask2roi(masks,masks_label_in)
%BRAMILA_MASK2ROI Summary of this function goes here
%   Detailed explanation goes here

vals = unique(masks(:));
vals(vals==0 | isnan(vals))=[];
if isempty(vals)
    error('Mask has no non-zero/nan values')
end

N=length(vals);
M = nnz(masks~=0 & ~isnan(masks));
fprintf('Number of voxels %i, number of ROIs %i\n',M,N);
if N>M/2
    warning('Number of ROIs is huge!')
end
vals=sort(vals,'ascend');


if nargin==2
    if ~iscell(masks_label_in)       
        masks_label{1}=masks_label_in;
    else
        masks_label=masks_label_in;
    end
    if length(masks_label)~=N
       error('Number of masks and their labels is inconsistent!') 
    end
    for i=1:N
        if ~ischar(masks_label{i})
           error('mask labels must be string!') 
        end
    end    
    NO_LABEL=0;
else
    masks_label=cell(N);
    for i=1:N
        masks_label{i}='';
    end   
    NO_LABEL = 1;
end

siz=size(masks);

fprintf('Creating rois\n')
for i=1:N
    
    a=(masks==vals(i));
    [x, y, z] = ind2sub(siz,find(a));
    rois(i).map = [x,y,z];
    rois(i).centroid=round(mean(rois(i).map,1));
    rois(i).centroidMNI = ind2mni(rois(i).centroid);
    rois(i).ID = vals(i);
    
    if NO_LABEL==1
        [~,b] = findClusterLabels_total(a,1,1,1);
        rois(i).label=b{1};
    else
        rois(i).label = masks_label{i};
    end
    
    fprintf('...ROI %i: %i voxels (%s)\n',i,length(x),rois(i).label);
end
fprintf('done!\n');

end

