function pval = bramila_test_group_motion(cfg,iterations,corrtype)
%BRAMILA_TEST_TISSUE_ISC Summary of this function goes here
% %   Detailed explanation goes here

L=length(cfg);
[total_X{1},total_subjID,total_typeID] = get_total_design(cfg,1);
[total_X{2}] = get_total_design(cfg,2);
[total_X{3}] = get_total_design(cfg,3);

for i=1:3
    total_X{i} = zscore(total_X{i}); % removes the need for a constant term!
end

for type = 1:3
    T=size(total_X{type},1);
    
    [count,val]=hist(total_typeID,unique(total_typeID));
    [~,i]=max(count);
    M=rank(total_X{type}(:,total_typeID==val(i)));
    
    if nargin<3
        if T/M<2
            corrtype = 2;
        else
            corrtype = 1;
        end
    end
    
    if corrtype == 2
        fprintf('\nTesting multivariate ISC (pair-wise)\n');
    elseif corrtype == 1
        fprintf('\nTesting multivariate ISC (full design) \n');
    else
        corrtype
        error('Correlation type must be 1 (full) or 2 (pair-wise)');
    end
    
    shifts = randi(T,iterations,L,'uint16');
    shifts(end+1,1:L) = ones(1,L,'uint16');
    
    printint=round(linspace(iterations/10,iterations*9/10,9));
    
    
    pval=nan(1,3);
    
    
    XXX = total_X{type};
    subj_id = total_subjID;
    dist=nan(1,iterations+1);
    kk=1;
    if size(XXX,2)>0
        
        for iter=1:(iterations+1)
            
            if kk<10 && printint(kk)==iter
                fprintf('%2.0f%% ',100*iter/iterations);
                kk=kk+1;
            end
            
            XX = subjectwise_shift(XXX,L,subj_id,shifts(iter,:));
            
            %var_perc = zeros(1,L-1);
            k=0;
            for i=1:L
                Y=XX(:,subj_id==i);
                
                if corrtype==2
                    
                    for j=1:L
                        if i~=j
                            X=XX(:,subj_id==j);
                            if size(X,2)>0 && size(Y,2)>0
                                var_exp = 100*compute_variance(X,Y);
                                k=k+1;
                                var_perc(k)=var_exp;
                            end
                        end
                    end
                    
                else
                    
                    X=XX(:,subj_id~=i);
                    if size(X,2)>0 && size(Y,2)>0
                        var_exp = 100*compute_variance(X,Y);
                        k=k+1;
                        var_perc(k)=var_exp;
                    end
                    
                end
                
            end
            
            dist(iter)=mean(var_perc);
            
        end
        
        if nnz(isnan(dist))>0
            warning('Distribution has NaN values!');
        end
        
    end
    
    pval(type)=nnz(dist(iterations+1)<dist(1:iterations))/iterations;
    fprintf('100%% (pval=%3.2f)\n',pval(type));
    
    
end

pval(pval==0)=1/(iterations+1);

end

function XX = subjectwise_shift(XX,L,subj_id,shifts)

for i=1:L
    ind = (subj_id==i);
    XX(:,ind) = XX([shifts(i):end,1:(shifts(i)-1)],ind);
end

end

function var = compute_variance(X,Y)

beta = X \ Y;
var = sum(sum(abs(X*beta).^2,1))./ sum(sum(abs(Y).^2,1));

end

function [total_X,subj_id,type_id] = get_total_design(reg_cfg,type)

total_X = [];
subj_id =[];
type_id =[];

for subj = 1:length(reg_cfg)
    
    mot = load(reg_cfg{subj}.motionparam);
    
    temp_cfg.detrend_type='linear-nodemean'; % must be the same as applied to BOLD data
    temp_cfg.write=0;
    temp_cfg.vol=mot;
    mot = bramila_detrend(temp_cfg);
    if type==2
        mot=mot.^2;
    elseif type==3
        mot=bramila_derivative(mot,1);
    end
    
    id = 1:size(mot,2);
    total_X = cat(2,total_X,mot);
    subj_id = cat(2,subj_id,subj*ones(1,size(mot,2)));
    type_id = cat(2,type_id,id);
end

end

function res = num2cellstr(data)

res = [];

for i=1:length(data)
    res{i}=num2str(data(i));
end

end
