function res = link_communities_orig( mat )
%LINK_COMMUNITIES_ORIG Summary of this function goes here
%   Detailed explanation goes here

if nnz(mat-mat')>0
   error('!!!') 
end

mat=triu(mat,1);
siz = size(mat);

ind = find(mat);

isweighted=0; 
if length(unique(mat(ind)))>1
   isweighted=1; 
end

filename = ['TEMPFILE',num2str(randi(1000000))];

fid = fopen([filename,'.dat'],'w+');

for i=1:length(ind)
    [x,y]=ind2sub(siz,ind(i));
    if isweighted==1
        fprintf(fid,'%i\t%i\t%f\n',x,y,mat(x,y));
    else
        fprintf(fid,'%i\t%i\n',x,y);
    end
end

fclose(fid);

programpath=pwd;
[a,b]=system('python -h');
if a~=0
    p = fileparts(which('python.exe'));
    if isempty(p)
        error('could not find Python');
    end
    programpath = p;
end

fprintf('Running link_clustering.py...\n'); 

if isweighted==1
   [a,b]=system([programpath,filesep,'python link_clustering.py -w ',filename,'.dat']);
else
   [a,b]=system([programpath,filesep,'python link_clustering.py ',filename,'.dat']);
end

if a~=0
    error('Failed to run with error: %s',b);
else
   fprintf('Success! Parsing resultfiles.\n');
end

files=dir(['*',filename,'*']);

for i=1:length(files)
   if ~isempty(strfind(files(i).name,'comm2nodes'))
       comm_node = readfile([pwd,filesep,files(i).name],1);
   %elseif ~isempty(strfind(files(i).name,'comm2edges'))
   %comm_edge = readfile([pwd,filesep,files(i).name],3);       
   elseif ~isempty(strfind(files(i).name,'edge2comm'))
       edge_comm = readfile([pwd,filesep,files(i).name],2);  
   elseif ~isempty(strfind(files(i).name,'thr_D'))       
       threshold = readfile([pwd,filesep,files(i).name],2);
   else       
   end       
   
end

comm_size = nan(1,length(comm_node));
for i=1:length(comm_node)
   comm_size(i)=length(comm_node{i});
end

c=nan(1,length(comm_node));
for i=1:length(comm_node)
    c(comm_node{i})=i;
end
comm_node=c;

res.comm_node=comm_node;
res.N_comms = length(comm_node);
res.N_edges = size(edge_comm,1);
res.comm_size = comm_size;
%res.comm_edge=comm_edge;
res.edge_comm=edge_comm;
res.threshold=threshold;
res.fileID = filename;

fprintf('ALL DONE.\n'); 

end

function res = readfile(filename,type)

fid = fopen(filename,'r');

fprintf('...reading file %s',filename);

k=0;
tline = fgetl(fid);
while ischar(tline)
    k=k+1;
    a=str2double_custom(tline,type);
    if type==1
        res{k}=a(2:end);
    elseif type==2
        res(k,:)=a;
    else
       error('!!!');
    end
    tline = fgetl(fid);
end

fclose(fid);

fprintf(' done! (total %i lines)\n',k);

end

function res = str2double_custom(str,type)

if type~=3
    a = strsplit(str,'\t');
    if length(a)<2
        a = strsplit(str,' ');
    end
    res = nan(1,length(a));
    for i=1:length(a)
        a{i}=strtrim(a{i});
        res(i)=str2double(a{i});
    end        
    if nnz(isnan(res))
        warning('Result contains NaN''s!!!!!!!')
    end
else    
    error('not implemented (nasty one to parse...)')
    
    C1 = strsplit(str,'\t');
    C2 = strsplit(str,' ');    
    if length(C1)>=length(C2)
        
    else
        
    end        
end

end

