function [resultmat,quality,ew]=covstatis_and_distatis(input_mat,autoscale)
%function res=cosmo_distatis(ds, varargin)
% apply DISTATIS measure to each feature
%
% res=cosmo_statis_measure(ds, opt)
%
% Inputs:
%    ds               dataset struct with dissimilarity values; usually
%                     the output from @cosmo_dissimilarity_matrix_measure
%                     applied to each subject followed by cosmo_stack. It
%                     can also be a cell with datasets (one per subject).
%    'return', d      d can be 'distance' (default) or 'crossproduct'.
%                     'distance' returns a distance matrix, whereas
%                     'crossproduct' returns a crossproduct matrix
%    'split_by', s    sample attribute that discriminates chunks (subjects)
%                     (default: 'chunks')
%    'shape', sh      shape of output if it were unflattened using
%                     cosmo_unflatten, either 'square' (default) or
%                     'triangle' (which gives the lower diagonal of the
%                     distance matrix)
%
% Returns:
%    res              result dataset struct with feature-wise optimal
%                     compromise distance matrix across subjects
%      .samples
%
%
% Example:
%     ds=cosmo_synthetic_dataset('nsubjects',5,'nchunks',1,'ntargets',4);
%     %
%     % define neighborhood (here a searchlight with radius of 1 voxel)
%     nbrhood=cosmo_spherical_neighborhood(ds,'radius',1,'progress',false);
%     %
%     % define measure
%     measure=@cosmo_dissimilarity_matrix_measure;
%     % each subject is a chunk
%     ds.sa.chunks=ds.sa.subject;
%     % compute DSM for each subject
%     sp=cosmo_split(ds,'chunks');
%     for k=1:numel(sp)
%         sp{k}=cosmo_searchlight(sp{k},nbrhood,measure,'progress',false);
%         sp{k}.sa.chunks=ones(6,1)*k;
%     end
%     % merge results
%     dsms=cosmo_stack(sp);
%     %
%     r=cosmo_distatis(dsms,'return','distance','progress',false);
%     cosmo_disp(r);
%     > .samples
%     >   [     0         0         0         0         0         0
%     >     0.818      1.09      0.77     0.653      1.03     0.421
%     >     0.869       1.3      1.06      1.04     0.932      1.07
%     >       :         :         :         :         :         :
%     >      1.16     0.889      0.99     0.631      1.48     0.621
%     >     0.268     0.952     0.965     0.462     0.943      1.04
%     >         0         0         0         0         0         0 ]@16x6
%     > .fa
%     >   .center_ids
%     >     [ 1         2         3         4         5         6 ]
%     >   .i
%     >     [ 1         2         3         1         2         3 ]
%     >   .j
%     >     [ 1         1         1         2         2         2 ]
%     >   .k
%     >     [ 1         1         1         1         1         1 ]
%     >   .nvoxels
%     >     [ 3         4         3         3         4         3 ]
%     >   .radius
%     >     [ 1         1         1         1         1         1 ]
%     >   .quality
%     >     [ 0.685     0.742     0.617     0.648     0.757     0.591 ]
%     >   .nchunks
%     >     [ 5         5         5         5         5         5 ]
%     > .a
%     >   .fdim
%     >     .labels
%     >       { 'i'  'j'  'k' }
%     >     .values
%     >       { [ 1         2         3 ]  [ 1         2 ]  [ 1 ] }
%     >   .sdim
%     >     .labels
%     >       { 'targets1'  'targets2' }
%     >     .values
%     >       { [ 1    [ 1
%     >           2      2
%     >           3      3
%     >           4 ]    4 ] }
%     >   .vol
%     >     .mat
%     >       [ 2         0         0        -3
%     >         0         2         0        -3
%     >         0         0         2        -3
%     >         0         0         0         1 ]
%     >     .dim
%     >       [ 3         2         1 ]
%     >     .xform
%     >       'scanner_anat'
%     > .sa
%     >   .targets1
%     >     [ 1
%     >       2
%     >       3
%     >       :
%     >       2
%     >       3
%     >       4 ]@16x1
%     >   .targets2
%     >     [ 1
%     >       1
%     >       1
%     >       :
%     >       4
%     >       4
%     >       4 ]@16x1
%
% Reference:
%   - Abdi, H., Valentin, D., O?Toole, A. J., & Edelman, B. (2005).
%     DISTATIS: The analysis of multiple distance matrices. In
%     Proceedings of the IEEE Computer Society: International conference
%     on computer vision and pattern recognition, San Diego, CA, USA
%     (pp. 42?47).
%
% Notes:
%   - DISTATIS tries to find an optimal compromise distance matrix across
%     the
%   - Output can be reshape to matrix or array form using
%     cosmo_unflatten(res,1)
%

% 1. Transform each distance matrix (
% i.e.,
% each study) into
% a between-object cross-product matrix.
% 2. Analyze the structure of the cross-product matrices.
% 3. Derive an optimal set of weights for computing the
% compromise.
% 4. Compute the compromise as a weighted sum of the in-
% dividual cross-product matrices.
% 5. Compute the eigen-decomposition of the compromise
% matrix

% NNO Sep 2014

weights_type='eig';
return_type = 'correlation';

nsubj=numel(input_mat);
nclasses = size(input_mat{1},1);

types = zeros(1,nsubj);
for i=1:nsubj
    a = sum(abs(diag(input_mat{i})));
    if a<eps
        types(i)=1;
    elseif abs(a-nclasses)<eps
        types(i)=2;
    else
       error('matrix diagonals must be 0 or 1!') 
    end
end
if length(unique(types))>1
    error('Types must be consistent!')
end
iscorrelation = 1;
if types(1)==1
    iscorrelation = 0;
    return_type = 'distance';
end

x=zeros(nclasses*nclasses,nsubj);
scale=nan(nsubj,1);
for j=1:nsubj
    if iscorrelation
        [x(:,j),scale(j)]=correlation2crossproduct(input_mat{j}, autoscale);
    else
        [x(:,j),scale(j)]=distance2crossproduct(input_mat{j}, autoscale);
    end
        
end

nkeep=nsubj;

% equivalent, but slower:
% [e,v]=eigs(c,1);

[ew,v]=get_weights(x, nkeep, weights_type);

% compute compromise
compromise=x*ew*sum(scale.*ew);

result=convert_compromise(compromise, return_type);

quality=v/nkeep;

resultmat = zeros(nclasses,nclasses);
resultmat(1:length(result))=result;

function [ew,v]=get_weights(x, nkeep, opt)
switch opt
    case 'eig'
        [ew,v]=eigen_weights(x,opt);        
    case 'uniform'
        % all the same (allowing for comparison with 'eig')
        ew=ones(nkeep,1)/nkeep;
        v=0;        
    otherwise
        error('illegal weight %s', opt.weight);
end

function [ew,v]=eigen_weights(x,opt)
%persistent correlation_warning_shown

c=cosmo_corr(x);

if any(c(:)<0)
    msg=sprintf(['negative correlations found '...
        ', minimum=%d'],min(c(:)));
    disp(msg);
    %     if false %opt.abs_correlation
    %         if isempty(correlation_warning_shown)
    %             msg=sprintf(['%s\nthe absolute value of the correlations '...
    %                 'is taken because .abscorrelation=true, but '...
    %                 'this feature is ***experimental*** and not '...
    %                 'properly validated. Interpret results with '...
    %                 'care'],msg);
    %             cosmo_warning(msg);
    %  %           correlation_warning_shown=true;
    %         end
    %         c=abs(c);
    %     else
    msg=sprintf(['%s\nIf you know what you are doing (as a '...
        'litmus test, you would be able to  '...
        'implement DISTATIS), consider to use the option:  '...
        '''abs_correlation'',true'],msg);
    error(msg);
    %    end
end

[v,e]=fast_eig1(c);
assert(all(e>0));
assert(v>0);

% normalize first eigenvector
ew=e/sum(e);

function result=convert_compromise(compromise, opt)
switch opt
    case 'crossproduct'
        result=compromise;
    case 'distance'
        result=crossproduct2distance(compromise);
    case 'correlation'
        result=crossproduct2distance(compromise);   
        result=1-result;
    otherwise
        error('illegal opt.return');
end

function z=crossproduct2distance(x)
n=sqrt(numel(x));
e=ones(n,1);
d=x(1:(n+1):end);
dd=d*e';
ddt=dd';
y=dd(:)+ddt(:)-2*x;
z=ensure_distance_vector(y);

function assert_symmetric(x, tolerance)
if nargin<2, tolerance=1e-8; end
xx=x'-x;

msk=xx>tolerance;
if any(msk)
    [i,j]=find(msk,1);
    error('not symmetric: x(%d,%d)=%d ~= %d=x(%d,%d)',...
        i,j,x(i,j),x(j,i),j,i);
end

function [z_vec,scale]=distance2crossproduct(x, autoscale)

n=size(x,1);
e=ones(n,1);
m=e*(1/n);
ee=eye(n)-e*m';
y=-0.5*ee*(x)*ee';
if autoscale
    scale = fast_eig1(y);
    z=(1/scale)*y;
else
    scale=1;
    z=y;
end
assert_symmetric(z)
% equivalent, but slower:
% z=(1/eigs(y,1))*y(:);

z_vec=z(:);


function [z_vec,scale]=correlation2crossproduct(x, autoscale)

n=size(x,1);
e=ones(n,1);
m=e*(1/n);
ee=eye(n)-e*m';
y=0.5*ee*(x)*ee';
if autoscale
    scale = fast_eig1(y);
    z=(1/scale)*y;
else
    scale=1;
    z=y;
end
assert_symmetric(z)
% equivalent, but slower:
% z=(1/eigs(y,1))*y(:);
z_vec=z(:);


function [lambda,pivot]=fast_eig1(x)
% compute first (largest) eigenvalue and corresponding eigenvector
% using power iteration method; benchmarking suggests this can be up to
% five times as fast as using eigs(x,1)
n=size(x,1);
pivot=ones(n,1);
tolerance=1e-8;
max_iter=1000;

old_lambda=NaN;
for k=1:max_iter
    z=x*pivot;
    pivot=z / norm(z);
    
    lambda=pivot'*z;
    if abs(lambda-old_lambda)/lambda<tolerance
        z=x*pivot;
        pivot=z / sqrt(sum(z.^2));
        
        lambda=pivot'*z;
        return
    end
    old_lambda=lambda;
end

% matlab fallback (only if above fails)
[pivot,lambda]=eigs(x,1);

function y=ensure_distance_vector(x)
tolerance=1e-8;

n=sqrt(numel(x));
xsq=reshape(x,n,n);

dx=diag(xsq);
assert(all(dx<tolerance));

xsq=xsq-diag(dx);

delta=xsq-xsq';
assert(all(delta(:)<tolerance))

xsq=.5*(xsq+xsq');
y=xsq(:);

function c=cosmo_corr(x,y,corr_type)
% Computes correlation - faster than than matlab's "corr" for Pearson.
%
% c=comso_corr(x[,y[,corr_type]])
%
% Inputs:
%   x          PxM matrix.
%   y          PxN matrix (optional). If omitted then y=x.
%   corr_type  'Pearson' or 'Spearman' or 'Kendall' (optional). If omitted
%              then corrtype='Pearson' and the computation time is
%              significantly reduced for small matrices x and y (with
%              /tiny/ numerical imprecisions) by the use of a custom
%              implementation.
%              Using 'Spearman' or 'Kendall' required the matlab stats
%              toolbox.
% Output:
%   c          MxN matrix with c(i,j)=corr(x(:,i),y(:,j),'type',corr_type).
%
% Notes:
%  - this function does not compute probability values.
%  - Using 'Spearman' or 'Kendall' for corr_type requires the matlab stats
%    toolbox.
%
% Example:
%   % generate some pseudo-random data.
%   x=reshape(mod(3:7:7e5,41),100,[]);
%   y=reshape(mod(1:7:7e5,37),100,[]);
%   % compute builtin corr with cosmo_corr
%   % call the function first to avoid lookup delays; then measure time
%   c=corr(x,y);
%   cc=cosmo_corr(x,y);
%   % compute differences in output
%   delta=c-cc;
%   max_delta=max(abs(delta(:)));
%   fprintf('difference not greater than eps: %d\n',max_delta<=eps);
%   > difference not greater than eps: 1
%
% See also: corr
%
% NNO Sep 2013 (from NNO's phoebe_corr, July 2010)
y_as_x=false;

if nargin<2
    corr_type='Pearson';
    y_as_x=true;
elseif ischar(y)
    corr_type=y;
    y_as_x=true;
elseif nargin<3
    corr_type='Pearson';
end

if y_as_x
    y=x;
end

    switch corr_type
        case 'Pearson'
            % speed-optimized version
            nx=size(x,1);
            ny=size(y,1);

            % subtract mean
            xd=bsxfun(@minus,x,sum(x,1)/nx);
            yd=bsxfun(@minus,y,sum(y,1)/ny);

            % normalization
            n=1/(size(x,1)-1);

            % standard deviation
            xs=(n*sum(xd .^ 2)).^-0.5;
            ys=(n*sum(yd .^ 2)).^-0.5;

            % compute correlations
            c=n * (xd' * yd) .* (xs' * ys);

            if y_as_x
                % ensure diagonal elements are 1
                dc=diag(c);
                c=(c-diag(dc))+eye(numel(dc));
            end

        otherwise
            % fall-back: use Matlab's function
            % will puke if no Matlab stat toolbox
            c=corr(x,y,'type',corr_type);
    end
        
        
