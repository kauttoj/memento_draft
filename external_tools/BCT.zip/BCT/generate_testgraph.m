function [mat,mod] = generate_testgraph(N_nodes,N_modules,ratio)
%GENERATE_TESTGRAPH Summary of this function goes here
%   Detailed explanation goes here

N_modules=min(N_nodes,N_modules);
N_modules=max(1,N_modules);

mat = rand(N_nodes,N_nodes);

mod = randi(N_modules,1,N_nodes);

for a=unique(mod)
    ind = find(mod==a);
    mat(ind,ind)=ratio*rand(length(ind),length(ind));    
end

mat=triu(mat,1);
mat=mat+mat';

end

