function [new_com1,new_com2] = match_communities(com1,com2)
%MATCH_COMMUNITIES Summary of this function goes here
%   Detailed explanation goes here

com1=com1(:);
com2=com2(:);

a=unique(com1);
N1=length(a);
b=unique(com2);
N2=length(b);

switched=0;
if N2<N1
    switched = 1;
    c=com1;
    com1=com2;
    com2=c;    
    c=a;
    a=b;
    b=c;
    c=N1;
    N1=N2;
    N2=c;
end

mat = zeros(N1,N2);

for i=1:N1,
    ind1 = com1==a(i);
    for j=1:N2,                
        ind2=com2==b(j);
        mat(i,j)=nnz(ind1.*ind2);
    end
end

bestpair = [0,0];
kk=0;

for i=1:N1,
    ind = find(mat(i,:)==max(mat(i,:)));
    ind = ind(randperm(length(ind)));
    for j=ind
       [~,k]=max(mat(:,j));
       if k==i
           kk=kk+1;
           bestpair(kk,:)=[a(i),b(j)];
           break;
       end
    end    
end

fprintf('Best match found for %i of %i\n',kk,N2);

if kk<N2
    aa=unique(a(~ismember(a,bestpair(:,1))));
    ind1=find(~ismember(b,bestpair(:,2)));
    for k1=1:length(aa),
        i=find(aa(k1)==a);
        ind = find(mat(i,ind1)==max(mat(i,ind1)));
        ind = ind(randperm(length(ind)));
        mm=-1;
        k2=-1;
        for j=ind           
            [m,k]=max(mat(i,ind1(j)));
            if m>mm
                mm=m;
                k2=k;
            end
        end        
        kk=kk+1;
        bestpair(kk,:)=[aa(k1),b(ind1(k2))];
        ind1(k2)=[];
    end
end

new_com1=0*com1;
new_com2=0*com2;

if length(unique(bestpair(:,1)))~=kk
    error('!!!')
end
if length(unique(bestpair(:,2)))~=kk
    error('!!!')
end

for i=1:kk
   new_com1((com1==bestpair(i,1)))=i; 
   new_com2((com2==bestpair(i,2)))=i;     
end

bb=b((~ismember(b,bestpair(:,2))));
for i=1:length(bb)
    new_com2((com2==bb(i)))=kk+i;
end

if switched==1   
    c=new_com1;
    new_com1=new_com2;
    new_com2=c;
end

disp('')

end

