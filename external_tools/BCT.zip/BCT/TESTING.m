clc;clear all;close all;

[mat,mod_real] = generate_testgraph(100,3,5);
mat(mat<0.98)=0;
mat(mat>0)=1;

Q_best=-1;
for i=1:100,
    [a,b]=community_louvain(mat);
    all_Q(i)=b;
    N_coms(i)=length(unique(a));
    all_coms(:,i)=a;
    if b>Q_best,
        Q_best=b;
        mod_best=a';
    end;
end

[com1,com2] = match_communities(mod_real,mod_best);
[com1,i]=sort(com1);
com2=com2(i);
figure;
title('Simple')
plot(1:length(com1),com1,'bo',1:length(com2),com2,'rs')
title('Simple')
nnz(com1~=com2)

D = agreement(all_coms);
D=D/max(D(:));
mod_cons = consensus_und(D,0.5,20);
% k=0;
% for dens = linspace(0.2,0.8,15)
%     k=k+1;
%     mod_cons1(:,k) = consensus_und(D,dens,10);
%     N1_coms(k)=length(unique(mod_cons1(:,k)));
% end
% a = (median(N_coms)-N1_coms);
% ind = find(a==min(abs(a)));
% mod_cons=mod_cons1(:,round(mean(ind)));
% 
[com1,com2] = match_communities(mod_real,mod_cons);
[com1,i]=sort(com1);
com2=com2(i);
figure;
plot(1:length(com1),com1,'bo',1:length(com2),com2,'rs')
title('Consensus')
nnz(com1~=com2)

res = link_communities_orig(mat);
[com1,com2] = match_communities(mod_real,res.comm_node);
[com1,i]=sort(com1);
com2=com2(i);
figure;
plot(1:length(com1),com1,'bo',1:length(com2),com2,'rs')
title('Links')
nnz(com1~=com2)