function res = sec2min(sec,isminimal)

if nargin<2
    isminimal=false;
end

for i=1:length(sec)
    hours = floor(sec(i)/(60*60));
    sec(i)=sec(i)-hours*60*60;
    
    min = floor(sec(i)/60);
    
    if min<10 && ~isminimal
        m = ['0',num2str(min)];
    else
        m = num2str(min);
    end
    
    a = sec(i) - 60*min;
    
    if a<10
        s=sprintf('%1.2f',a);
        s=['0',s];
    else
        s=sprintf('%2.2f',a);
    end
    
    if i==1
        if ~isminimal || hours>0
            str = [num2str(hours),':',m,':',s];    
        else            
            str = [m,':',s];        
        end
    else
        if ~isminimal || hours>0
            str = [str,', ',[num2str(hours),':',m,':',s]];        
        else
            str = [str,', ',[m,':',s]];
        end
    end
end
if nargin == 0
    disp(str)
else
    res = str;
end