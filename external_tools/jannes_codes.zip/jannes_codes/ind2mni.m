function out = ind2mni(in)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

in = double(in);
T = [45,63,36] + [1,1,1];
T = repmat(T,[size(in,1),1]);

out = 2*(in - T);

end

