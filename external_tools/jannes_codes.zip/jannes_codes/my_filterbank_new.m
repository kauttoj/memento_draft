clear all
close all

TR=2;
Fs=1/TR;

cfg.Fs=1/2;

%% FILTER BANDS // In Hertz


bs{1}=[0 0.01 0.027 0.036];         % slow 5
bs{2}=[0.02 0.027 0.073 0.08];      % slow 4!!!!
bs{3}=[0.06 0.073 0.198 0.21];      % slow 3
bs{4}=[0.19 0.198];                 % slow 2
bs{5}=[0.01,0.1];		    % tyypillinen alue connectivity-analyyseissä (etenkin resting state)

As{1}=[0 1 0];
As{2}=[0 1 0];
As{3}=[0 1 0];
As{4}=[0 1];

DEVs{1}=[0.05 0.05 0.05];
DEVs{2}=[0.05 0.05 0.05];
DEVs{3}=[0.05 0.05 0.05];
DEVs{4}=[0.05 0.05];


T=300;
x=zscore(randn(T,1));
figure(100)
plot(x,'k','LineWidth',2);
map=jet(4);
for f=1:4
    % make the filter
    [N,Fo,Ao,W] = firpmord(bs{f},As{f},DEVs{f},Fs);

%    HFcutoff = 0.10;
%    LFcutoff = 0.01;
    NyqF = (1/TR)/2;
    WnH = (0*bs{f}(4)+2*bs{f}(3)) / (2*NyqF);
    WnL = (2*bs{f}(2)+0*bs{f}(1)) / (2*NyqF);
    [bb, aa] = butter(5, [WnL,WnH],'bandpass');
    %h1=dfilt.df2(b,a);      % This is an unstable filter
    
    [z, p, k] = butter(5,[WnL,WnH],'bandpass');
    [sos,g]=zp2sos(z,p,k);
    h2=dfilt.df2sos(sos,g);              
    
    %out1(:,f)=filtfilt(b,a,x);
    out1(:,f)=filtfilt(sos,g,x);
    
    if(mod(N,2)==1)
        N=N+1;  % it has to be even -> b is odd -> delay is integer = N/2
    end
    figure(f)
    b=firpm(N,Fo,Ao,W);
    %freqz(b,1,1024);hold on;
    %freqz(b,1,1024)
%    figure(f)
%    subplot(2,1,1)
%    title(['filter length ' num2str(N)]);
    
    out(:,f)=filtfilt(b,1,x);
%    figure(100)
%    hold on
%    plot(out(:,f),'Color',map(f,:));
%    plot(out1(:,f),'--','Color',map(f,:));
    
    h3=dfilt.df2(b,1);      
 
    %subplot(2,2,f);
    hfvt=fvtool(h2,h3,'FrequencyScale','linear');
    s1 = ['Butter (ZPK Design), order ',num2str(length(bb))];
    s2 = ['FIR, order ',num2str(length(b))];
    legend(hfvt,s1,s2)
    
end

plot(sum(out,2),'Color',[.5 .5 .5],'lineWidth',2)



    
