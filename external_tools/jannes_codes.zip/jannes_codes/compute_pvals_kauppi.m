function [Th,Th_info,pvals_Th,pvals]=compute_pvals_kauppi(nullVals,vals,two_tailed)

% sort values into descending order:
if nargin<3
    two_tailed=0;
end


%nullVals = fliplr(nullVals);

if two_tailed==1
    fprintf('\nComputing TWO-TAILED p-values\n\n')
    q = 0.05/2;

    nullVals1 = sort(nullVals,'descend');
    N = length(nullVals1);
    nullVals1 = nullVals1(1:(1+floor(N*q)));    
    tables = generateLUT(nullVals1,N,q);
    tables.q = q;    
    [Th1,Th_info,pvals_Th1,pvals1] = evaluatePvals(vals,tables);
    
    nullVals1 = sort(-nullVals,'descend');
    N = length(nullVals1);
    nullVals1 = nullVals1(1:(1+floor(N*q)));    
    tables = generateLUT(nullVals1,N,q);
    tables.q = q;    
    [Th2,~,pvals_Th2,pvals2] = evaluatePvals(-vals,tables);
    Th2=-Th2;
    
    i=isnan(pvals1);
    pvals1(i)=1;
    i=isnan(pvals2);
    pvals2(i)=1;
    
    pvals = nan(size(pvals1));
    for i=1:length(pvals1)
        if pvals1(i)>pvals2(i)
            pvals(i)=pvals2(i);
        elseif pvals1(i)<pvals2(i)
            pvals(i)=pvals1(i);
        else
            pvals(i)=nan;
        end
    end       
    
    pvals_Th{1}=pvals_Th2;
    pvals_Th{2}=pvals_Th1;
    
    Th{1}=Th2;
    Th{2}=Th1;
    
else   
    fprintf('\nComputing RIGHT-TAILED p-values\n\n')    
    q = 0.05;
    nullVals = sort(nullVals,'descend');
    N = length(nullVals);
    nullVals = nullVals(1:(1+floor(N*q)));    
    tables = generateLUT(nullVals,N,q);
    tables.q = q;    
    [Th,Th_info,pvals_Th,pvals] = evaluatePvals(vals,tables);
end


function res = generateLUT(nullVals,N_perm,q)

intVals = [0    0.0050    0.0100    0.0200    0.0300    0.0400    0.0500]*q/0.05;
for k = 2:length(intVals)
  acc(k-1) = round( (intVals(k)-intVals(k-1))*N_perm/(k-1));
end

% get decimation factors for each LUT. Accuracy for each LUT can be changed
% by modifying "acc" field in PrivateParams -struct.
acc = floor(N_perm*diff(intVals)./acc);
acc(acc<1)=1;

% find critical value according to:
% Nichols and Holmes: "Nonparametric Permutation Tests For 
% Functional Neuroimaging: A Primer with Examples", HBM 15, 2001.
critVal = nullVals(1+floor(N_perm*q));

% generate look-up tables:
inds = [1 1+floor(intVals(2:end)*N_perm)];
%length(nullVals);
limits = nullVals(inds);
for k = 1:length(inds)-1
    v = nullVals(inds(k):inds(k+1)-1);
    v = v(1:acc(k):length(v));
    % calculate empirical cumulative cdf in a specified p-value range:
    %[notUsed XXXX] = ecdf(v);
    X = [min(v) unique(v)];
    X = X(:);
    %if (length(XXXX) == length(X))==0 || abs(XXXX - X) > 1e-6
    %    warning('problem')
    %    eee=0;
    %    
    %end
   % startV(k) = v(1);
   F = linspace(intVals(k),intVals(k+1),length(X));

   res.X{k} = X;
   res.F{k} = F;

end

res.limits = limits;
res.intVals = intVals;
res.critVal = critVal;
res.N = N_perm;


function [Th,Th_info,pvals_Th,pvals] = evaluatePvals(vals,tables)

critVal = tables.critVal;
limits = tables.limits;
intVals = tables.intVals;
q = tables.q;

% remove nan-values and redundant values from the data of interest:
%valsTmp = vals;
M = length(vals);
pvals = NaN*ones(M,1);
vals = vals(:)';
crapVals = isnan(vals) | vals < critVal;
vals(crapVals) = [];

Th_info{1} = ['none_' num2str(q)];
Th_info{2} = ['pID_' num2str(q)];
Th_info{3} = ['pN_' num2str(q)];
Th_info{4} = ['bonf_' num2str(q)];
Th_info{5} = ['none_' num2str(q/5)];
Th_info{6} = ['pID_' num2str(q/5)];
Th_info{7} = ['pN_' num2str(q/5)];
Th_info{8} = ['bonf_' num2str(q/5)];
Th_info{9} = ['none_' num2str(q/50)];
Th_info{10} = ['pID_' num2str(q/50)];
Th_info{11} = ['pN_' num2str(q/50)];
Th_info{12} = ['bonf_' num2str(q/50)];

% check empty condition for vals (no any voxels showing p < 0.05):
if isempty(vals)
  Th = zeros(1,12);
  pvals_Th = NaN*ones(1,12);
  return
end

% sort values into descending order:
[vals sinds] = sort(vals);
[trash sinds] = sort(sinds); % sinds keeps track of original indexing
vals = fliplr(vals);

SS = 0;
% calculate p-values from look-up tables using linear interpolation:
p = zeros(size(vals));
for k = 1:length(limits)-1
    idx = find(vals >= limits(k+1) & vals < limits(k));
    if ~isempty(idx)
      % load appropriate look-up table:
        F = tables.F{k};
        X = tables.X{k};
        if k == 1
            % to avoid nans in interpolation, set last point in the highest-end
            % look-up table at least as large as the highest value in true distribution:
            limits(1) = max(vals)+1e-6;
            X(end+1) = max(max(vals),max(X))+1e-6;
            F(end+1) = F(end);    
        end
        p(idx) = interp1(X(2:end),F(2:end),vals(idx));
        p(idx) = intVals(k) + (intVals(k+1) - p(idx));    
        SS = SS + length(idx);
    end
end

%SS
%sum(~crapVals)
%sum(crapVals)

% return p-values using original indexing:

p = fliplr(p);
p = p(sinds);

pvals(~crapVals) = p;
pvals = pvals(:)';

% perform multiple comparison corrections:
[pID,pN] = FDR(pvals,q);
[pID2,pN2] = FDR(pvals,(q)/5);
[pID3,pN3] = FDR(pvals,(q)/(50));

% corrected thresholds:
pvals_Th = [pID pN q/length(pvals) q/5 pID2 pN2 ((q)/5)/length(pvals) q/50 pID3 pN3 ((q)/50)/length(pvals)];

Th = zeros(1,11);

% use look-up tables to find threshold values:
for k = 1:length(limits)-1
  idx = find(pvals_Th < intVals(k+1) & pvals_Th >= intVals(k));
  if ~isempty(idx)
    % load appropriate look-up table:
    F = tables.F{k};
    X = tables.X{k};
    if k == 1
      % to avoid nans in interpolation, set last point in the highest-end
      % look-up table at least as large as the highest value in true distribution:
      X(end+1) = max(max(vals),max(X))+1e-6;
      F(end+1) = 0;
    end
    pvals_Th_flipped = intVals(k) + (intVals(k+1) - pvals_Th(idx));
    Th(idx) = interp1(F(2:end),X(2:end),pvals_Th_flipped);
  end
end

Th = [critVal Th];
pvals_Th = [q pvals_Th];



Th(Th==0)=inf;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% subfunction FDR by Tom Nichols:

function [pID,pN] = FDR(p,q)
% FORMAT pt = FDR(p,q)
% 
% p   - vector of p-values
% q   - False Discovery Rate level
%
% pID - p-value threshold based on independence or positive dependence
% pN  - Nonparametric p-value threshold
%______________________________________________________________________________
% @(#)FDR.m	1.3 Tom Nichols 02/01/18

p = sort(p(:));
V = length(p); 
I = (1:V)';
cVID = 1;
cVN = sum(1./(1:V));

pID = p(max(find(p<=I/V*q/cVID)));
pN = p(max(find(p<=I/V*q/cVN)));

if isempty(pID)
  pID = NaN;
end
if isempty(pN)
  pN = NaN;
end
