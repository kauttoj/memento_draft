function my_filter_and_cut(cfg)

cfg.input_folder = 'original_data';
cfg.subject_folder_prefix = 'S';
cfg.subject_id = [1 2 5 7 8 9 11 13 16 17 19 21];
cfg.output_filder = 'filtered_and_cutted_data';
cfg.template_folder = '/triton/becs/scratch/braindata/kauttoj2/working/templates';
cfg.TR = 2.015;
cfg.filter_type = 'FFT';
cfg.selected_intervals{1} = [10,20];
cfg.selected_intervals{2} = [30,40];
cfg.selected_intervals{3} = [60,70];
cfg.data_file_id = '4D.nii';
cfg.extract_motion_correction = 1;
cfg.motion_correction_folder = [cfg.input_folder,'/','RealignParameter'];
cfg.cut_before_filter = 0;
cfg.use_MNI152_template = 1;

if isempty(cfg.selected_intervals)
    do_intervals = 1;
    N_intervals = length(cfg.selected_intervals);
else
    do_intervals = 0;
    N_intervals=1;
end    

home = pwd;

nii = load_nii([cfg.template_folder,'/MNI152_T1_2mm_brain_mask.nii']);
mask = nii.img;
dims = size(mask);

new_dir = [home,'/',cfg.output_folder];
old_dir = [home,'/',cfg.input_folder];

if exist(old_dir,'folder')
    cd(old_dir);
    k=0;
    for i=cfg.subject_id
       k=k+1;
       if i<10
            str = [cfg.subject_folder_prefix,'0',num2str(i)];
       else
            str = [cfg.subject_folder_prefix,num2str(i)];
       end 
       if ~exist(str,'folder')
           str
           error('subject folder not found!')
       end
       subject_folders{k} = [old_folder,'/',str];
       subject_folders_part{k} = [str];
    end
    cd(home);
else
    old_folder
    error('old data folder not found!')
end

if ~exist(new_dir,'dir')
    disp('...creating new data folder')
    mkdir(new_dir);
end        

if strcmp(cfg.filter_type,'FIR')
    
    TR = cfg.TR;
    cfg.Fs=1/TR;
    cfg.F=[0.008 0.012 0.1 0.11];
    cfg.As=[0 1 0];
    cfg.DEV=[0.05 0.01 0.05];
    [N,Fo,Ao,W] = firpmord(cfg.F,cfg.As,cfg.DEV,cfg.Fs);
    if(mod(N,2)==1)
        N=N+1;  % it has to be even -> b is odd -> delay is integer = N/2
    end
    my_filter=firpm(N,Fo,Ao,W);
    
    fprintf('...FIR filter order is %i\n',N);

end

printx = round(linspace(1,91,10));

for k=1:length(subject_folders)    
    
    cd(subject_folders{k});    
    disp(['Subject ',num2str(cfg.subject_id(k)),', location: ',pwd]);
        
    T = get_nii_frame(cfg.data_file_id);
    
    if k>1 && T~=T_old
        T,T_old        
        error('Different total duration!')
    end
    T_old = T;
        
    nii = load_nii(cfg.data_file_id);
    cd(new_dir);   
    if ~exist(subject_folders_part{k},'dir')
        mkdir(subject_folders_part{k});        
    end    
    cd(subject_folders_part{k});
    if cfg.use_MNI152_template
        save_nii_oma(nii.img,'4D.nii');
    else
        save_nii(nii,'4D.nii');  
    end            
    
    for kk = 1:N_intervals                
        
        if do_interval==1
    
            sel = cfg.selected_intervals{kk}(1):cfg.selected_intervals{kk}(end);
            nii = load_nii(cfg.data_file_id,sel);
    
        else
            
            nii = load_nii(cfg.data_file_id); 
            
        end
        
    img = nii.img;
    
    cd(home);
    
    if cfg.extract_motion_correction==1
        
        cd(cfg.motion_correction_folder);
        cd(subject_folders_part{kk});
        a = dir('*.txt');
        if length(a.name)>1
            error('Folder has more than one TXT file!')
        end
        realign = importdata(a.name);
        if size(realign,2)~=6
            error('Realign parameters mismatch (must have 6)!')
        end
        if size(realign,1)~=T
            error('Realign time-dimension mismatch (must be T)!')
        end
        realign = realign(time_slice_selection,:);
        realign = realign - repmat(realign(1,:),length(time_slice_selection),1);
        realign = zscore(realign);
        
    end
       
    new_img = zeros([size(img,1),size(img,2),size(img,3),length(time_slice_selection)]);
    
    fprintf('...filtering in progress ');
     
    count = 0;
    
    for x=1:dims(1),
        if ismember(x,printx)
            fprintf(' %i',x);
        end
        for y=1:dims(2),
            for z=1:dims(3),
                if mask(x,y,z)>0
                   dat = double(squeeze(img(x,y,z,:)));
                   
                   m = mean(dat);
                   v = var(dat);
                   
                   if ~isnan(m) && v~=0
                   
                        count = count+1;
                        dat = dat - mean(dat);
                        %[bb,int,dat]=regress(dat,realign);
                        dat_bp = filtfilt(my_filter,1,dat);
                        new_img(x,y,z,:) = dat_bp;
                    
                   end
                end                
            end
        end
    end
    nii.img = single(new_img);
        
    fprintf('Total %i good voxels (inside mask)\n',count);
    
 
    cd(str);
    disp(['saving data in: ',pwd]);
    
        save_nii(nii,'4D_329.nii');   
    end
end

disp('Done!');
cd(home);