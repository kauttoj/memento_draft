
clc;

t=linspace(0,5*pi,400);
data = zeros(10,400);
for i=1:5
    data(i,:) = sin(t) + 0.2*randn(size(t));
end
data(5,:) = -sin(t) + 0.2*randn(size(t));
for i=6:10
    data(i,:) = cos(t) + 0.2*randn(size(t));
end

cormat = corr(data');
a=cormat;
a(abs(a)<0.2)=0;
a

% ind = randperm(10);
% data = data(ind,:);
% cormat = corr(data');
% cormat=cormat - diag(diag(cormat));
% a=cormat;
% a(abs(a)<0.2)=0;
% a


D = pdist(data,'correlation');
Z = linkage(D,'single');
order = dendrogram_sort(Z,200);
cormat = cormat(order,order);
a=cormat;
a(abs(a)<0.2)=0;
a

k=0;
Y=[];
M=size(net,1);
for ii=2:M
    for jj=1:(ii-1)
        k=k+1;
        Y(k)=net(ii,jj);
    end
end
Z = linkage(Y,'complete');
order = dendrogram_sort(Z,200);
cormat(order,order)