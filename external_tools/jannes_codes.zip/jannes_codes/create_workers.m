function N_workers = create_workers( nworker )
% N_workers = create_workers( nworker )
if nargin<1
    nworker = 5;
end

try
    myCluster = gcp('nocreate');
    if isempty(myCluster)
        %delete(gcp)
        myCluster = parcluster('local');
        myCluster.NumWorkers=nworker;
        parpool(myCluster);
    end
    N_workers = myCluster.NumWorkers;
catch err % old matlab?
    if ~matlabpool('size')
        eval(['matlabpool local ',num2str(nworker)]);
    end
    N_workers = matlabpool('size');
end

fprintf('Created a pool with %i workers\n',N_workers)

end

