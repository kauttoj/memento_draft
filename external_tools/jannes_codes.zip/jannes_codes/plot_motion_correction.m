function [handle1,handle2] = plot_motion_correction( cfg )

% handle = plot_motion_correction( cfg )
% INPUT:
% cfg = fDPA configuration variable

home = pwd;

a = cfg.DataProcessDir;
if exist(a,'dir')~=7
    error('fDPA data folder not found!');
end

cd(a);
cd RealignParameter;

N = length(cfg.SubjectID);

for subj = 1:N
   
    cd(cfg.SubjectID{subj});
    listing = dir;
    data{subj} = getdata(listing);        
    cd ..
end

handle1 = figure('Position',[0,0,800,1100],'Name','Motion correction - translation');
for subj = 1:N
   subplot(N,1,subj);
   hold on;
   plot(data{subj}(:,1),'b');
   plot(data{subj}(:,2),'r');
   plot(data{subj}(:,3),'k');
   xlabel('timepoint');
   ylabel('correction');
   title(['Subject ',num2str(subj)]);
   axis tight;
   if subj == 1
       ma = max([max(data{subj}(:,1)),max(data{subj}(:,2)),max(data{subj}(:,3))]);
       mi = min([min(data{subj}(:,1)),min(data{subj}(:,2)),min(data{subj}(:,3))]);
       if abs(ma)<abs(mi)
           legend('x','y','z',3);
       else
           legend('x','y','z',2);
       end
   end
   box on;
end

handle2 = figure('Position',[800,0,800,1100],'Name','Motion correction - rotations');
for subj = 1:N
   subplot(N,1,subj);
   hold on;
   plot(data{subj}(:,4),'b');
   plot(data{subj}(:,5),'r');
   plot(data{subj}(:,6),'k');
   xlabel('timepoint');
   ylabel('correction');
   title(['Subject ',num2str(subj)]);
   axis tight;
   if subj == 1
       ma = max([max(data{subj}(:,4)),max(data{subj}(:,5)),max(data{subj}(:,6))]);
       mi = min([min(data{subj}(:,4)),min(data{subj}(:,5)),min(data{subj}(:,6))]);
       if abs(ma)<abs(mi)
           legend('pitch','roll','yaw',3);
       else
           legend('pitch','roll','yaw',2);
       end              
   end
   box on;
end

cd(home);

end

function res = getdata(in)

    L = length(in);
    
    k=0;
    for i=1:L,
       
        if in(i).isdir==0
           a = in(i).name;
           if strcmp('.txt',a((end-3):end))
               k=k+1;
               if k>1
                   error('Multiple text files!');
               end
                delimiterIn = ' ';
                headerlinesIn = 0;
                data = importdata(a,delimiterIn,headerlinesIn);              
           end
        end        
    end

    res = data;
    
    
end

