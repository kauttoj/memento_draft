function oma_replace_substring(old_str,new_str,do_replacement)
%OMA_REPLACE_SUBSTRING Summary of this function goes here
%   Detailed explanation goes here

if nargin<3
    do_replacement=0;
end

if length(old_str) ~= length(new_str)
   error('wrong string counts!') 
end

home = pwd;

k = findstr(home,'kauttoj2');
if isempty(k)
   error('Tarkista hakemisto!!') 
end

alldirs = dir();

for i=1:length(alldirs)
    if alldirs(i).isdir && ~strcmp(alldirs(i).name,'..') && ~strcmp(alldirs(i).name,'.')
        cd(alldirs(i).name);
        fil = dir('*.m');
        for j=1:length(fil)
            if ~fil(j).isdir
                fin = fopen(fil(j).name,'r');
                fout = fopen(['NEW_',fil(j).name],'w+');
                count=zeros(1,length(old_str));
                while ~feof(fin)
                    old_s = fgetl(fin);                    
                    for k=1:length(old_str)
                        new_s = strrep(old_s, old_str{k},new_str{k});
                        if ~strcmp(old_s,new_s)
                           count(k) = count(k)+1; 
                        end
                    end
                    fprintf(fout,'%s\n',new_s);                    
                end
                s='';
                for k=1:length(count)
                    s=[s,num2str(count(k)),', '];
                end
                s=s(1:(end-2));
                fprintf('file: %s\n... replacements: %s\n',fil(j).name,s);
                fclose(fin);
                fclose(fout);
                
                if sum(count)>0 && do_replacement==1
                    movefile(fil(j).name,['OLD_',fil(j).name]);
                    movefile(['NEW_',fil(j).name],fil(j).name);
                else
                    delete(['NEW_',fil(j).name]);
                end
            end
        end
        cd ..
    end
end

end
