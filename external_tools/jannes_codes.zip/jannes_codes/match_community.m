
function [all_nodes_pos,all_nodes_neg]=match_community(all_nodes_pos,all_nodes_neg)

uni_pos=unique(all_nodes_pos);
uni_neg=unique(all_nodes_neg);
c=zeros(length(uni_pos),length(uni_neg));
for i=1:length(uni_pos)
    a = 0*all_nodes_pos;
    a(all_nodes_pos==uni_pos(i))=1;    
    for j=1:length(uni_neg)
        b = 0*all_nodes_neg;
        b(all_nodes_neg==uni_neg(j))=1;
        
        c(i,j)=sum(a.*b);
    end                
end

fprintf('Original mixing matrix:\n')
c

pair = [];
val=[];
for i=1:size(c,1)
    kk1=find(c(i,:)==max(c(i,:)));
    for k1=kk1
        k2=find(c(:,k1)==max(c(:,k1)));
        
        if ismember(i,k2)
            if isempty(pair)
                pair=[uni_pos(i),uni_neg(k1)];
                val = c(i,k1);
            else
                pair(end+1,1:2)=[uni_pos(i),uni_neg(k1)];
                val(end+1) = c(i,k1);
            end
        end
    end
end

%c

i=0;
while i<length(val)
    i=i+1;
    
    k = find(pair(i,1)==pair(:,1));
    if length(k)>1
       [~,l]=max(val(k));
       k(l)=[];
       pair(k,:)=[];
       val(k)=[];      
    end
    
    k = find(pair(i,2)==pair(:,2));
    if length(k)>1
       [~,l]=max(val(k));
       k(l)=[];
       pair(k,:)=[];
       val(k)=[];
       i=0;
    end    
end

%pair

done = [];

for i=1:size(pair,1)
    if all(ismember(done,pair(i,:))==0)
        if pair(i,1)~=pair(i,2)
            ind1=all_nodes_neg==pair(i,2);
            ind2=all_nodes_neg==pair(i,1);
            
            all_nodes_neg(ind2)=pair(i,2);
            all_nodes_neg(ind1)=pair(i,1);
            
            done=[done,pair(i,1),pair(i,2)];
        end
    end
end

uni_pos=unique(all_nodes_pos);
uni_neg=unique(all_nodes_neg);
c=zeros(length(uni_pos),length(uni_neg));
for i=1:length(uni_pos)
    a = 0*all_nodes_pos;
    a(all_nodes_pos==uni_pos(i))=1;    
    for j=1:length(uni_neg)
        b = 0*all_nodes_neg;
        b(all_nodes_neg==uni_neg(j))=1;
        
        c(i,j)=sum(a.*b);
    end
        
end

fprintf('New mixing matrix:\n')
c