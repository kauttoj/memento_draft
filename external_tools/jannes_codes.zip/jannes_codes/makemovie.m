function makemovie(data,times,windowsize,filename)

s = RandStream('mt19937ar','Seed','shuffle');
RandStream.setGlobalStream(s);

if isstruct(data)
    type=2;
    T = length(data);
else
    type=1;
    T = size(data,4);
end

passed = 0;
for k=1:T
    if type==1
        mat = squeeze(data(:,:,:,k));
    elseif type==2
        mat = data(k).xyz;
    end
    val = mat(:);
    val(val==0 | isnan(val))=[];
    fprintf('frame %i: %i activations\n',k,length(val))
    if isempty(val)
        ma(k) = -inf;
        mi(k) = inf;
    else
        passed = 1;
        ma(k) = max(val);
        mi(k) = min(val);
    end
end

[total_mi,ind_mi]=min(mi);
[total_ma,ind_ma]=max(ma);

fprintf('Mimimum: %f (frame %i), Maximum: %f (frame %i)\n',total_mi,ind_mi,total_ma,ind_ma);

range = [total_mi,total_ma];

if passed
    
    writerObj = VideoWriter(filename,'Motion JPEG AVI');
    writerObj.FrameRate = 5;
    writerObj.Quality = 100;
    
%    aviobj = avifile(filename,'compression','none','fps',5,'quality',80);
    tempframe = fullfile(tempdir,'tempframe');
    open(writerObj);
    tic
    for k=1:T
        fprintf('frame %i/%i\n',k,T);
        aika = times(k);
        a = squeeze(data(:,:,:,k));
        s = sprintf('frame %4.0i, %4.0fs, %s (%s -> %s), %5.0i voxels ',k,aika,sec2min(max(0,aika-5)),sec2min(max(0,aika-windowsize/2-5)),sec2min(max(0,aika+windowsize/2-5)),nnz(a));
        handle = volume_plotter5_inv(a,1,s,1,autumn(256),range);
        %frame = getframe(handle);
        %tempframe =fullfile(tempname);
        print(handle,tempframe,'-dbmp');
        frame = imread([tempframe,'.bmp']);
        writeVideo(writerObj,im2frame(frame));
        
        %writerObj = addframe(writerObj, handle);
        
        %writeVideo(writerObj,frame);
        %delete([tempframe,'.bmp']);
        close(handle);
    end
    a=toc;
    fprintf('%fs per frame\n',a/T);
    close(writerObj);
    %aviobj = close(aviobj);
else
    warning('No values to plot, quitting');
end