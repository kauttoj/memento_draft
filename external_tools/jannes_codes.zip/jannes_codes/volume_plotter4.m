function handle = volume_plotter4(mat,kumpi,tit,volumetype,colormapp)

% INPUT:
% mat = 3D activation map
% mask = 3D mask that lies under our activation map (optional)
% tit = title for image (optional)

% This function uses MNI 2mm anatomical image with dimensions 91x109x91

% Janne K, 2013


% path to templates (change these)
% if exist('/scratch/braindata/kauttoj2/working/templates/','dir')
%     templa = '/scratch/braindata/kauttoj2/working/templates/';
% elseif exist('triton/becs/scratch/braindata/kauttoj2/working/templates/','dir')
%     templa = 'triton/becs/scratch/braindata/kauttoj2/working/templates/';
% else
%     error('Cannot find templates');
% end

% [x,y,z]=ind2sub(size(mat),find(mat == max(mat(:))))
% mat(x,y,z) = 1000;

if nargin<5
    colormapp = colormap('Autumn');
    if nargin<4    
        volumetype = 1;
        if nargin<3
            tit = '';    
        end        
    end
end

T1_type = 1;

%nii = load_nii('/scratch/braindata/kauttoj2/working/templates/MNI152_T1_2mm.nii');
factor = 1;
if volumetype == 1
    if T1_type==1
        
        load('MNI_T1_1mm');
        T1 = MNI_T1_1mm;%nii.img;
        
        %load('MNI_T1_1mm_mask');
        load('edge_slices_T1_1mm');
        %T1_mask = MNI_T1_1mm_mask;%nii.img;
        
        x_slicess = x_slice_1mm;
        y_slicess = y_slice_1mm;
        z_slicess = z_slice_1mm;
        
    else
        load('MNI_T1_2mm');
        T1 = MNI_T1_2mm;%nii.img;
        
        %load('MNI_T1_1mm_mask');
        load('edge_slices_T1_2mm');
        
        x_slicess = x_slice_2mm;
        y_slicess = y_slice_2mm;
        z_slicess = z_slice_2mm;
        
    end
    
    
    
    if ~all(size(mat)==size(T1))
        %error('Feature not yet available :)');
        
        s1 = size(mat);
        s2 = size(T1);
        
        a1 = s2(1)/s1(1);
        a2 = s2(2)/s1(2);
        a3 = s2(3)/s1(3);
        if abs(rem(a1,1)) + abs(rem(a2,1)) + abs(rem(a3,1)) > 100*eps || abs(a1-a2) + abs(a2-a3) > 10*eps
            error('T1 image size must be multiple of activation image');
        end
        
        factor = round(a1);
        
    end
    
end

if kumpi==1
    
    z_min = 30/91;
    z_max = 73/91;
    NSlices = 16;
    
    Z_mat = round(linspace(z_min,z_max,NSlices)*size(mat,3));
    
    %Z_mat(5) = 39;
    
    Z_T1 = Z_mat*factor;%round(linspace(z_min,z_max,NSlices)*size(T1,3));
        
    rows = 4;%ceil(sqrt(NSlices));
    cols = 4;%ceil(sqrt(NSlices));
    
    handle = figure('Position',[20,20,1150,900],'Name',tit);
    
elseif kumpi==2
    
    rows = 1;%ceil(sqrt(NSlices));
    cols = 3;%ceil(sqrt(NSlices));
    
    handle = figure('Position',[20,20,900,430],'Name',tit);
end




% T1_x  = 1-single(squeeze(sum(T1_mask,1))>0);
% T1_y = 1-single(squeeze(sum(T1_mask,2))>0);
% T1_z = 1-single(squeeze(sum(T1_mask,3))>0);

% T1_x = squeeze(T1(ceil(size(T1,1)/2)+3,:,:));
% T1_y = squeeze(T1(:,ceil(size(T1,2)/2)-3,:));
% T1_z = squeeze(T1(:,:,ceil(size(T1,3)/2)-5));



if ~(length(unique(mat(:)))==2)
    
    if kumpi==2
        
        annotation('textbox',[0.1 0.85 0.8 0.05],'string',tit,'FontSize',14,'HorizontalAlignment','center','VerticalAlignment','middle','EdgeColor','none')
        
        
        T1_x = x_slicess;
        T1_y = y_slicess;
        T1_z = z_slicess;
        
        a=single(mat>0);
        %a(x,y,z)=1000;
        mat_x = squeeze(sum(a,1));
        mat_y = squeeze(sum(a,2));
        mat_z = squeeze(sum(a,3));
        
        disp('Plotting cumulative activation maps');
        
        i=0;
        val = [mat_x(:);mat_y(:);mat_z(:)];
        val(val==0)=[];
        mi = min(val);
        ma = max(val);
        map = flipud(colormap('gray'));
        L = size(map,1);
        lim = linspace(mi-eps,ma+eps,L+1);
        
        custom_subplot(rows,cols,i+1);
        T1_slice = flipud((mat2gray(T1_x))');
        siz = size(T1_slice);
        siz = siz(1:2);
        imshow(T1_slice,'InitialMagnification','fit');
        aaa = find(1-T1_slice);
        temp = zeros([siz,3]);
        hold on;
        for j=1:L
            mat_slice = flipud(mat_x');
            mat_slice(mat_slice>lim(j+1) | mat_slice<lim(j))=0;
            mat_slice = (mat_slice>0);                        
            
            temp1 = upsample(mat_slice*map(j,1),factor);
            temp1(aaa)=0;
            temp(:,:,1)=temp1;
            temp1 = upsample(mat_slice*map(j,2),factor);
            temp1(aaa)=0;
            temp(:,:,2)=temp1;
            temp1 = upsample(mat_slice*map(j,3),factor);
            temp1(aaa)=0;
            temp(:,:,3)=temp1;                      
            
            h = imshow(temp, 'InitialMagnification','fit');
            set(h, 'AlphaData', upsample(mat_slice,factor));
        end
        
        %title('Summed activation');%['z = ',num2str(Z_mat(i)),'/',num2str(size(mat,3)),' (',num2str(aa),')']);
        freezeColors;
        set(gca,'YTick',[]);
        set(gca,'XTick',[]);
        hold off;
        
        custom_subplot(rows,cols,i+2);
        T1_slice = flipud(mat2gray(T1_y)');
        siz = size(T1_slice);
        siz = siz(1:2);
        imshow(T1_slice,'InitialMagnification','fit');
        aaa = find(1-T1_slice);
        temp = zeros([siz,3]);
        hold on;
        for j=1:L
            mat_slice = flipud(mat_y');
            mat_slice(mat_slice>lim(j+1) | mat_slice<lim(j))=0;
            mat_slice = (mat_slice>0);
            temp1 = upsample(mat_slice*map(j,1),factor);
            temp1(aaa)=0;
            temp(:,:,1)=temp1;
            temp1 = upsample(mat_slice*map(j,2),factor);
            temp1(aaa)=0;
            temp(:,:,2)=temp1;
            temp1 = upsample(mat_slice*map(j,3),factor);
            temp1(aaa)=0;
            temp(:,:,3)=temp1;   
            h = imshow(temp, 'InitialMagnification','fit');
            set(h, 'AlphaData', upsample(mat_slice,factor));
        end
        %title('summed activation');%['z = ',num2str(Z_mat(i)),'/',num2str(size(mat,3)),' (',num2str(aa),')']);
        freezeColors;
        set(gca,'YTick',[]);
        set(gca,'XTick',[]);
        hold off;
        
        custom_subplot(rows,cols,i+3);
        T1_slice = (mat2gray(T1_z));
        siz = size(T1_slice);
        siz = siz(1:2);
        imshow(T1_slice,'InitialMagnification','fit');
        aaa = find(1-T1_slice);
        temp = zeros([siz,3]);
        hold on;
        for j=1:L
            mat_slice = (mat_z);
            mat_slice(mat_slice>lim(j+1) | mat_slice<lim(j))=0;
            mat_slice = (mat_slice>0);
            temp1 = upsample(mat_slice*map(j,1),factor);
            temp1(aaa)=0;
            temp(:,:,1)=temp1;
            temp1 = upsample(mat_slice*map(j,2),factor);
            temp1(aaa)=0;
            temp(:,:,2)=temp1;
            temp1 = upsample(mat_slice*map(j,3),factor);
            temp1(aaa)=0;
            temp(:,:,3)=temp1;   
            h = imshow(temp, 'InitialMagnification','fit');
            set(h, 'AlphaData', upsample(mat_slice,factor));
        end
        %title('summed activation');%['z = ',num2str(Z_mat(i)),'/',num2str(size(mat,3)),' (',num2str(aa),')']);
        freezeColors;
        set(gca,'YTick',[]);
        set(gca,'XTick',[]);
        hold off;
        
    elseif kumpi==1
        
        annotation('textbox',[0.1 0.94 0.8 0.05],'string',tit,'FontSize',14,'HorizontalAlignment','center','VerticalAlignment','middle','EdgeColor','none')
                
        val = mat(:);
        val(val==0)=[];
        mi = min(val);
        ma = max(val);
        
        map = colormapp;%colormap('Autumn');
        %map_orig = map;
        L = size(map,1);
        lim = linspace(mi-eps,ma+eps,L+1);
        siz = size(mat);
        siz = siz(1:2);
        
        for i=1:NSlices
            
            disp(['Plotting map slice ' num2str(i) '/' num2str(NSlices)]);
            
            custom_subplot(rows,cols,i);
            
            if volumetype == 1
                image = (mat2gray((squeeze(T1(:,:,Z_T1(i))))));
                
            end
            
            temp = zeros([factor*siz,3]);
            hold on;
            aa = 0;
            %fprintf('slice %i, voxel in colorlevel: ',i);
            for j=1:L
                
                mat_slice = (squeeze(mat(:,:,Z_mat(i))));
                mat_slice(mat_slice>lim(j+1) | mat_slice<lim(j))=0;
                mat_slice = (mat_slice>0);
             %   fprintf('%i...',nnz(mat_slice));
                
                temp(:,:,1)=upsample(mat_slice*map(j,1),factor);
                temp(:,:,2)=upsample(mat_slice*map(j,2),factor);
                temp(:,:,3)=upsample(mat_slice*map(j,3),factor);
                
                h = imshow(temp, 'InitialMagnification','fit');
                set(h, 'AlphaData', upsample(mat_slice,factor));
                aa = aa + nnz(mat_slice);
            end
            %fprintf('\n');
            imshow(image,map,'InitialMagnification','fit');
            
            title(['z = ',num2str(Z_mat(i)),'/',num2str(size(mat,3))]);%' (',num2str(aa),')']);
            set(gca,'YTick',[]);
            set(gca,'XTick',[]);
            box on;
            hold off;
        end
        
        ax = axes('Position', [0.05 0.3 0.9 0.4], 'Visible', 'off');
        colorbar ('FontSize',12);
        set(ax,'CLim',[mi,ma],'YTick',linspace(mi,ma,10));     
        
    end
    
    
else
    
    %a = sort(unique(mat(:)));
            annotation('textbox',[0.1 0.94 0.8 0.05],'string',tit,'FontSize',14,'HorizontalAlignment','center','VerticalAlignment','middle','EdgeColor','none')
 
    
    for i=1:NSlices
        
        disp(['Plotting mask slice ' num2str(i) '/' num2str(NSlices)]);
        
        custom_subplot(rows,cols,i);
        mat_slice = (squeeze(mat(:,:,Z_mat(i))));
        if volumetype == 1
            T1_slice = (mat2gray((squeeze(T1(:,:,Z_T1(i))))));        
            img = imoverlay(T1_slice,upsample(mat_slice,factor),[1 0 0]);
            imshow(img, 'InitialMagnification', 'fit');
        else
            imshow(upsample(img,factor), 'InitialMagnification', 'fit');
        end
                
        title(['z = ',num2str(Z_mat(i)),'/',num2str(size(mat,3))]);
            set(gca,'YTick',[]);
            set(gca,'XTick',[]);        
        freezeColors;
        box on;
        
    end
    
    %     val = mat(:);
    %     val(val==0)=[];
    
end


