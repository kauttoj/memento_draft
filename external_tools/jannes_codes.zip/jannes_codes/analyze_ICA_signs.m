function res = analyze_ICA_signs( datafile,new_data_path)
%CHECK_ICA_SIGNS Summary of this function goes here
%   Detailed explanation goes here
disp('Tool to check sign of individual ICA timecourses');
disp('!!!!!! only single session study supported (at moment) !!!!!');

load(datafile);

files = sesInfo.inputFiles;
L=length(files);

N_components=sesInfo.userInput.numComp;
title_srt = sesInfo.userInput.prefix;

nii = load_nii([title_srt,'Mask']);
mask = single(nii.img);
mask_ind = find(mask>0);

% Parameters
N_voxels=100;


disp('Getting individual ICA timecourses');
for i=1:L
    
    if i<10
        str = ['00',num2str(i)];
    else
        str = ['0',num2str(i)];
    end
    cd([title_srt,'_sub',str,'_component_ica_s1_']);
    nii = load_nii([title_srt,'_sub',str,'_timecourses_ica_s1_']);
    kuva = nii.img;
    
    for j=1:N_components        
        if i==1 && j==1
            ica_ts = zeros(L,N_components,length(kuva(:,j)));
        end
        ica_ts(i,j,:) = zscore(kuva(:,j));
    end
    
    cd ..  
    
end

disp('Finding ICA peak voxels');
cd([title_srt,'_tmap_component_ica_s1_']);
for comp=1:N_components
    
    disp(['...component ',num2str(comp),'/',num2str(N_components)]);
    if comp<10
        str = ['00',num2str(comp)];
    else
        str = ['0',num2str(comp)];
    end
    nii = load_nii([title_srt,'_tmap_component_ica_s1_',str]);
    tmap = nii.img;
    
    pmap = 1-tcdf((tmap),L-1);
    
    tvals = tmap(mask_ind);
    pvals = pmap(mask_ind);
    
    [fdr_lim,fdr_mask] = FDR(pvals,0.05);
    tvals = tvals.*double(fdr_mask);
    %tmap_fdr = 0*tmap;
    %tmap_fdr(mask_ind)=tvals;    
    %tmap_fdr = extentThreshold(tmap_fdr,20);
          
    [tvals,order]=sort(tvals,'descend');
    
    if tvals(N_voxels)==0
        warning(['bad component ',num2str(comp),' !!!']);
    end
    max_inds{comp} = mask_ind(order(1:N_voxels));

end
cd ..

disp('Computing correlation with original data');
for i=1:L
    
    disp(['...subject ',num2str(i),'/',num2str(L)]);
    
    data = files(i).name;
    
    k = findstr('.nii',data(1,:));
    
    if isempty(k)
        k = findstr('.img',data(1,:));
        if isempty(k)
            error('known EPI filetype (neither NII or IMG)');
        end
        error('IMG not yet supported');
    else
        filename = data(1,1:(k+3));
        if nargin>1
           
            k = findstr('/',filename);
            k=k(end-1);
            filename(1:(k-1))=new_data_path;
                        
        end        
        
        nii = load_nii(filename);
        img = nii.img;
    end    
   
    for comp=1:N_components
            
        [xx,yy,zz]=ind2sub(size(img),max_inds{comp});
        
        ts = 0;
        for k=1:N_voxels
            x=xx(k);
            y=yy(k);
            z=zz(k);
            ts = ts + zscore(squeeze(img(x,y,z,:)));
        end
        ts=ts/N_voxels;
        
        korr(i,comp)=corr2(ts,squeeze(ica_ts(i,comp,:)));
        
    end
    
end
   
count=0;
disp('Possible flipped timecourses:')
for i=1:L
    for comp=1:N_components
        if korr(i,comp)<0
           count=count+1;
           fprintf('subject %i, component %i (%f)\n',i,comp,korr(i,comp));
        end
    end
end
if count==0
    disp('none found! :)')
else
    disp(['total ',num2str(count)]);
end

res=korr;

end
    
    

