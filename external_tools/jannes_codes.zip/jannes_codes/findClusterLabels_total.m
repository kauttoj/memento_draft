function [result,bestmatch] = findClusterLabels_total(image,min_size,montako,no_print)
% function result = findClusterLabels_total(image,min_size,montako)

if nargin<4
    no_print=0;
end


% Applies the extent threshold function of SPM5 on 'image' with given
% 'indices' and cluster size 'k'
%
% [x, y, z] = ind2sub(size(image), find(image));
%
% XYZ = [x y z];
%
% % from spm_getSPM line 676:
%
% %-Calculate extent threshold filtering (from spm_getSPM, line 676)
% %-------------------------------------------------------------------
% A     = spm_clusters(XYZ');
% Q     = [];
% for i = 1:max(A)
%     j = find(A == i);
%     if length(j) >= k; Q = [Q j]; end
% end
%
% % ...eliminate voxels
% %-------------------------------------------------------------------
% XYZ   = XYZ(Q,:);
%
% result = zeros(size(image));
% inds = sub2ind(size(image), XYZ(:,1), XYZ(:,2), XYZ(:,3));
% result(inds) = image(inds);
%

load('/triton/becs/scratch/braindata/kauttoj2/working/templates/HarvardOxford_labels_TOTAL.mat');
arealabels = HarvardOxford_labels_TOTAL;

dims = size(image);

image(isnan(image))=0;
[x, y, z] = ind2sub(size(image),find(image));
XYZ = [x y z];
% from spm_getSPM line 676:

%-Calculate extent threshold filtering (from spm_getSPM, line 676)
%-------------------------------------------------------------------
A     = spm_clusters(XYZ');
good = ones(1,length(A));

nii = load_nii('/triton/becs/scratch/braindata/kauttoj2/working/templates/HarvardOxford_2mm_th25_TOTAL.nii');
atlas= nii.img;

if length(unique(atlas(:)))-1 ~= length(arealabels)
    error('Atlas labels and values do not match!');
end

atlas(atlas==0)=length(arealabels)+1;
arealabels{end+1}='-';

clustersizes = zeros(1,max(A));
count = 0;
N=max(A);
if no_print==0
    disp(['Found ',num2str(N),' clusters']);
end
kk=0;
for i = 1:N
    ind = find(A==i);
    l = length(ind);
    clustersizes(i)=l;
    
    apu = sub2ind(dims,XYZ(ind,1),XYZ(ind,2),XYZ(ind,3));
    vals=image(apu);
    [maxvalues(i),k]=max(vals);
    maxpositions_ind{i}=(XYZ(ind(k),:));
    maxpositions{i}=ind2mni(XYZ(ind(k),:));
    
    areacounter = zeros(1,length(arealabels));
    
    for k=ind
        lab = atlas(XYZ(k,1),XYZ(k,2),XYZ(k,3));
        areacounter(lab)=areacounter(lab)+1;
    end
    
    %[a,b]=sort(areacounter,'descend');
    maxareas{i} = areacounter;
    
    if clustersizes(i)>=min_size
        good(count+1:count+l)=ind;
        count = count+l;
        
        %mask = zeros(dims);
        
    else
        kk = kk+1;
    end
end

pois = clustersizes<min_size;
clustersizes(pois)=[];
maxpositions_ind(pois)=[];
maxpositions(pois)=[];
maxvalues(pois)=[];
maxareas(pois)=[];

%maxpositions{i}=ind2mni(XYZ(ind(k),:));

if nargin<3
    montako = N;
end

[clustersizes,ind]=sort(clustersizes,'descend');
maxvalues=maxvalues(ind);
maxpositions=maxpositions(ind);
maxpositions_ind = maxpositions_ind(ind);
maxareas=maxareas(ind);
%
% fprintf('Size\tX\tY\tZ\tValue\n')
% for i=1:montako
%    fprintf('%i\t%i\t%i\t%i\t%f\n',clustersizes(i),maxpositions{i}(1),maxpositions{i}(2),maxpositions{i}(3),maxvalues(i));
%    result(i,:)=[clustersizes(i),maxpositions{i}(1),maxpositions{i}(2),maxpositions{i}(3),maxvalues(i)];
% end



montako = min(montako,length(clustersizes));

if no_print==0
    fprintf('Sort by cluster size\n');
    
    for i=1:montako
        
        fprintf('%i,%i,%i\n',maxpositions_ind{i}(1),maxpositions_ind{i}(2),maxpositions_ind{i}(3));
        
    end
        
    fprintf('\n TEX table format \n\n');
    
    fprintf('Cluster size & Value & X & Y & Z & Area \\\\ \n')
end
montako = min(montako,length(clustersizes));

for i=1:montako
    
    %area = atlas(maxpositions_ind{i}(1),maxpositions_ind{i}(2),maxpositions_ind{i}(3));
    
    [maxareas{i},k]=sort(maxareas{i},'Descend');
    
    apustr='';
    
    perc = zeros(1,length(maxareas{i}));
    notbad = true(1,length(maxareas{i}));
    for j=1:length(maxareas{i})
        
        if sum(perc(notbad))>=75
            break;
        end            
        
        if strcmp(arealabels{k(j)},'-')       
            perc(j) = round(100*maxareas{i}(j)/sum(maxareas{i}));
            %notbad(j)=false;
        else
            perc(j) = round(100*maxareas{i}(j)/sum(maxareas{i}));
            if ~isempty(apustr)
                apustr=[apustr,', ',[arealabels{k(j)},' (',num2str(perc(j)),'\%)']];
            else
                apustr=[arealabels{k(j)},' (',num2str(perc(j)),'\%)'];
            end
        end
        
        if j==1
            bestmatch{i}=apustr;
        end
        
    end
    
%     if ~strcmp(arealabels{k(2)},'-') && round(100*maxareas{i}(2)/sum(maxareas{i}))>5
%         apustr=[apustr,', ',[arealabels{k(2)},' (',num2str(round(100*maxareas{i}(2)/sum(maxareas{i}))),'\%)']];
%     end
%     
%     if isempty(bestmatch{i})
%         bestmatch{i}=apustr(3:end);
%     end
%     
%     if ~strcmp(arealabels{k(3)},'-') && round(100*maxareas{i}(3)/sum(maxareas{i}))>5
%         apustr=[apustr,', ',[arealabels{k(3)},' (',num2str(round(100*maxareas{i}(3)/sum(maxareas{i}))),'\%)']];
%     end
%     
%     if ~strcmp(arealabels{k(4)},'-') && round(100*maxareas{i}(4)/sum(maxareas{i}))>5
%         apustr=[apustr,', ',[arealabels{k(4)},' (',num2str(round(100*maxareas{i}(4)/sum(maxareas{i}))),'\%)']];
%     end
    
    if no_print==0
        fprintf('%i & %3.2f & %i & %i & %i & %s \\\\ \n',clustersizes(i),maxvalues(i),maxpositions{i}(1),maxpositions{i}(2),maxpositions{i}(3),apustr);
    end
    result(i,:)=[clustersizes(i),maxpositions{i}(1),maxpositions{i}(2),maxpositions{i}(3),maxvalues(i)];
    
    all_ks{i}=k;
end

if no_print==0
    fprintf('\n\n');
    fprintf('Cluster size, Value, X, Y, Z : Region \n')
end
for i=1:montako
    
    %area = atlas(maxpositions_ind{i}(1),maxpositions_ind{i}(2),maxpositions_ind{i}(3));
    
    %[maxareas{i},k]=sort(maxareas{i},'Descend');
    k=all_ks{i};
    
    apustr='';
    
    perc = zeros(1,length(maxareas{i}));
    notbad = true(1,length(maxareas{i}));
    for j=1:length(maxareas{i})
        
        if sum(perc(notbad))>=75
            break;
        end
        
        if strcmp(arealabels{k(j)},'-')
            %apustr='';
            perc(j) = round(100*maxareas{i}(j)/sum(maxareas{i}));
           % notbad(j)=false;
        else
            perc(j) = round(100*maxareas{i}(j)/sum(maxareas{i}));
            if ~isempty(apustr)
                apustr=[apustr,', ',[arealabels{k(j)},' (',num2str(perc(j)),'%)']];
            else
                apustr=[arealabels{k(j)},' (',num2str(perc(j)),'%)'];
            end
        end
        
        if j==1
            bestmatch{i}=apustr;
        end
        
    end
    
%     if ~strcmp(arealabels{k(2)},'-') && round(100*maxareas{i}(2)/sum(maxareas{i}))>5
%         apustr=[apustr,', ',[arealabels{k(2)},' (',num2str(round(100*maxareas{i}(2)/sum(maxareas{i}))),'\%)']];
%     end
%     
%     if isempty(bestmatch{i})
%         bestmatch{i}=apustr(3:end);
%     end
%     
%     if ~strcmp(arealabels{k(3)},'-') && round(100*maxareas{i}(3)/sum(maxareas{i}))>5
%         apustr=[apustr,', ',[arealabels{k(3)},' (',num2str(round(100*maxareas{i}(3)/sum(maxareas{i}))),'\%)']];
%     end
%     
%     if ~strcmp(arealabels{k(4)},'-') && round(100*maxareas{i}(4)/sum(maxareas{i}))>5
%         apustr=[apustr,', ',[arealabels{k(4)},' (',num2str(round(100*maxareas{i}(4)/sum(maxareas{i}))),'\%)']];
%     end
    
    if no_print==0
        fprintf('%i , %3.2f , %i , %i , %i: %s \n',clustersizes(i),maxvalues(i),maxpositions{i}(1),maxpositions{i}(2),maxpositions{i}(3),apustr);
    end
    result(i,:)=[clustersizes(i),maxpositions{i}(1),maxpositions{i}(2),maxpositions{i}(3),maxvalues(i)];
end

if no_print==0
    fprintf('\n\n')
    fprintf('Sort by peak value\n');
end
[maxvalues,ind]=sort(maxvalues,'descend');
maxpositions_ind=maxpositions_ind(ind);
clustersizes=clustersizes(ind);
maxpositions=maxpositions(ind);

if no_print==0
    fprintf('Cluster size & Value & X & Y & Z & Area \\\\ \n')
end

for i=1:montako
    
    area = atlas(maxpositions_ind{i}(1),maxpositions_ind{i}(2),maxpositions_ind{i}(3));
    if no_print==0
        fprintf('%i & %i & %i & %i & %s \\\\ \n',clustersizes(i),maxpositions{i}(1),maxpositions{i}(2),maxpositions{i}(3),arealabels{area});
    end
    result(i,:)=[clustersizes(i),maxpositions{i}(1),maxpositions{i}(2),maxpositions{i}(3),maxvalues(i)];
end

