function str_out = remove_space(str_in)

L=length(str_in);
ind = false(L,1);
for i=1:L
   charcode = find(char(0:255) == char(str_in(i))) - 1;
   if charcode == 13
       ind(i)=true;
   end
end
str_out = str_in;
str_out(ind)=' ';