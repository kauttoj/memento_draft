function pcomb = stouffer_combine(p)
% Stouffer et al's (1949) unweighted method for combination of 
% independent p-values via z's 

dims = size(p);

if dims(1)==1 || dims(2)==1

    if length(p)==0
        error('pfast was passed an empty array of p-values')
        pcomb=1;
    else
        pcomb = (1-erf(sum(sqrt(2) * erfinv(1-2*p))/sqrt(2*length(p))))/2;
    end
    
else
    
    fprintf('Stouffer combine: combining %i measurements (%i values each)\n',dims(1),dims(2));
    
    for i=1:dims(1)
        pcomb(i) = (1-erf(sum(sqrt(2) * erfinv(1-2*p(i,:)))/sqrt(2*length(p(i,:)))))/2;
    end
    
end