function res = ismemberpoint(points1,points2)
%ISMEMBERPOINT Summary of this function goes here
%   Detailed explanation goes here

N1 = size(points1,1);
M1=size(points1,2);
M2=size(points2,2);


if M1~=M2
   error('dimension mismatch!') 
end

res = zeros(1,N1);

for i=1:N1,
    
    a = (points1(i,1) == points2(:,1));
    for j=2:M1
       a = a & (points1(i,j) == points2(:,j));
    end    
    
    if nnz(a)>0
        res(i)=1;
    end    
end

end

