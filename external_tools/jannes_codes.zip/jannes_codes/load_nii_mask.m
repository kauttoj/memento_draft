function [ts_data,PATTERN_mask_ind] = load_nii_mask(niifile,mask,N_max_volumes)
%LOAD_NII_PARTS Summary of this function goes here
%   Detailed explanation goes here

nii=load_nii_hdr(niifile);
data_siz = nii.dime.dim(2:4);

if ~iscell(mask)
    a=mask;
    clear mask;
    mask{1}=a;
end

N_masks = length(mask);
str = '[';
for i=1:N_masks
    PATTERN_mask_ind{i} = find(mask{i});
    str = [str,num2str(length(PATTERN_mask_ind{i})),', '];
    mask_siz{i} = size(mask{i});
    
    if nnz(data_siz-mask_siz{i})>0
        error('Mask %i has different dimension',i);
    end
end
str = [str(1:end-2),']'];

N_vols=get_nii_frame(niifile);
if nargin<3
    N_max_volumes = N_vols+1;
end

N_read_parts = ceil(N_vols/N_max_volumes);

segments = round(linspace(1,N_vols,N_read_parts+1));
segments(end)=segments(end)+1;

fprintf('Mask size %s, reading data (in %i parts)... ',str,N_read_parts)

allvols=[];

for i=1:N_masks
    ts_data{i}=zeros(N_vols,length(PATTERN_mask_ind{i}));
end

for k=1:N_read_parts
    
    vols = segments(k):(segments(k+1)-1);
    allvols = [allvols,vols];
    try
        nii=load_nii(niifile,vols);
    catch err        
        nii=load_untouch_nii(niifile,vols);
        warning('Raw data matrix used. Left-right flipping of the matrix is possible!');
    end
    data = nii.img;
    siz=size(data);
    data=reshape(data,prod(siz(1:3)),siz(4))';
    
    for i=1:N_masks
        ts_data{i}(vols,:)=data(:,PATTERN_mask_ind{i});
    end
    clear data;
    
    fprintf('%i ',k);
end

if length(allvols)~=N_vols || any(diff(allvols)~=1)
    error('volume check failed!')
end

fprintf(' done!\n')

end

