function give_mricrogl_slices(rows,cols)
%CREATE_MRICROGL_SCRIPTS Summary of this function goes here
%   Detailed explanation goes here

lower=0.22;
upper=0.79;

N=rows*cols;

slices = linspace(lower,upper,N);
fprintf('\n');
fprintf('A H -0.15 V -0.15');
k=0;
for i=1:rows
    for j=1:cols;
        k=k+1;
        fprintf(' %3.2f',slices(k));
    end
    if i<rows
       fprintf(';');  
    end
end
fprintf(' X\n\n');
%fprintf(' X S 0.5\n\n');

end

