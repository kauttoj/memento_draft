function pcor = mafdr_oma(p, varargin)
% mafdr wrapper that checks and warns for crazy "corrected" p-vals
% only return corrected p-vals are returned (at moment)

call_str = [];
for i=1:length(varargin)
    call_str=[call_str,',varargin{',num2str(i),'}'];
end

eval(['pcor = mafdr(p',call_str,');']);

N_bad = nnz(pcor<p);
if N_bad>0
    warning('!!!! Total %i bad corrected p-values found !!!!',N_bad);
end


end

