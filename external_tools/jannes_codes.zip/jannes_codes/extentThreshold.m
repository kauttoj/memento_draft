function result = extentThreshold(image,k)
% function result = extentThreshold(image, k)
% Applies the extent threshold function of SPM5 on 'image' with given
% 'indices' and cluster size 'k' 
% 
% [x, y, z] = ind2sub(size(image), find(image));
% 
% XYZ = [x y z];
% 
% % from spm_getSPM line 676:
% 
% %-Calculate extent threshold filtering (from spm_getSPM, line 676)
% %-------------------------------------------------------------------
% A     = spm_clusters(XYZ');
% Q     = [];
% for i = 1:max(A)
%     j = find(A == i);
%     if length(j) >= k; Q = [Q j]; end
% end
% 
% % ...eliminate voxels
% %-------------------------------------------------------------------
% XYZ   = XYZ(Q,:);
% 
% result = zeros(size(image));
% inds = sub2ind(size(image), XYZ(:,1), XYZ(:,2), XYZ(:,3));
% result(inds) = image(inds);
% 

[x, y, z] = ind2sub(size(image),find(image));
XYZ = [x y z];
% from spm_getSPM line 676:

%-Calculate extent threshold filtering (from spm_getSPM, line 676)
%-------------------------------------------------------------------
A     = spm_clusters(XYZ');
good = ones(1,length(A));

clustersizes = zeros(1,max(A));
count = 0;
N=max(A);
disp(['Found ',num2str(N),' clusters']);
kk=0;
for i = 1:N
    ind = find(A==i);
    l = length(ind);
    clustersizes(i)=l;
    if l>=k
        good(count+1:count+l)=ind;
        count = count+l;
    else
        kk = kk+1;
    end
end
disp(['smallest cluster ',num2str(min(clustersizes)),', largest cluster ',num2str(max(clustersizes)),', Removed ',num2str(kk),' clusters']);

% ...eliminate voxels
%-------------------------------------------------------------------
XYZ = XYZ(good(1:count),:);

result = zeros(size(image));
inds = sub2ind(size(image), XYZ(:,1), XYZ(:,2), XYZ(:,3));
result(inds) = image(inds);