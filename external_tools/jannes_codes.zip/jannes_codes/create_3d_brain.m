skip = 7;

img=load_nii('MNI152_T1_2mm_brain_mask.nii');
brain=double(img.img);
prev=0;
p=[];
for x=1:91;
    for y=1:109
        for z=1:91;
            v=brain(x,y,z);
            if(prev~=v)
                p=[p; x y z];
            end
            prev=v;
        end
    end
end

p=p(1:skip:end,:);

[t,tnorm]=MyRobustCrust(p);
hand = gcf;
hold on
axis equal
h=trisurf(t,p(:,1),p(:,2),p(:,3),'facealpha',0.4,'facecolor',[1 1 1],'edgecolor',[0.8 0.8 0.8]);
view(3);
axis vis3d