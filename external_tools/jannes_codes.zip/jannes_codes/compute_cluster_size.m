function out = compute_cluster_size(maskfile,fwhm,pthr,athr)

% -------
% OPTIONS  [at least 1 option is required, or you'll get this help message!]
% -------
%  ***** Specify the volume over which the simulation will occur *****
% 
%   --** (a) Directly give the spatial domain that will be used **--
% -nxyz n1 n2 n3 = Size of 3D grid to use for simulation
%                   [default values = 64 64 32]
% -dxyz d1 d2 d3 = give all 3 voxel sizes at once
%                   [default values = 3.5 3.5 3.5]
% -BALL          = inside the 3D grid, mask off points outside a ball
%                   at the center of the grid and touching the edges;
%                   this will keep about 1/2 the points in the 3D grid.
%                   [default = use all voxels in the 3D grid]
% 
%   --** OR: (b) Specify the spatial domain using a dataset mask **--
% 
% -mask mset     = Use the 0 sub-brick of dataset 'mset' as a mask
%                   to indicate which voxels to analyze (a sub-brick
%                   selector '[]' is allowed) 
% 
% -OKsmallmask   = Allow small masks. Normally, a mask volume must have
%                   128 or more nonzero voxels.  However, IF you know what
%                   you are doing, and IF you are willing to live life on
%                   the edge of statistical catastrophe, then you can use
%                   this option to allow smaller masks -- in a sense, this
%                   is the 'consent form' for such strange shenanigans.
%                  * If you use this option, it must come BEFORE '-mask'.
%                  * Also read the 'CAUTION and CAVEAT' section, far below.
% 
%     ** '-mask' means that '-nxyz' & '-dxyz' & '-BALL' will be ignored. **
% 
% -fwhm s        = Gaussian filter width (all 3 dimensions)
%                   [default = 0.0 = no smoothing]
%                  * If you wish to set different smoothing amounts for
%                    each axis, you can instead use option
%                      -fwhmxyz sx sy sz
%                    to specify the three values separately.
% 
% -pthr p1 .. pn = list of uncorrected (per voxel) p-values at which to
%                   threshold the simulated images prior to clustering.
%                   [default = 0.02 0.01 0.005 0.002 0.001 0.0005 0.0002 0.0001]
% 
% -2sided        = Normally, 3dClustSim does '1-sided' testing.  The random
%                   dataset of Gaussian noise-only values is generated, and then
%                   it is thresholded on the positive side so that the N(0,1)
%                   upper tail probability is pthr.  If you use this option, then
%                   the thresholding is instead done in a 2-sided way: positive
%                   AND negative values will be clustered together, with the
%                   thresholding chosen to have a 2-sided tail probability given
%                   by pthr.
%                  * This option is for experimentation, not for serious use!
% 
% -athr a1 .. an = list of corrected (whole volume) alpha-values at which
%                   the simulation will print out the cluster size
%                   thresholds.  For each 'p' and 'a', the smallest cluster
%                   size C(p,a) for which the probability of the 'p'-thresholded
%                   image having a noise-only cluster of size C is less than 'a'
%                   is the output (cf. the sample output, below)
%                   [default = 0.10 0.05 0.02 0.01]
% 
%          ** Both lists '-pthr' and '-athr' (of values between 0 and 0.2)    **
%          ** should be given in DESCENDING order.  They will be sorted to be **
%          ** that way in any case, and such is how the output will be given. **
% 
%          ** The list of values following '-pthr' or '-athr' can be replaced **
%          ** with the single word 'LOTS', which will tell the program to use **
%          ** a longer list of values for these probabilities [try it & see!] **
%          ** (i.e., '-pthr LOTS' and/or '-athr LOTS' are legal options)      **
% 
% -LOTS          = the same as using '-pthr LOTS -athr LOTS'
% 
% -iter n        = number of Monte Carlo simulations [default = 10000]
% 
% -NN abc        = Define the clustering method(s) to use.  'abc' contains
%                  some set of digits from the set { 1 , 2 , 3 }, where
%                   1 = Use first-nearest neighbor clustering
%                       * above threshold voxels cluster together if faces touch
%                   2 = Use second-nearest neighbor clustering
%                       * voxels cluster together if faces OR edges touch
%                   3 = Use third-nearest neighbor clustering
%                       * voxels cluster together if faces OR edges OR corners touch
%                  To get outputs from all 3 types of clustering, use '-NN 123'.
%                  If you don't use this option, then only first-nearest neighbor
%                  clustering will be computed (as if you used '-NN 1').
% 
%               ** The clustering method only makes a difference at higher **
%               ** (less significant) values of pthr.   At small values of **
%               ** pthr (more significant),  all 3 clustering methods will **
%               ** give very similar results.                              **
% 
% -nodec         = normally, the program prints the cluster size threshold to
%                   1 decimal place (e.g., 27.2).  Of course, clusters only come
%                   with an integer number of voxels -- this fractional value
%                   is interpolated to give the desired alpha level.  If you
%                   want no decimal places (so that 27.2 becomes 28), use '-nodec'.
% 
% -seed S        = random number seed [default seed = 123456789]
%                   * if seed=0, then program will quasi-randomize it
% 
% -niml          = Output the table in an XML/NIML format, rather than a .1D format.
%                   * This option is for use with other software programs;
%                     see the NOTES section below for details.
%                   * '-niml' also implicitly means '-LOTS'.
%                   * '-niml' also implicitly means '-NN 123'.
%                     If you DON'T want all 3 NN methods, then use an explicit
%                     '-NN' option AFTER the '-niml' option to choose what you want.
% 
% -both          = Output the table in XML/NIML format AND in .1D format.
%                   * You probably want to use '-prefix' with this option!
%                     Otherwise, everything is mixed together on stdout.
%                   * '-both' does NOT imply '-NN 123'; if you want all 3 NN
%                     methods with '-both', you have to explicitly use '-NN 123'.
% 
% -prefix ppp    = Write output for NN method #k to file 'ppp.NNk.1D' for k=1, 2, 3.
%                   * If '-prefix is not used, results go to standard output.
%                   * If '-niml' is used, the filename is 'ppp.NNk.niml'.
%                   * If '-niml' AND '-mask' are both used, then a compressed ASCII
%                     encoding of the mask volume is stored into file 'ppp.mask'.
%                     This string can be stored into a dataset header as an attribute
%                     with name AFNI_CLUSTSIM_MASK, and will be used in the AFNI
%                     Clusterize GUI, if present, to mask out above-threshold voxels
%                     before the clusterizing is done (which is how the mask is used
%                     here in 3dClustSim).
%                   * If the ASCII mask string is NOT stored into the statistics dataset
%                     header, then the Clusterize GUI will try to find the original
%                     mask dataset and use that instead.  If that fails, then masking
%                     won't be done in the Clusterize process.
% 
% -quiet         = Don't print out the progress reports, etc.
%                   * Put this option first to quiet most informational messages.
% 
% ------


b = [];
disp('------ AFNI 3dClustSim --------');

if nargin<2
    disp('No FWHW provided, using 6mm')
    fwhm = 6;
end
if nargin<3
    pthr = [0.01 0.005 0.001 0.0005 0.0001];%[0.02 0.01 0.005 0.002 0.001 0.0005 0.0002 0.0001];
end
if nargin<4
    athr = [0.05 0.01 0.005];
end

if isstr(maskfile)==1    
    if length(maskfile)>4 && strcmp(maskfile(end-4),'.')
        file_id = maskfile(end-3:end);
        maskfile = maskfile(1:end-4);    
    end           
    if exist([maskfile,'.img']) && exist([maskfile,'.hdr'])
        file_id = '.hdr';
    elseif exist([maskfile,'.nii']) 
        file_id = '.nii';
    else
       error('Proper maskfile not found (img/hdr or nii)!!!') 
    end
    filename = maskfile;
else
    if ~all(size(maskfile)==[91,109,91])
        error('Given mask matrix is not 91x109x91');        
    else
       maskfile(maskfile~=0)=1;
       maskfile(isnan(maskfile))=0;              
       fprintf('Given mask has %i voxels, creating tempfile\n',nnz(maskfile));
       save_nii_oma(maskfile,'cluster_size_simulation_temp');
       filename = 'cluster_size_simulation_temp.hdr';
       file_id=[];
    end
end

seed = 0;
niter=12000;



str = ['./3dClustSim -mask ',filename,file_id,' -fwhm ',num2str(fwhm),' -NN 2 -nodec -seed ',num2str(seed),' -niter ',num2str(niter),' -dxyz 2 2 2'];
str =[str,' -pthr '];
for i=1:length(pthr)
    str =[str,num2str(pthr(i)),' '];
end
str =[str,'-athr '];
for i=1:length(athr)
    str =[str,num2str(athr(i)),' '];
end

fprintf('Running 3dClustSim... ');
tic;
[a,b]=unix(str);
t=toc;

if exist('cluster_size_simulation_temp.hdr')
    delete('cluster_size_simulation_temp.hdr');
end
if exist('cluster_size_simulation_temp.img')
    delete('cluster_size_simulation_temp.img');
end
if exist('cluster_size_simulation_temp.mat')
    delete('cluster_size_simulation_temp.mat');
end

if a~=0
    b
    error('3dClustSim FAILED')
else
    fprintf('success! (duration %s)\n',sec2min(t))
end

out=b;

end


function res = sec2min(sec)

sec = round(sec);

for i=1:length(sec)
    min = floor(sec(i)/60);
    a = round(sec(i) - 60*min);    
    if a<10
        a=sprintf('%1.0f',a);
        a=['0',a];
    else
        a=sprintf('%2.0f',a);
    end    
    if i==1
        str = [num2str(min),':',a];
    else
        str = [str,', ',[num2str(min),':',a]];
    end
end

res = str;

end