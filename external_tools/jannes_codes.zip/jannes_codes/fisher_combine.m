function p = fisher_combine(p)
% Fisher's (1925) method for combination of independent p-values
% Code adapted from Bailey and Gribskov (1998)

dims = size(p);

if dims(1)==1 || dims(2)==1


    product=prod(p);
    n=length(p);
    if n<=0
        error('pfast was passed an empty array of p-values')
    elseif n==1
        p = product;
        return
    elseif product == 0
        p = 0;
        return
    else
        x = -log(product);
        t=product;
        p=product;
        for i = 1:n-1
            t = t * x / i;
            p = p + t;
        end
    end  
    
else
    
    fprintf('Fisher combine: combining %i measurements (%i values each)\n',dims(1),dims(2));
    
    for i=1:dims(1)
        
        product=prod(p(i,:));
        n=length(p(i,:));
        if n<=0
            error('pfast was passed an empty array of p-values')
        elseif n==1
            p(i,:) = product;
            return
        elseif product == 0
            p(i,:) = 0;
            return
        else
            x = -log(product);
            t=product;
            p(i,:)=product;
            for i = 1:n-1
                t = t * x / i;
                p(i,:) = p(i,:) + t;
            end
        end
        
    end
end