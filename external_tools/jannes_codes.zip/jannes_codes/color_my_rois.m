function map = color_my_rois(map,rois,sel,val)

for i = 1:length(sel)
    s=sel(i);
    a = rois(s).map;
    for j=1:size(a,1)
        map(a(j,1),a(j,2),a(j,3))=val(i);        
    end    
end