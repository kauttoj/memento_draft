function write_mricrogl_script(image,slices,savefolder)
%CREATE_MRICROGL_SCRIPTS Summary of this function goes here
%   Detailed explanation goes here

if exist(image,'file')==0
    error('image not found!')
end

slices(1)=slices(1)+0.5;
slices(end)=slices(end)-0.5;

mi=-72;
ma=109;
slices = (slices - mi)/(ma-mi);


%cd('G:\Työkansio\Nykyinen\koodit\mricron');
%cd multislice
[filepath,filename]=fileparts(image);
if isempty(filepath)
    filepath = pwd;
end
s = sprintf('%s_SCRIPT.gls',filename);
fileID = fopen(s,'w+');
s=[];
for i=1:size(slices,1)
    for j=1:size(slices,2)
        a=sprintf('%3.2f',slices(i,j));
        s=[s,a];
        %if j<size(slices,2)
        s=[s,' '];
        %end
    end
    if i<size(slices,1)
        s=[s,';'];
    end
end

fprintf(fileID,'VAR\n');
fprintf(fileID,'\ti: INTEGER;\n');
fprintf(fileID,'BEGIN;\n');
fprintf(fileID,'\tLOADIMAGE(''/scratch/braindata/kauttoj2/working/templates/MNI152_T1_1mm_brain.nii'');\n');
fprintf(fileID,'\tCOLORBARVISIBLE(false);\n');
fprintf(fileID,'\tOVERLAYLOADSMOOTH(true);\n');
fprintf(fileID,'\tOVERLAYLOAD(''%s'');\n',[filepath,filesep,image]);
fprintf(fileID,'\tOVERLAYTRANSPARENCYONBACKGROUND(10);\n');
fprintf(fileID,'\tMOSAIC(''L+ H 0.3 V 0.300 A %s'');\n',s);
fprintf(fileID,'\tSAVEBMP(''%s%s%s_SLICES.png'');\n',savefolder,filesep,filename);
fprintf(fileID,'END.\n');

fclose(fileID);

end

