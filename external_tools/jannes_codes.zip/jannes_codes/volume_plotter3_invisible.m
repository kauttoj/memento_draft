function handle = volume_plotter3_invisible(mat,timecourse,kumpi,tit,volumetype,colormapp)

% INPUT:
% mat = 3D activation map
% mask = 3D mask that lies under our activation map (optional)
% tit = title for image (optional)

% This function uses MNI 2mm anatomical image with dimensions 91x109x91

% Janne K, 2013


% path to templates (change these)
% if exist('/scratch/braindata/kauttoj2/working/templates/','dir')
%     templa = '/scratch/braindata/kauttoj2/working/templates/';
% elseif exist('triton/becs/scratch/braindata/kauttoj2/working/templates/','dir')
%     templa = 'triton/becs/scratch/braindata/kauttoj2/working/templates/';
% else
%     error('Cannot find templates');
% end

% [x,y,z]=ind2sub(size(mat),find(mat == max(mat(:))))
% mat(x,y,z) = 1000;

if nargin<6
    colormapp = colormap('Autumn');
    if nargin<5    
        volumetype = 1;
        if nargin<4
            tit = '';    
        end        
    end
end

T1_type = 1;

%hasmask=0;
% if nargin>1
%     if exist('mask','var') && ~isempty(mask)
%         hasmask=1;
%         if ~all(size(mat)==size(mask))
%             error('Image and mask must have same dimensions');
%         end
%     end
% end

%nii = load_nii('/scratch/braindata/kauttoj2/working/templates/MNI152_T1_2mm.nii');
factor = 1;
if volumetype == 1
    if T1_type==1
        
        load('MNI_T1_1mm');
        T1 = MNI_T1_1mm;%nii.img;
        
        %load('MNI_T1_1mm_mask');
        load('edge_slices_T1_1mm');
        %T1_mask = MNI_T1_1mm_mask;%nii.img;
        
        x_slicess = x_slice_1mm;
        y_slicess = y_slice_1mm;
        z_slicess = z_slice_1mm;
        
    else
        load('MNI_T1_2mm');
        T1 = MNI_T1_2mm;%nii.img;
        
        %load('MNI_T1_2mm_mask');
        load('edge_slices_T1_2mm');
        
        x_slicess = x_slice_2mm;
        y_slicess = y_slice_2mm;
        z_slicess = z_slice_2mm;
        
    end
    
    
    
    if ~all(size(mat)==size(T1))
        %error('Feature not yet available :)');
        
        s1 = size(mat);
        s2 = size(T1);
        
        a1 = s2(1)/s1(1);
        a2 = s2(2)/s1(2);
        a3 = s2(3)/s1(3);
        if abs(rem(a1,1)) + abs(rem(a2,1)) + abs(rem(a3,1)) > 100*eps || abs(a1-a2) + abs(a2-a3) > 10*eps
            error('T1 image size must be multiple of activation image');
        end
        
        factor = round(a1);
        
    end
    
end

if kumpi==1
    
    z_min = 22/91;
    z_max = 72/91;
    NSlices = 20;
    
    Z_mat = round(linspace(z_min,z_max,NSlices-4)*size(mat,3));
    
    %Z_mat(5) = 39;
    
    Z_T1 = Z_mat*factor;%round(linspace(z_min,z_max,NSlices)*size(T1,3));
        
    rows = 5;%ceil(sqrt(NSlices));
    cols = 4;%ceil(sqrt(NSlices));
    
    handle = figure('Position',[20,20,900,1000],'Name',tit);%,'visible','off');
    
elseif kumpi==2
    
    rows = 1;%ceil(sqrt(NSlices));
    cols = 3;%ceil(sqrt(NSlices));
    
    handle = figure('Position',[20,20,900,430],'Name',tit);%,'visible','off');
end




% T1_x  = 1-single(squeeze(sum(T1_mask,1))>0);
% T1_y = 1-single(squeeze(sum(T1_mask,2))>0);
% T1_z = 1-single(squeeze(sum(T1_mask,3))>0);

% T1_x = squeeze(T1(ceil(size(T1,1)/2)+3,:,:));
% T1_y = squeeze(T1(:,ceil(size(T1,2)/2)-3,:));
% T1_z = squeeze(T1(:,:,ceil(size(T1,3)/2)-5));



if ~(length(unique(mat(:)))==2)
    
    if kumpi==2
        
        annotation('textbox',[0.1 0.85 0.8 0.05],'string',tit,'FontSize',14,'HorizontalAlignment','center','VerticalAlignment','middle','EdgeColor','none')
        
        
        T1_x = x_slicess;
        T1_y = y_slicess;
        T1_z = z_slicess;
        
        a=single(mat>0);
        %a(x,y,z)=1000;
        mat_x = squeeze(sum(a,1));
        mat_y = squeeze(sum(a,2));
        mat_z = squeeze(sum(a,3));
        
        disp('Plotting cumulative activation maps');
        
        i=0;
        val = [mat_x(:);mat_y(:);mat_z(:)];
        val(val==0)=[];
        mi = min(val);
        ma = max(val);
        map = flipud(colormap('gray'));
        L = size(map,1);
        lim = linspace(mi-eps,ma+eps,L+1);
        
        custom_subplot(rows,cols,i+1);
        T1_slice = flipud((mat2gray(T1_x))');
        siz = size(T1_slice);
        siz = siz(1:2);
        imshow(T1_slice,'InitialMagnification','fit');
        temp = zeros([siz,3]);
        hold on;
        for j=1:L
            mat_slice = flipud(mat_x');
            mat_slice(mat_slice>lim(j+1) | mat_slice<lim(j))=0;
            mat_slice = (mat_slice>0);
            
            temp(:,:,1)=upsample(mat_slice*map(j,1),factor);
            temp(:,:,2)=upsample(mat_slice*map(j,2),factor);
            temp(:,:,3)=upsample(mat_slice*map(j,3),factor);
            h = imshow(temp, 'InitialMagnification','fit');
            set(h, 'AlphaData', upsample(mat_slice,factor));
        end
        %title('Summed activation');%['z = ',num2str(Z_mat(i)),'/',num2str(size(mat,3)),' (',num2str(aa),')']);
        freezeColors;
        set(gca,'YTick',[]);
        set(gca,'XTick',[]);
        hold off;
        
        custom_subplot(rows,cols,i+2);
        T1_slice = flipud(mat2gray(T1_y)');
        siz = size(T1_slice);
        siz = siz(1:2);
        imshow(T1_slice,'InitialMagnification','fit');
        temp = zeros([siz,3]);
        hold on;
        for j=1:L
            mat_slice = flipud(mat_y');
            mat_slice(mat_slice>lim(j+1) | mat_slice<lim(j))=0;
            mat_slice = (mat_slice>0);
            temp(:,:,1)=upsample(mat_slice*map(j,1),factor);
            temp(:,:,2)=upsample(mat_slice*map(j,2),factor);
            temp(:,:,3)=upsample(mat_slice*map(j,3),factor);
            h = imshow(temp, 'InitialMagnification','fit');
            set(h, 'AlphaData', upsample(mat_slice,factor));
        end
        %title('summed activation');%['z = ',num2str(Z_mat(i)),'/',num2str(size(mat,3)),' (',num2str(aa),')']);
        freezeColors;
        set(gca,'YTick',[]);
        set(gca,'XTick',[]);
        hold off;
        
        custom_subplot(rows,cols,i+3);
        T1_slice = (mat2gray(T1_z));
        siz = size(T1_slice);
        siz = siz(1:2);
        imshow(T1_slice,'InitialMagnification','fit');
        temp = zeros([siz,3]);
        hold on;
        for j=1:L
            mat_slice = (mat_z);
            mat_slice(mat_slice>lim(j+1) | mat_slice<lim(j))=0;
            mat_slice = (mat_slice>0);
            temp(:,:,1)=upsample(mat_slice*map(j,1),factor);
            temp(:,:,2)=upsample(mat_slice*map(j,2),factor);
            temp(:,:,3)=upsample(mat_slice*map(j,3),factor);
            h = imshow(temp, 'InitialMagnification','fit');
            set(h, 'AlphaData', upsample(mat_slice,factor));
        end
        %title('summed activation');%['z = ',num2str(Z_mat(i)),'/',num2str(size(mat,3)),' (',num2str(aa),')']);
        freezeColors;
        set(gca,'YTick',[]);
        set(gca,'XTick',[]);
        hold off;
        
    elseif kumpi==1
        
        annotation('textbox',[0.1 0.94 0.8 0.05],'string',tit,'FontSize',14,'HorizontalAlignment','center','VerticalAlignment','middle','EdgeColor','none');
        
        val = mat(:);
        val(val==0)=[];
        mi = min(val);
        ma = max(val);
        
        map = colormapp;%colormap('Autumn');
        %map_orig = map;
        L = size(map,1);
        lim = linspace(mi-eps,ma+eps,L+1);
        siz = size(mat);
        siz = siz(1:2);
        
        custom_subplot(rows,cols,1:4);hold on;
        
        plot(timecourse{1},timecourse{2});
        plot(timecourse{3},timecourse{4},'r');
        plot(timecourse{5},timecourse{6},'r');
        %set(gca,'XTick',[]);
        set(gca,'XAxisLocation','top');
        %xlabel('Time (s)','FontSize',14);
        %ylabel('Timecourse','FontSize',12);
        box on;
        set(gca, 'LineWidth', 1.2)
        axis tight;
        
        NSlices = NSlices - 4;
        for i=1:NSlices
            
            disp(['Plotting map slice ' num2str(i) '/' num2str(NSlices)]);
            
            custom_subplot(rows,cols,i+4);
            
            if volumetype == 1
                T1_slice = (mat2gray((squeeze(T1(:,:,Z_T1(i))))));
                imshow(T1_slice,'InitialMagnification','fit');
            end
            
            temp = zeros([factor*siz,3]);
            hold on;
            
            %         if hasmask
            %             mask_slice = squeeze(mask(:,:,Z_mat(i)));
            %
            %             temp(:,:,3)=mask_slice;
            %
            %             h = imshow(temp, 'InitialMagnification','fit');
            %             set(h, 'AlphaData', mask_slice);
            %         end
            aa = 0;
            %fprintf('slice %i, voxel in colorlevel: ',i);
            for j=1:L
                
                mat_slice = (squeeze(mat(:,:,Z_mat(i))));
                mat_slice(mat_slice>lim(j+1) | mat_slice<lim(j))=0;
                mat_slice = (mat_slice>0);
             %   fprintf('%i...',nnz(mat_slice));
                
                temp(:,:,1)=upsample(mat_slice*map(j,1),factor);
                temp(:,:,2)=upsample(mat_slice*map(j,2),factor);
                temp(:,:,3)=upsample(mat_slice*map(j,3),factor);
                
                h = imshow(temp, 'InitialMagnification','fit');
                set(h, 'AlphaData', upsample(mat_slice,factor));
                aa = aa + nnz(mat_slice);
            end
            %fprintf('\n');
            
            title(['z = ',num2str(Z_mat(i)),'/',num2str(size(mat,3))]);%,' (',num2str(aa),')']);
            set(gca,'YTick',[]);
            set(gca,'XTick',[]);
            box on;
            freezeColors;
            hold off;
        end
        
        %ax = axes('Position', [0.05 0.3 0.9 0.4], 'Visible', 'off');
        %colorbar ('FontSize',12);
        %set(ax,'CLim',[mi,ma],'YTick',linspace(mi,ma,10));
        colormap(map);
        
        
        
    end
    
    
else
    
    %a = sort(unique(mat(:)));
    
    for i=1:NSlices
        
        disp(['Plotting mask slice ' num2str(i) '/' num2str(NSlices)]);
        
        custom_subplot(rows,cols,i);
        mat_slice = (squeeze(mat(:,:,Z_mat(i))));
        if volumetype == 1
            T1_slice = (mat2gray((squeeze(T1(:,:,Z_T1(i))))));        
            img = imoverlay(T1_slice,upsample(mat_slice,factor),[1 0 0]);
            imshow(img, 'InitialMagnification', 'fit');
        else
            imshow(upsample(img,factor), 'InitialMagnification', 'fit');
        end
        
        title(['z = ',num2str(Z_mat(i)),'/',num2str(size(mat,3))]);
        freezeColors;
        box on;
        
    end
    
    %     val = mat(:);
    %     val(val==0)=[];
    
end

% scale_subplots(1.12,[-0.05,-0.05])
%
% figure;
% plot(sort(val));
% xlabel('value number');
% ylabel('Z-score');
% axis tight;


%%% oma koodi loppuu tähän

function out = imoverlay(in, mask, color)
%IMOVERLAY Create a mask-based image overlay.
%   OUT = IMOVERLAY(IN, MASK, COLOR) takes an input image, IN, and a binary
%   image, MASK, and produces an output image whose pixels in the MASK
%   locations have the specified COLOR.
%
%   IN should be a grayscale or an RGB image of class uint8, uint16, int16,
%   logical, double, or single.  If IN is double or single, it should be in
%   the range [0, 1].  If it is not in that range, you might want to use
%   mat2gray to scale it into that range.
%
%   MASK should be a two-dimensional logical matrix.
%
%   COLOR should be a 1-by-3 vector of values in the range [0, 1].  [0 0 0]
%   is black, and [1 1 1] is white.
%
%   OUT is a uint8 RGB image.
%
%   Examples
%   --------
%   Overlay edge detection result in green over the original image.
%       
%       I = imread('cameraman.tif');
%       bw = edge(I, 'canny');
%       rgb = imoverlay(I, bw, [0 1 0]);
%       imshow(rgb)
%
%   Treating the output of peaks as an image, overlay the values greater than
%   7 in red.  The output of peaks is not in the usual grayscale image range
%   of [0, 1], so use mat2gray to scale it.
%
%       I = peaks;
%       mask = I > 7;
%       rgb = imoverlay(mat2gray(I), mask, [1 0 0]);
%       imshow(rgb, 'InitialMagnification', 'fit')

%   Steven L. Eddins
%   Copyright 2006-2012 The MathWorks, Inc.

% If the user doesn't specify the color, use white.
DEFAULT_COLOR = [1 1 1];
if nargin < 3
    color = DEFAULT_COLOR;
end

% Force the 2nd input to be logical.
mask = (mask ~= 0);

% Make the uint8 the working data class.  The output is also uint8.
in_uint8 = im2uint8(in);
color_uint8 = im2uint8(color);

% Initialize the red, green, and blue output channels.
if ndims(in_uint8) == 2
    % Input is grayscale.  Initialize all output channels the same.
    out_red   = in_uint8;
    out_green = in_uint8;
    out_blue  = in_uint8;
else
    % Input is RGB truecolor.
    out_red   = in_uint8(:,:,1);
    out_green = in_uint8(:,:,2);
    out_blue  = in_uint8(:,:,3);
end

% Replace output channel values in the mask locations with the appropriate
% color value.
out_red(mask)   = color_uint8(1);
out_green(mask) = color_uint8(2);
out_blue(mask)  = color_uint8(3);

% Form an RGB truecolor image by concatenating the channel matrices along
% the third dimension.
out = cat(3, out_red, out_green, out_blue);

function new_img = upsample(img,factor)

if factor == 1
    new_img = img;
else
    rows = size(img,1);
    cols = size(img,2);
    layers = size(img,3);
    if layers > 1
        new_img = zeros(rows*factor,cols*factor,layers);
        a = (1:factor:(rows*factor - 1));
        b = (1:factor:(cols*factor - 1));
        for l = 1:layers
            new_img(a,b,l)=img;
            for k=1:(factor-1),
                new_img(a,b,l)=img;
                new_img(a + k,b + k,l)=img;
                new_img(a,b + k,l)=img;
                new_img(a+k,b,l)=img;
            end
        end
    else
        new_img = zeros(rows*factor,cols*factor);
        a = (1:factor:(rows*factor - 1));
        b = (1:factor:(cols*factor - 1));
        new_img(a,b)=img;
        for k=1:(factor-1),
            new_img(a,b)=img;
            new_img(a + k,b + k)=img;
            new_img(a,b + k)=img;
            new_img(a+k,b)=img;
        end
    end
end



function freezeColors(varargin)
% freezeColors  Lock colors of plot, enabling multiple colormaps per figure. (v2.3)
%
%   Problem: There is only one colormap per figure. This function provides
%       an easy solution when plots using different colomaps are desired
%       in the same figure.
%
%   freezeColors freezes the colors of graphics objects in the current axis so
%       that subsequent changes to the colormap (or caxis) will not change the
%       colors of these objects. freezeColors works on any graphics object
%       with CData in indexed-color mode: surfaces, images, scattergroups,
%       bargroups, patches, etc. It works by converting CData to true-color rgb
%       based on the colormap active at the time freezeColors is called.
%
%   The original indexed color data is saved, and can be restored using
%       unfreezeColors, making the plot once again subject to the colormap and
%       caxis.
%

appdatacode = 'JRI__freezeColorsData';

[h, nancolor] = checkArgs(varargin);

%gather all children with scaled or indexed CData
cdatah = getCDataHandles(h);

%current colormap
cmap = colormap;
nColors = size(cmap,1);
cax = caxis;

% convert object color indexes into colormap to true-color data using
%  current colormap
for hh = cdatah',
    g = get(hh);
    
    %preserve parent axis clim
    parentAx = getParentAxes(hh);
    originalClim = get(parentAx, 'clim');
    
    %   Note: Special handling of patches: For some reason, setting
    %   cdata on patches created by bar() yields an error,
    %   so instead we'll set facevertexcdata instead for patches.
    if ~strcmp(g.Type,'patch'),
        cdata = g.CData;
    else
        cdata = g.FaceVertexCData;
    end
    
    %get cdata mapping (most objects (except scattergroup) have it)
    if isfield(g,'CDataMapping'),
        scalemode = g.CDataMapping;
    else
        scalemode = 'scaled';
    end
    
    %save original indexed data for use with unfreezeColors
    siz = size(cdata);
    setappdata(hh, appdatacode, {cdata scalemode});
    
    %convert cdata to indexes into colormap
    if strcmp(scalemode,'scaled'),
        %4/19/06 JRI, Accommodate scaled display of integer cdata:
        %       in MATLAB, uint * double = uint, so must coerce cdata to double
        %       Thanks to O Yamashita for pointing this need out
        idx = ceil( (double(cdata) - cax(1)) / (cax(2)-cax(1)) * nColors);
    else %direct mapping
        idx = cdata;
        %10/8/09 in case direct data is non-int (e.g. image;freezeColors)
        % (Floor mimics how matlab converts data into colormap index.)
        % Thanks to D Armyr for the catch
        idx = floor(idx);
    end
    
    %clamp to [1, nColors]
    idx(idx<1) = 1;
    idx(idx>nColors) = nColors;
    
    %handle nans in idx
    nanmask = isnan(idx);
    idx(nanmask)=1; %temporarily replace w/ a valid colormap index
    
    %make true-color data--using current colormap
    realcolor = zeros(siz);
    for i = 1:3,
        c = cmap(idx,i);
        c = reshape(c,siz);
        c(nanmask) = nancolor(i); %restore Nan (or nancolor if specified)
        realcolor(:,:,i) = c;
    end
    
    %apply new true-color color data
    
    %true-color is not supported in painters renderer, so switch out of that
    if strcmp(get(gcf,'renderer'), 'painters'),
        set(gcf,'renderer','zbuffer');
    end
    
    %replace original CData with true-color data
    if ~strcmp(g.Type,'patch'),
        set(hh,'CData',realcolor);
    else
        set(hh,'faceVertexCData',permute(realcolor,[1 3 2]))
    end
    
    %restore clim (so colorbar will show correct limits)
    if ~isempty(parentAx),
        set(parentAx,'clim',originalClim)
    end
    
end %loop on indexed-color objects


% ============================================================================ %
% Local functions

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% getCDataHandles -- get handles of all descendents with indexed CData
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function hout = getCDataHandles(h)
% getCDataHandles  Find all objects with indexed CData

%recursively descend object tree, finding objects with indexed CData
% An exception: don't include children of objects that themselves have CData:
%   for example, scattergroups are non-standard hggroups, with CData. Changing
%   such a group's CData automatically changes the CData of its children,
%   (as well as the children's handles), so there's no need to act on them.

error(nargchk(1,1,nargin,'struct'))

hout = [];
if isempty(h),return;end

ch = get(h,'children');
for hh = ch'
    g = get(hh);
    if isfield(g,'CData'),     %does object have CData?
        %is it indexed/scaled?
        if ~isempty(g.CData) && isnumeric(g.CData) && size(g.CData,3)==1,
            hout = [hout; hh]; %#ok<AGROW> %yes, add to list
        end
    else %no CData, see if object has any interesting children
        hout = [hout; getCDataHandles(hh)]; %#ok<AGROW>
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% getParentAxes -- return handle of axes object to which a given object belongs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function hAx = getParentAxes(h)
% getParentAxes  Return enclosing axes of a given object (could be self)

error(nargchk(1,1,nargin,'struct'))
%object itself may be an axis
if strcmp(get(h,'type'),'axes'),
    hAx = h;
    return
end

parent = get(h,'parent');
if (strcmp(get(parent,'type'), 'axes')),
    hAx = parent;
else
    hAx = getParentAxes(parent);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% checkArgs -- Validate input arguments
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [h, nancolor] = checkArgs(args)
% checkArgs  Validate input arguments to freezeColors

nargs = length(args);
error(nargchk(0,3,nargs,'struct'))

%grab handle from first argument if we have an odd number of arguments
if mod(nargs,2),
    h = args{1};
    if ~ishandle(h),
        error('JRI:freezeColors:checkArgs:invalidHandle',...
            'The first argument must be a valid graphics handle (to an axis)')
    end
    % 4/2010 check if object to be frozen is a colorbar
    if strcmp(get(h,'Tag'),'Colorbar'),
        if ~exist('cbfreeze.m'),
            warning('JRI:freezeColors:checkArgs:cannotFreezeColorbar',...
                ['You seem to be attempting to freeze a colorbar. This no longer'...
                'works. Please read the help for freezeColors for the solution.'])
        else
            cbfreeze(h);
            return
        end
    end
    args{1} = [];
    nargs = nargs-1;
else
    h = gca;
end

%set nancolor if that option was specified
nancolor = [nan nan nan];
if nargs == 2,
    if strcmpi(args{end-1},'nancolor'),
        nancolor = args{end};
        if ~all(size(nancolor)==[1 3]),
            error('JRI:freezeColors:checkArgs:badColorArgument',...
                'nancolor must be [r g b] vector');
        end
        nancolor(nancolor>1) = 1; nancolor(nancolor<0) = 0;
    else
        error('JRI:freezeColors:checkArgs:unrecognizedOption',...
            'Unrecognized option (%s). Only ''nancolor'' is valid.',args{end-1})
    end
end





