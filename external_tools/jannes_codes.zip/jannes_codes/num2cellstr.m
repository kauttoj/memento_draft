function res = num2cellstr(data)

res = [];

for i=1:length(data)
    res{i}=num2str(data(i));
end



end