function nodes2nii(mask,rois,cluster,name)
%NODES2NII Summary of this function goes here
%   Detailed explanation goes here

A = 0*mask;
for k=1:length(rois)
    map = rois(k).map;
    for i=1:size(map,1)
        A(map(i,1),map(i,2),map(i,3))=cluster(k);
    end
end
A = A.*mask;
save_nii_oma(A,[name,'.nii']);

a=unique(A(:));
a(a==0)=[];

k=0;
for b=a'
    k=k+1;
    B = 0*A;
    B(A==b)=1;
    save_nii_oma(B,sprintf('%s_cluster_%i.nii',name,k));
end

end

