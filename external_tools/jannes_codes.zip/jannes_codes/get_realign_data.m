function res = get_realign_data()

    in = dir(pwd);
    L = length(in);
    
    k=0;
    for i=1:L,
       
        if in(i).isdir==0
           a = in(i).name;
           if strcmp('.txt',a((end-3):end))
               k=k+1;
               if k>1
                   error('Multiple text files!');
               end
                delimiterIn = ' ';
                headerlinesIn = 0;
                data = importdata(a,delimiterIn,headerlinesIn);              
           end
        end        
    end

    res = data;
    
    
end