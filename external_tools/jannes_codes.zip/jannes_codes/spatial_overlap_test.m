function pval = spatial_overlap_test(map1,map2,iterations)
%SPATIAL_OVERLAP_TEST Summary of this function goes here
%   Detailed explanation goes here

if nargin==0
   
    map1 = [0,0,0,0,0;...
            0,1,1,0,0;...
            0,1,1,0,0;...
            0,1,1,0,0;...
            0,0,0,0,0];
    map1 = map1 + 0.05*rand(5,5);
        
%     map2 = [0,0,0,0,0;...
%             1,1,0.1,0,0;...
%             1,1,0.2,0,0;...
%             1,1,0.3,0,0;...
%             0,0,0,0,0];    
        
    map2 = [0,0,0,1,1;...
            0,0,0,0,1;...
            0,0,0,0,0;...
            0,0,0,0,0;...
            0,0,0,0,0];      
           
    map2 = map2 + 0.05*rand(5,5);
        
    iterations = 10000;
    
end


nulvals=zeros(1,iterations);

map1=map1(:);
map2=map2(:);

if min(map1)<0 || max(map1)>1
    error('Not a probability (map1)')
end
if min(map2)<0 || max(map2)>1
    error('Not a probability (map2)')
end

if mean(map1)<0.4 && mean(map2)<0.4
    map1=1-map1;
    map2=1-map2;    
    warning('Probablity map direction switched (positive tail test)')
end

N=length(map1);

val = sum(map1.*map2)/N;

dispind = linspace(iterations/10,iterations*9/10,9);

fprintf('Starting iterations');
k=1;
for i=1:iterations
    
    if k<10 && i==dispind(k)
       fprintf('...%i/10',k);
       k=k+1;
    end
    ind = randperm(N);
    map1=map1(ind);
    nulvals(i)=sum(map1.*map2)/N;
    
end
fprintf('done!\n');

if length(unique(nulvals))<iterations/2
    warning('null-distribution has lots of same values!')
end  

pval = nnz(nulvals>val)/iterations;

end

