function [new_data,cutpoints,means,old_data] = ts2symbolic(old_data,symbols,method)
%TS2SYMBOLIC Summary of this function goes here
%   Detailed explanation goes here

if mod(symbols,2)==0
    symbols = symbols + 1;
end
maxval = floor(symbols/2);

N = size(old_data,1);
T = size(old_data,2);

fprintf('Data contains %i timeseries with length %i\n',N,T);

old_data = zscore(old_data,0,2);
new_data = zeros(size(old_data));

if strcmp(method,'simple')

    val=sort(old_data(:),'Ascend');
    cutpoints = linspace(1,T*N,symbols+1);    
    cutpoints = round(cutpoints);
    
    for i=1:(length(cutpoints)-1)
       means(i) = median(val(cutpoints(i):cutpoints(i+1)));
    end
    
    cutpoints = cutpoints(2:end-1);
    
    cutpoints = val(cutpoints);
            
    for i=1:maxval
        new_data(old_data<cutpoints(maxval - i + 1))=-i;        
        new_data(old_data>cutpoints(maxval + i))=i;  
    end      
    
elseif strcmp(method,'optimal')

    cutpoints = [];
    means = [];

end


