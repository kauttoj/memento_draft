function compute_SPM_tstats(files,type,min_size,pval)
% USAGE: compute_SPM_tstats(files,type,min_size,pval)
%   files = nii or img/hdr files for t-statistics
%   type = ''FDR'' or ''FWE'' (default = FWE)
%   min_size = minimum cluster size (defaut = 5)
%   pval = p-value threshold (default = 0.05)
if nargin<2
    type = 'FDR';
    min_size=5;
end
     
if ~strcmp(type,'FDR') && ~strcmp(type,'FWE') 
    error('Correction method must be ''FWE'' or ''FDR''');
end

if nargin<3
    min_size=5;
end

if nargin<4
    pval = 0.05;
end

if min_size<0 || min_size>100000
   error('Cluster min. size must be >0 and <100000');
end

load('/triton/becs/scratch/braindata/kauttoj2/code/jannes_codes/SPM_2nd_level_ttest_batch.mat');

%batch = matlabbatch;
if isempty(files)
    fprintf('No files, searching folder...')
   d1 = dir('*.img');
   d2 = dir('*.nii');
   
   k=0;
   for i=1:length(d1)
       k=k+1;
       files{k}=[pwd,filesep,d1(i).name];
   end
   for i=1:length(d2)
       k=k+1;
       files{k}=[pwd,filesep,d2(i).name];              
   end            
   
   if k==0
       error('No files given or found');
   else
       fprintf('No files given, using %i img/nii files in folder\n',length(files));
   end
   
   err=0;
   for i=1:length(files)
      if ~isempty(strfind(files{i},'ResMS')) || ~isempty(strfind(files{i},'beta_')) || ~isempty(strfind(files{i},'spmT_'))
          err=1;
          break;
      end
   end
   
   if err==1
      warning('Found files contain possible SPM resultmaps!! Press any key to continue anyway');
      pause(); 
   end
   
end

N=length(files);

mkdir SPM_stats
matlabbatch{1}.spm.stats.factorial_design.dir{1} = [pwd,filesep,'SPM_stats/'];

for i=1:N
    
    %old_scan = matlabbatch{1}.spm.stats.factorial_design.des.t1.scans{i};
    
    %new_scan = [old_scan(1:k(1)),'sub0',num2str(i),old_scan((k(1)+7):end)];            
    
    new_scan = files{i};
    
    if ~exist(new_scan,'file')
        new_scan = which(new_scan);
    end        
    
    if ~exist(new_scan,'file')
        error('file not found:\n%s\n',new_scan);
    end
    
    nii=load_nii(new_scan);
    N_nan=nnz(isnan(nii.img));
    %N_zero = nnz(nii.img==0);
    
    if N_nan>0            
        fprintf('Map %i: implicit mask type is NaN, mask size %i voxels\n',i,nnz(~isnan(nii.img)));
    else
        fprintf('Map %i: implicit mask type is ZERO, mask size %i voxels\n',i,nnz(~(nii.img==0)));
    end
    
    new_scan = [new_scan,',1'];
    
    matlabbatch{1}.spm.stats.factorial_design.des.t1.scans{i,1}=new_scan;
    
end

fprintf('Output folder:%s\n',matlabbatch{1}.spm.stats.factorial_design.dir{1});

%clear matlabbatch

if strcmp(type,'FDR')
    
    matlabbatch{4}.spm.stats.results.conspec.threshdesc='FDR';
    
elseif strcmp(type,'FWE')
    
    matlabbatch{4}.spm.stats.results.conspec.threshdesc='FWE';
    
else
   error('!!!!!') 
end

matlabbatch{4}.spm.stats.results.conspec.thresh=pval;
matlabbatch{4}.spm.stats.results.conspec.extent = min_size;

%save('matlabbatch.mat','matlabbatch');
fprintf('Running SPM batch...\n');
spm('defaults','fmri');
spm_jobman('initcfg');
spm_jobman('run',matlabbatch);
