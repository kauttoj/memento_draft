function save_volume_slices_old(mat,filename,tit)

% INPUT:
% mat = 3D activation map
% mask = 3D mask that lies under our activation map (optional)
% tit = title for image (optional)

% This function uses MNI 2mm anatomical image with dimensions 91x109x91

% Janne K, 2013


% path to templates (change these)
% if exist('/scratch/braindata/kauttoj2/working/templates/','dir')
%     templa = '/scratch/braindata/kauttoj2/working/templates/';
% elseif exist('triton/becs/scratch/braindata/kauttoj2/working/templates/','dir')
%     templa = 'triton/becs/scratch/braindata/kauttoj2/working/templates/';
% else
%     error('Cannot find templates');
% end

% [x,y,z]=ind2sub(size(mat),find(mat == max(mat(:))))
% mat(x,y,z) = 1000;

has_range = 0;    
colormapp = grey(256);
volumetype = 1;
T1_type = 1;

%hasmask=0;
% if nargin>1
%     if exist('mask','var') && ~isempty(mask)
%         hasmask=1;
%         if ~all(size(mat)==size(mask))
%             error('Image and mask must have same dimensions');
%         end
%     end
% end

%nii = load_nii('/scratch/braindata/kauttoj2/working/templates/MNI152_T1_2mm.nii');
factor = 1;
if volumetype == 1
    if T1_type==1
        
        load('MNI_T1_1mm');
        T1 = MNI_T1_1mm;%nii.img;
        
        %load('MNI_T1_1mm_mask');
        load('edge_slices_T1_1mm');
        %T1_mask = MNI_T1_1mm_mask;%nii.img;
        
        x_slicess = x_slice_1mm;
        y_slicess = y_slice_1mm;
        z_slicess = z_slice_1mm;
        
    else
        load('MNI_T1_2mm');
        T1 = MNI_T1_2mm;%nii.img;
        
        %load('MNI_T1_1mm_mask');
        load('edge_slices_T1_2mm');
        
        x_slicess = x_slice_2mm;
        y_slicess = y_slice_2mm;
        z_slicess = z_slice_2mm;
        
    end       
    
    if ~all(size(mat)==size(T1))
        %error('Feature not yet available :)');
        
        s1 = size(mat);
        s2 = size(T1);
        
        a1 = s2(1)/s1(1);
        a2 = s2(2)/s1(2);
        a3 = s2(3)/s1(3);
        if abs(a1-a2) + abs(a2-a3) > 10*eps
           error('T1 image size must be a multiple of an activation image (only one scale factor)');
        end
        a = abs(round(a1)-a1);
        if a > 100*eps
            warning('Using image interpolation (scale factor NOT an integer)');
        end
        
        if a < 1e-12
            factor = round(a1);
        else
            factor = a1;
        end
        
    end
    
end



%B = imresize(A, scale)

if kumpi==1
    
    N_colors = size(colormapp,1);
    N_graycolors = 2^13;
    graymap = (gray(N_graycolors));
    T1 = double(T1);
    mi=min(T1(:));
    ma=max(T1(:));
    T1 = T1 - mi + 10*eps;
    T1 = ceil(N_graycolors*T1/(ma-mi));
    
    mat = double(mat);
    
    mat_zeros = (mat == 0 | isnan(mat));
    val = mat(:);
    val(val==0 | isnan(val))=[];
    ma = max(val);
    mi = min(val);
    
    
    if has_range
        if  ~isempty(val) && (mi<range_limits(1) || ma>range_limits(2))
            error('Outside range!');
        end
        mat = mat - range_limits(1) + 10*eps;
        mat = ceil(range_limits(2)*N_colors*mat/(range_limits(2)-range_limits(1))) + N_graycolors;
        mat(mat_zeros)=0;
        colorbar_min = range_limits(1);
        colorbar_max = range_limits(2);        
    else
        mat = mat - mi + 10*eps;
        mat = ceil(N_colors*mat/(ma-mi)) + N_graycolors;
        mat(mat_zeros)=0;
        colorbar_min = mi;
        colorbar_max = ma;
    end
    
    colorbar_ticks = round(linspace(N_graycolors+1,N_graycolors + N_colors,10));
    a = linspace(colorbar_min,colorbar_max,10);
    for i=1:length(a)
        colorbar_labels{i} = sprintf('%1.2f',a(i));
    end
    
    totalmap = [graymap;colormapp];
    
    
    z_min = 27/91;
    z_max = 72/91;
    NSlices = 16;
    
    Z_mat = round(linspace(z_min,z_max,NSlices)*size(mat,3));
    
    %Z_mat(5) = 39;
    
    Z_T1 = round(Z_mat*factor);%round(linspace(z_min,z_max,NSlices)*size(T1,3));
        
    rows = 4;%ceil(sqrt(NSlices));
    cols = 4;%ceil(sqrt(NSlices));
        
    X = 30;                  %# A3 paper size
    Y = 30;                  %# A3 paper size
    xMargin = 1;               %# left/right margins from page borders
    yMargin = 1;               %# bottom/top margins from page borders
    xSize = X - 2*xMargin;     %# figure size on paper (widht & hieght)
    ySize = Y - 2*yMargin;     %# figure size on paper (widht & hieght)
    
    handle = figure('Units','centimeters', 'Position',[5 5 xSize ySize]/2,'Name',tit,'visible','off','Menubar','none'); % 'Position',[20,20,1150,900]
    
    set(gcf, 'PaperUnits','centimeters')
    set(gcf, 'PaperSize',[X Y])
    set(gcf, 'PaperPosition',[xMargin yMargin xSize ySize])
    set(gcf, 'PaperOrientation','portrait')
    
elseif kumpi==2
        
    T1_x = x_slicess;
    T1_y = y_slicess;
    T1_z = z_slicess;
        
    a=single(mat>0);
    mat_x = squeeze(sum(a,1));
    mat_y = squeeze(sum(a,2));
    mat_z = squeeze(sum(a,3));
               
    val = [mat_x(:);mat_y(:);mat_z(:)];
    val(val==0 | isnan(val))=[];
    ma = max(val);
    N_graycolors = 2*ma;
    graymap=flipud(gray(N_graycolors));   
    
    if has_range
   
    mat_x = ceil((ma/range_limits(2))*N_graycolors*mat_x/ma);
    mat_x = imresize(mat_x,size(T1_x),'nearest');
    mat_x(T1_x==0)=N_graycolors;    
    mat_x = flipud(mat_x');
    
    mat_y = ceil((ma/range_limits(2))*N_graycolors*mat_y/ma);
    mat_y = imresize(mat_y,size(T1_y),'nearest');
    mat_y(T1_y==0)=N_graycolors;    
    mat_y=flipud(mat_y');
    
    mat_z = ceil((ma/range_limits(2))*N_graycolors*mat_z/ma);
    mat_z = imresize(mat_z,size(T1_z),'nearest');
    mat_z(T1_z==0)=N_graycolors;
    mat_z=flipud(mat_z');
    else
    mat_x = ceil(N_graycolors*mat_x/ma);
    mat_x = imresize(mat_x,size(T1_x),'nearest');
    mat_x(T1_x==0)=N_graycolors;    
    mat_x = flipud(mat_x');
    
    mat_y = ceil(N_graycolors*mat_y/ma);
    mat_y = imresize(mat_y,size(T1_y),'nearest');
    mat_y(T1_y==0)=N_graycolors;    
    mat_y=flipud(mat_y');
    
    mat_z = ceil(N_graycolors*mat_z/ma);
    mat_z = imresize(mat_z,size(T1_z),'nearest');
    mat_z(T1_z==0)=N_graycolors;
    mat_z=flipud(mat_z');        
    end
    
    rows = 1;%ceil(sqrt(NSlices));
    cols = 3;%ceil(sqrt(NSlices));
    
    colorbar_ticks = round(linspace(1,N_graycolors,10));
    colorbar_labels = round(linspace(0,ma,10));    
    
    handle = figure('PaperType','A4','Name',tit,'visible','off');%figure('Position',[20,20,920,430]
end

set(handle, 'PaperPositionMode', 'auto');
%set(handle, 'PaperType', 'A4');



% T1_x  = 1-single(squeeze(sum(T1_mask,1))>0);
% T1_y = 1-single(squeeze(sum(T1_mask,2))>0);
% T1_z = 1-single(squeeze(sum(T1_mask,3))>0);

% T1_x = squeeze(T1(ceil(size(T1,1)/2)+3,:,:));
% T1_y = squeeze(T1(:,ceil(size(T1,2)/2)-3,:));
% T1_z = squeeze(T1(:,:,ceil(size(T1,3)/2)-5));



%if ~(length(unique(mat(:)))==2)
    
    if kumpi==2
        
        annotation('textbox',[0.1 0.90 0.8 0.05],'string',tit,'FontSize',14,'HorizontalAlignment','center','VerticalAlignment','middle','EdgeColor','none')        
        
        %disp('Plotting cumulative activation maps');           
       
        custom_subplot(rows,cols,1);
        imshow(mat_x,graymap, 'InitialMagnification','fit');
        set(gca,'YTick',[]);
        set(gca,'XTick',[]);
        
        custom_subplot(rows,cols,2);
        imshow(mat_y,graymap, 'InitialMagnification','fit');
        set(gca,'YTick',[]);
        set(gca,'XTick',[]);
        
        custom_subplot(rows,cols,3);
        imshow(mat_z,graymap, 'InitialMagnification','fit');
        set(gca,'YTick',[]);
        set(gca,'XTick',[]);
        
        ax = axes('Position', [0.05 0.3 0.93 0.4], 'Visible', 'off');
        h = colorbar('FontSize',12);
        set(h, 'ylim',[1,N_graycolors]);
        set(h, 'YTick',colorbar_ticks);
        set(h,'YTickLabel',colorbar_labels);        
        
    elseif kumpi==1
        
        annotation('textbox',[0.1 0.94 0.8 0.05],'string',tit,'FontSize',12,'HorizontalAlignment','center','VerticalAlignment','middle','EdgeColor','none')        
                
        for i=1:NSlices
            
            %disp(['slice ' num2str(i) '/' num2str(NSlices)]);
            
            custom_subplot(rows,cols,i);
            
            image1 = squeeze(T1(:,:,Z_T1(i)));           
            image2 = squeeze(mat(:,:,Z_mat(i)));
            
            image2 = imresize(image2,size(image1),'nearest');
            ind = image2>0;
            image1(ind) = image2(ind);
            
            imshow(image1,totalmap, 'InitialMagnification','fit');
            
            title(['z = ',num2str(Z_mat(i)),'/',num2str(size(mat,3))],'FontSize',9);%' (',num2str(aa),')']);
            set(gca,'YTick',[]);
            set(gca,'XTick',[]);
            box on;
        end
        
        %ax = axes('Position', [0.05 0.3 0.9 0.4], 'Visible', 'off');
        %h = colorbar('FontSize',12);
        %set(h, 'ylim',(N_graycolors + [1,N_colors]));
        %set(h, 'YTick',colorbar_ticks);
        %set(h,'YTickLabel',colorbar_labels);
       
    end
    
    print(handle, '-append', '-dpsc2', filename);
    
    
%     
% else
%     
%     %a = sort(unique(mat(:)));
%             annotation('textbox',[0.1 0.94 0.8 0.05],'string',tit,'FontSize',14,'HorizontalAlignment','center','VerticalAlignment','middle','EdgeColor','none')
%  
%     
%     for i=1:NSlices
%         
%         disp(['Plotting mask slice ' num2str(i) '/' num2str(NSlices)]);
%         
%         custom_subplot(rows,cols,i);
%         mat_slice = (squeeze(mat(:,:,Z_mat(i))));
%         if volumetype == 1
%             T1_slice = (mat2gray((squeeze(T1(:,:,Z_T1(i))))));        
%             img = imoverlay(T1_slice,upsample(mat_slice,factor),[1 0 0]);
%             imshow(img, 'InitialMagnification', 'fit');
%         else
%             imshow(upsample(img,factor), 'InitialMagnification', 'fit');
%         end
%                 
%         title(['z = ',num2str(Z_mat(i)),'/',num2str(size(mat,3))]);
%             set(gca,'YTick',[]);
%             set(gca,'XTick',[]);        
%         freezeColors;
%         box on;
%         
%     end
%     
%     %     val = mat(:);
%     %     val(val==0)=[];
%     
% end

% scale_subplots(1.12,[-0.05,-0.05])
%
% figure;
% plot(sort(val));
% xlabel('value number');
% ylabel('Z-score');
% axis tight;


%%% oma koodi loppuu tähän

function out = imoverlay(in, mask, color)
%IMOVERLAY Create a mask-based image overlay.
%   OUT = IMOVERLAY(IN, MASK, COLOR) takes an input image, IN, and a binary
%   image, MASK, and produces an output image whose pixels in the MASK
%   locations have the specified COLOR.
%
%   IN should be a grayscale or an RGB image of class uint8, uint16, int16,
%   logical, double, or single.  If IN is double or single, it should be in
%   the range [0, 1].  If it is not in that range, you might want to use
%   mat2gray to scale it into that range.
%
%   MASK should be a two-dimensional logical matrix.
%
%   COLOR should be a 1-by-3 vector of values in the range [0, 1].  [0 0 0]
%   is black, and [1 1 1] is white.
%
%   OUT is a uint8 RGB image.
%
%   Examples
%   --------
%   Overlay edge detection result in green over the original image.
%       
%       I = imread('cameraman.tif');
%       bw = edge(I, 'canny');
%       rgb = imoverlay(I, bw, [0 1 0]);
%       imshow(rgb)
%
%   Treating the output of peaks as an image, overlay the values greater than
%   7 in red.  The output of peaks is not in the usual grayscale image range
%   of [0, 1], so use mat2gray to scale it.
%
%       I = peaks;
%       mask = I > 7;
%       rgb = imoverlay(mat2gray(I), mask, [1 0 0]);
%       imshow(rgb, 'InitialMagnification', 'fit')

%   Steven L. Eddins
%   Copyright 2006-2012 The MathWorks, Inc.

% If the user doesn't specify the color, use white.
DEFAULT_COLOR = [1 1 1];
if nargin < 3
    color = DEFAULT_COLOR;
end

% Force the 2nd input to be logical.
mask = (mask ~= 0);

% Make the uint8 the working data class.  The output is also uint8.
in_uint8 = im2uint8(in);
color_uint8 = im2uint8(color);

% Initialize the red, green, and blue output channels.
if ndims(in_uint8) == 2
    % Input is grayscale.  Initialize all output channels the same.
    out_red   = in_uint8;
    out_green = in_uint8;
    out_blue  = in_uint8;
else
    % Input is RGB truecolor.
    out_red   = in_uint8(:,:,1);
    out_green = in_uint8(:,:,2);
    out_blue  = in_uint8(:,:,3);
end

% Replace output channel values in the mask locations with the appropriate
% color value.
out_red(mask)   = color_uint8(1);
out_green(mask) = color_uint8(2);
out_blue(mask)  = color_uint8(3);

% Form an RGB truecolor image by concatenating the channel matrices along
% the third dimension.
out = cat(3, out_red, out_green, out_blue);


function new_img = upsample(img,factor)

if factor == 1
    new_img = img;
else
    rows = size(img,1);
    cols = size(img,2);
    layers = size(img,3);
    if layers > 1
        new_img = zeros(rows*factor,cols*factor,layers);
        a = (1:factor:(rows*factor - 1));
        b = (1:factor:(cols*factor - 1));
        for l = 1:layers
            new_img(a,b,l)=img;
            for k=1:(factor-1),
                new_img(a,b,l)=img;
                new_img(a + k,b + k,l)=img;
                new_img(a,b + k,l)=img;
                new_img(a+k,b,l)=img;
            end
        end
    else
        new_img = zeros(rows*factor,cols*factor);
        a = (1:factor:(rows*factor - 1));
        b = (1:factor:(cols*factor - 1));
        new_img(a,b)=img;
        for k=1:(factor-1),
            new_img(a,b)=img;
            new_img(a + k,b + k)=img;
            new_img(a,b + k)=img;
            new_img(a+k,b)=img;
        end
    end
end

