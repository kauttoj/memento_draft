function p_vals = compute_pvals_accurate(nulldist,vals)
% This function computes estimated p-values from empirical distribution
% non-significant p-values with p>0.05 are set to 1
% pvalues between 0.05 and 0.01 are computed directly from empirical
% distribution
% p-values with p<0.01 are estimated with generalized Pareto distribution
    
    nulldist=sort(nulldist,'ascend');
    
    p_vals = -ones(size(vals));    
    cut05 = prctile(nulldist,95);
    cut01 = prctile(nulldist,99);
    p_vals(vals<cut05)=1;
    
    L=length(nulldist);
    
    ind = find(vals>=cut05 & vals<=cut01);
    for i=ind
       p_vals(i)=nnz(nulldist>=vals(i))/L; 
    end            
    
    taildist = nulldist(nulldist>=cut01) - cut01;
    
    if length(taildist)<200
        warning('Tail has only %i values!',length(taildist));
    end
    
    paramEsts = gpfit(taildist);
    kHat      = paramEsts(1);   % Tail index parameter
    sigmaHat  = paramEsts(2);   % Scale parameter
    
    ygrid = linspace(0,1.25*max(taildist),5000);
    %tail = gppdf(ygrid,kHat,sigmaHat);
    tailcdf = gpcdf(ygrid,kHat,sigmaHat);
    tailcdf= tailcdf/tailcdf(end);
    tailcdf = 0.99 + tailcdf*0.01;
            
    ygrid = ygrid + cut01;
    
    ind = find(vals>cut01);
    for i=ind
       k=find(vals(i)>=ygrid,1,'last');
       p_vals(i)=1 - tailcdf(k);
    end
    
%     close all;
%     subplot(2,1,1);
%     [y,x] = ecdf(nulldist);
%     plot(x,y,'b');
%     hold on;
%     plot(ygrid,tailcdf,'r');
%     axis tight;
%     subplot(2,1,2);    
%     plot(x(x>=cut01),y(x>=cut01),'b');
%     hold on;
%     plot(ygrid,tailcdf,'r');
%     axis tight;    
        
    if nnz(p_vals<0)
        error('Some p-vals were omitted!')
    end
    
    %tail = 

end

