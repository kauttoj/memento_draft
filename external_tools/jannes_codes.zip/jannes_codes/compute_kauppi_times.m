function res = compute_kauppi_times(timepoints,TR,window,stepping)
% res = compute_kauppi_times(timepoints,TR,window,stepping)

M=floor( (timepoints - window)/stepping ) + 1;
res = ((0:(M-1)))*stepping*TR+TR*window/2;


end

