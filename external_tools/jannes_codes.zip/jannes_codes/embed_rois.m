function [label_id,bad_ind] = embed_rois(rois,largeatlas)
%EMBED_ROIS Summary of this function goes here
%   Detailed explanation goes here
fprintf('Embedding %i ROIs\n',length(rois))
bad_ind=[];
N=length(rois);
label_id=-ones(1,N);
for i=1:N   
    L=size(rois(i).map,1);
    id = -ones(1,L);
    for j=1:L
        id(j) = largeatlas(rois(i).map(j,1),rois(i).map(j,2),rois(i).map(j,3));
    end
    uid = unique(id);
    [a,~]=histc(id,uid);
    [a,k]=sort(a,'descend');
    if uid(k(1))==0
        warning('ROI %i outside embedding atlas',i);
        %if length(uid)<2
        bad_ind(end+1)=i;
        %else
        %    label_id(i)=uid(k(2));
        %end
    else
        label_id(i)=uid(k(1));
    end
end

fprintf('done. Total %i ROIs completely outside atlas.\n',length(bad_ind));

end

