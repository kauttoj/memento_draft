function res = universal_regressor_v5(X,Y,cfg_file)

MODEL_SIZE_LIMIT=cfg_file.maximum_model_size;
DO_PLOT=cfg_file.do_plot;
N_subjects = cfg_file.N_subjects;
good_components = cfg_file.chosen_columns;
N_components = length(good_components);
REGRESSION_TYPE = cfg_file.regression_type;

res.REGRESSION_TYPE=REGRESSION_TYPE;

T = size(Y,3);
fprintf('%i timepoints, %i subjects, %i time-series, %i regressors\n',T,N_subjects,N_components,size(X,2));

FULL_SIZE = size(X,2);

addpath('/triton/becs/scratch/braindata/kauttoj2/code/glmnet_matlab');

% Set default options.
opts.weights        =           [];
opts.alpha          =          cfg_file.alpha;
opts.nlambda        =          100;
opts.lambda_min     =            0;
opts.lambda         =           [];
opts.standardize    =         true;
opts.thresh         =         1E-4;
opts.pmax          =            MODEL_SIZE_LIMIT;
opts.pmax           =            0;
opts.exclude        =           [];
opts.penalty_factor =           [];
opts.maxit          =          100;
opts.HessianExact   =        false;
opts.type           = 'covariance';
standard_glm_opts = glmnetSet(opts);

fprintf('Centering data\n');
for i=1:FULL_SIZE
    X(:,i)=X(:,i)-mean(X(:,i));
end

for subj=1:size(Y,1)
    for comp=1:size(Y,2)
        Y(subj,comp,:)=Y(subj,comp,:)-mean(squeeze(Y(subj,comp,:)));
    end
end

X_design = X;
X_design_full = [ones(T,1),X];
X_design_pinv = pinv(X_design_full);

all_ica_ts_fitted = -ones(N_subjects,T,N_components);
all_model_order = -ones(N_subjects,N_components);
all_resp_var_expl = -ones(N_subjects,N_components);
all_design_var_expl = -ones(N_subjects,N_components);
all_has_bad_cv = -ones(N_subjects,N_components);

fprintf('Starting type ''%s'' computations\n',REGRESSION_TYPE);

tic;

if cfg_file.use_parallel == 1
    
    N_cores = feature('numCores');
    
    if N_cores<4
        error('Less than 4 cores available!')
    else
                
        if matlabpool('size')>0
            matlabpool('close');
        end
        matlabpool('open',max(2,min(cfg_file.N_cores,N_cores-1)));
        
        data.T=T;
        data.N_components=N_components;
        data.good_components=good_components;
        data.Y=Y;
        data.X_design=X_design;
        data.X_design_full=X_design_full;
        data.cfg_file=cfg_file;
        data.standard_glm_opts=standard_glm_opts;
        data.REGRESSION_TYPE=REGRESSION_TYPE;
        data.FULL_SIZE=FULL_SIZE;
        
        parfor subj=1:cfg_file.N_subjects
            tempres{subj}=parallel_first_loop(data,subj);
        end
        
        for subj=1:cfg_file.N_subjects
            all_cvres{subj}=tempres{subj}.all_cvres;
            all_chosen_features{subj}=tempres{subj}.all_chosen_features;
            all_model_order(subj,:)=tempres{subj}.all_model_order;
            all_B_vals{subj}=tempres{subj}.all_saved_betas;
            all_fit_corr(subj,:)=tempres{subj}.all_fit_corr;
            all_ica_ts_fitted(subj,:,:)=tempres{subj}.all_ica_ts_fitted;
            all_resp_var_expl(subj,:)=tempres{subj}.all_response_var_expl;
            all_design_var_expl(subj,:)=tempres{subj}.all_design_var_expl;
            all_has_bad_cv(subj,:)=tempres{subj}.all_has_bad_cv;
            
%             res.all_cvres=cvres;
%             res.all_chosen_features=chosen_features;
%             res.all_model_order=model_order;
%             res.all_saved_betas=saved_betas;
%             res.all_fit_corr=fit_corr;
%             res.all_ica_ts_fitted=ica_ts_fitted;
%             res.all_resp_var_expl=response_var_exp;
%             res.all_design_var_expl=design_var_exp;
%             res.all_has_bad_cv=has_bad_cv;
        end
        
        clear data;
        clear tempres;
        
%        matlabpool('close');
    end
else
    
    for subj = 1:N_subjects
        
        ica_ts_fitted = -ones(T,N_components);
        fit_corr = -ones(1,N_components);
        has_bad_cv = -ones(1,N_components);
        model_order=-ones(1,N_components);
        response_var_exp= -ones(1,N_components);
        design_var_exp= -ones(1,N_components);
        
        if DO_PLOT==1
            figure;hold on;title(['subject ',num2str(subj)]);
        end
        
        fprintf('Subject %i\n',subj);
        
        
        k=0;
        for i=good_components
            
            k=k+1;
            
            ica_ts = squeeze(Y(subj,i,:));            
            
            if strcmp(REGRESSION_TYPE,'PLS')
                
                [Xloadings,Yloadings,Xscores,Yscores,betaPLS,PLSPctVar,PLSmsep] = plsregress(X_design,ica_ts,MODEL_SIZE_LIMIT,'cv',cfg_file.CV_folds,'MCreps',cfg_file.MCReps);
                cvres{k}=PLSmsep;
                
                var_exp = cumsum(PLSPctVar(2,:));
                var_exp = 100*var_exp/var_exp(end);
                cv_mse = PLSmsep(2,1:end);
                
                model_order(k) = max([cfg_file.minimum_model_size,simple_pls_order(var_exp,cv_mse)]);
                
                if min(cv_mse(1:2)) < cv_mse(end)
                    has_bad_cv(k)=1;
                    fprintf('..component %i, chosen order %i (bad CV curve!)\n',i,model_order(k));
                else
                    has_bad_cv(k)=0;
                    fprintf('..component %i, chosen order %i\n',i,model_order(k));
                end
                
                if DO_PLOT==1
                    plot(0:MODEL_SIZE_LIMIT,cv_mse,'o-','Color',0.8*rand(1,3));
                    a=plot(model_order(k),cv_mse(1+model_order(k)),'rs');
                    set(get(get(a,'Annotation'),'LegendInformation'),...
                        'IconDisplayStyle','off');
                    xlabel('Model order');ylabel('CVMSE')
                    axis tight;
                end
                
                [Xloadings,Yloadings,Xscores,Yscores,betaPLS,PLSPctVar] = plsregress(X_design,ica_ts,model_order(k));
                
                yfitPLS = X_design_full*betaPLS;
                fit_corr(k)=corr2(ica_ts,yfitPLS);
                
                ica_ts_fitted(:,k)=yfitPLS;
                
                chosen_features{k}=[];
                var_exp = cumsum(PLSPctVar(2,:));
                response_var_exp(k)=var_exp(end);
                var_exp = cumsum(PLSPctVar(1,:));
                design_var_exp(k)=var_exp(end);
                
                saved_betas{k}=betaPLS;
                %X_design_saved{k}=Xscores;
                
            elseif strcmp(REGRESSION_TYPE,'glmnet')
                
                CVerr=cvglmnet(X_design,ica_ts,cfg_file.CV_folds,[],'response','gaussian',standard_glm_opts,DO_PLOT,cfg_file.MCReps);
                
                glm_opts=standard_glm_opts;
                glm_opts.lambda=CVerr.lambda_1se;
                glm_opts.nlambda=1;
                
                fit = glmnet(X_design,ica_ts,'gaussian',glm_opts);
                
                isbad=0;
                if fit.df < cfg_file.minimum_model_size
                    isbad=1;
                    if CVerr.lambda_min == CVerr.lambda_1se
                        glm_opts.pmax = cfg_file.minimum_model_size;
                        fit = glmnet(X_design,ica_ts,'gaussian',standard_glm_opts);
                        betas = fit.beta(:,find(fit.df>0,1,'first'));
                    else
                        glm_opts.lambda=CVerr.lambda_min;
                        fit = glmnet(X_design,ica_ts,'gaussian',glm_opts);
                        betas = fit.beta;
                    end
                else
                    betas = fit.beta;
                end
                
                cvres{k}=fit;
                
                chosen_feat = find(betas);
                model_order(k) = length(chosen_feat);
                
                chosen_features{k}=chosen_feat;
                
                if isbad==1
                    has_bad_cv(k)=1;
                    fprintf('..component %i, chosen features %i (bad CV curve!)\n',i,model_order(k));
                else
                    has_bad_cv(k)=0;
                    fprintf('..component %i, chosen features %i\n',i,model_order(k));
                end
                
                X_design_chosen = X_design(:,chosen_feat);
                B = glmfit(X_design_chosen,ica_ts,'normal');
                ica_ts_fitted(:,k)=B(1) + X_design_chosen*B(2:end);
                
                saved_betas{k}=B;
                
                fit_corr(k) = corr2(ica_ts_fitted(:,k),ica_ts);
                
            elseif strcmp(REGRESSION_TYPE,'elastic')
                
                [ba,fitinfo] = lasso(X_design,ica_ts,'CV',cfg_file.CV_folds,'Alpha',cfg_file.alpha,'DFmax',MODEL_SIZE_LIMIT,'MCReps',cfg_file.MCReps);
                lambdaindex = fitinfo.Index1SE;
                
                isbad = 0;
                if fitinfo.DF(lambdaindex)<cfg_file.minimum_model_size
                    isbad=1;
                    %fprintf('Component %i had bad lambda-index\n',i);
                    lambdaindex = fitinfo.IndexMinMSE;
                    if fitinfo.DF(lambdaindex)<cfg_file.minimum_model_size
                        %failed_components(end+1)=k;
                        %fprintf('Component %i failed\n',i);
                        lambdaindex=find(fitinfo.DF>0,1,'last');
                    end
                end
                
                cvres{k}=fitinfo;
                
                chosen_feat = find((ba(:,(lambdaindex))~=0));
                BB = (ba(:,(lambdaindex)));
                BB = BB(chosen_feat);
                
                model_order(k) = length(chosen_feat);
                
                if isbad==1
                    has_bad_cv(k)=1;
                    fprintf('..component %i, chosen features %i (bad CV curve!)\n',i,model_order(k));
                else
                    has_bad_cv(k)=0;
                    fprintf('..component %i, chosen features %i\n',i,model_order(k));
                end
                
                X_design_chosen = X_design(:,chosen_feat);
                
                chosen_features{k}=chosen_feat;
                
                %X_design_saved{k} = X_design_chosen;
                %X_design_saved_pinv{k} = pinv([ones(T,1),X_design_chosen]);
                
                B = glmfit(X_design_chosen,ica_ts,'normal');
                ica_ts_fitted(:,k)=B(1) + X_design_chosen*B(2:end);
                
                saved_betas{k}=B;
                
                fit_corr(k) = corr2(ica_ts_fitted(:,k),ica_ts);
                
            elseif strcmp(REGRESSION_TYPE,'simple')
                
                B = glmfit(X_design,ica_ts,'normal');
                ica_ts_fitted(:,k)=X_design_full*B;
                saved_betas{k}=B;
                
                fit_corr(k) = corr2(ica_ts_fitted(:,k),ica_ts);
                
                model_order(k)=FULL_SIZE;
                chosen_features{k}=[];
                cvres{k}=[];
                %X_design_saved{k}=[];
                
            elseif strcmp(REGRESSION_TYPE,'sRVM')
                
                [B,fitted,PARAMETER,HYPERPARAMETER]=fit_sparse_bayes(ica_ts,X_design);
                ica_ts_fitted(:,k)=fitted;
                
                fit_corr(k) = corr2(ica_ts_fitted(:,k),ica_ts);
                
                model_order(k)=nnz(B);
                chosen_features{k}=find(B);
                cvres{k}=[]; 
                
            else
                
                error('Unknown method!');
                
            end
            
        end
        %oma_legend(good_components);
        
        if max(fit_corr)>0.99
            warning('Component %i has suspiciously large correlations!',good_components(k));
        end
        
        all_cvres{subj}=cvres;
        all_chosen_features{subj}=chosen_features;
        all_model_order(subj,:)=model_order;
        all_B_vals{subj}=saved_betas;
        all_fit_corr(subj,:)=fit_corr;
        all_ica_ts_fitted(subj,:,:)=ica_ts_fitted;
        all_resp_var_expl(subj,:)=response_var_exp;
        all_design_var_expl(subj,:)=design_var_exp;
        all_has_bad_cv(subj,:)=has_bad_cv;
        
    end
end

a=toc;
fprintf('done! Elapsed time %s\n',sec2min(a));
res.part1_time = a;
res.all_fit_corr=all_fit_corr;
res.all_fitted=all_ica_ts_fitted;
res.all_design_var_expl=all_design_var_expl;
res.all_resp_var_expl=all_resp_var_expl;
res.all_B_vals=all_B_vals;
res.all_model_order=all_model_order;
res.X_design=X_design;
res.chosen_features=all_chosen_features;
res.cvres=all_cvres;
res.Y=Y;

save([cfg_file.filename,'_part1'],'res','cfg_file');

if all_has_bad_cv(1,1)>-1   
    fprintf('Expected good components based on CV results:\n')
    a = mean(all_has_bad_cv,1);
    for i=1:N_components
        if a(i)<0.25
            fprintf('%i,',good_components(i));
        end
    end
    fprintf('\n');
end

%----STATISTICAL TESTING-------

permutations = cfg_file.permutations;

if mod(T,2)==0
    LL = length(2:(T/2));
else
    LL = length(2:(ceil(T/2)));
end   

fprintf('\n');
fprintf('Starting permutations\n');

perm_ind = round(linspace(permutations/10,permutations*9/10,9));

TYPE = -1;
if strcmp(REGRESSION_TYPE,'PLS')
    TYPE = 1;
elseif strcmp(REGRESSION_TYPE,'elastic')
    TYPE = 2;
elseif strcmp(REGRESSION_TYPE,'simple')
    TYPE=3;
elseif strcmp(REGRESSION_TYPE,'glmnet')
    TYPE = 4;        
end

if strcmp(cfg_file.lasso_permutation_type,'full')
   LASSO_PERM_TYPE = 1; 
elseif strcmp(cfg_file.lasso_permutation_type,'randperm')
   LASSO_PERM_TYPE = 2;
else
    error('unknown permutation type for LASSO!')
end

glm_opts=standard_glm_opts;

apuvector = 1:FULL_SIZE;
onevector = ones(T,1);
for subj = 1:N_subjects    
    k=0;
    for i=good_components        
        k=k+1;        
        ica_ts = squeeze(Y(subj,i,:));        
        saved_coeffs{subj,k}=fft(ica_ts);        
    end
end

tic;

if cfg_file.use_parallel == 1
    
    data.N_components=N_components;
    data.N_subjects=N_subjects;
    data.permutations=permutations;
    data.LL=LL;
    data.X_design=X_design;
    data.all_model_order=all_model_order;
    data.good_components=good_components;
    data.LASSO_PERM_TYPE=LASSO_PERM_TYPE;
    data.cfg_file=cfg_file;
    data.TYPE=TYPE;
    data.onevector=onevector;
    data.X_design_full=X_design_full;
    data.apuvector=apuvector;
    data.all_fit_corr=all_fit_corr;
    data.perm_ind=perm_ind;
    data.saved_coeffs=saved_coeffs;
    data.X_design_pinv=X_design_pinv;
    data.glm_opts=glm_opts;
    
    parfor k=1:N_components
        tempres{k}=parallel_permutation_loop(data,k);
    end
    
    for k=1:N_components
        all_mean_null_dist{k} = tempres{k}.all_mean_null_dist;
        p_val_group(k)=tempres{k}.p_val_group;
    end
    
    clear data;
    clear tempres;
    
    matlabpool('close');
    
else
    
    k=0;
    for i=good_components
        
        k=k+1;
        
        fprintf('..component %i: ',i);
        null_dist = zeros(N_subjects,permutations);
        
        randcoeffs = randi(N_components,1,permutations);
        randphases = exp(1i*2*pi*rand(LL,permutations));
        
        kk=1;
        for j=1:permutations
            
            if kk<10 && j==perm_ind(kk)
                fprintf('%i..',kk*10);
                kk=kk+1;
            end
            
            for subj = 1:N_subjects
                
                coeffs = saved_coeffs{subj,randcoeffs(j)};
                
                ts = mix_phase([],coeffs,randphases(:,j));
                
                switch TYPE
                    case 1
                        [Xloadings,Yloadings,Xscores,Yscores,beta] = plsregress(X_design,ts,all_model_order(subj,k));
                        yfit = X_design_full*beta;
                    case 2
                        if LASSO_PERM_TYPE==1
                            ba = lasso(X_design,ts,'Alpha',cfg_file.alpha,'DFmax',all_model_order(subj,k));
                            chosen_feat = ba(:,1)~=0;
                            X_design_chosen = [onevector,X_design(:,chosen_feat)];
                        else
                            random_design = randsample(apuvector,all_model_order(subj,k),'false');
                            X_design_chosen = [onevector,X_design(:,random_design)];
                        end
                        beta = regress(ts,X_design_chosen);
                        yfit = X_design_chosen*beta;
                    case 3
                        beta=X_design_pinv*ts;
                        yfit = X_design_full*beta;
                    case 4
                        if LASSO_PERM_TYPE==1
                            glm_opts.pmax = all_model_order(subj,k);
                            fit = glmnet(X_design,ts,'gaussian',glm_opts);
                            chosen_feat = fit.beta(:,end)~=0;
                            X_design_chosen = [onevector,X_design(:,chosen_feat)];
                        else
                            random_design = randsample(apuvector,all_model_order(subj,k),'false');
                            X_design_chosen = [onevector,X_design(:,random_design)];
                        end
                        beta = regress(ts,X_design_chosen);
                        yfit = X_design_chosen*beta;
                end
                
                null_dist(subj,j) = oma_corr2(yfit,ts);
            end
            
        end
        
        null_dist_mean = mean(atanh(null_dist),1);
        val = mean(atanh(all_fit_corr(:,k)));
        
        a=nnz(null_dist_mean>val);
        p_val_group(k)=a/length(null_dist_mean);
        
        fprintf('done (pval %4.3f)\n',p_val_group(k));
        
        if max(null_dist(:))>0.99
            warning('Component %i has suspiciously large null-correlations!',good_components(k));
        end
        
        all_mean_null_dist{k}=mean((null_dist),1);
        
    end
    
end

a=toc;
fprintf('done! Elapsed time %s\n',sec2min(round(a)));
res.part2_time = a;

% k=0;
% for i=good_components
%     k=k+1;
%     p_val_component(k)=fisher_combine(all_p_val_component(:,k));
% end

alpha = 0.05;
significant_005 = good_components(find( (p_val_group<=FDR(p_val_group,alpha)))) % ...
                %& (p_val_component<=FDR(p_val_component,alpha)))
            
alpha = 0.01;
significant_001 = good_components(find( (p_val_group<=FDR(p_val_group,alpha)))) % ...
                %& (p_val_component<=FDR(p_val_component,alpha)))
            
alpha = 0.005;
significant_0005 = good_components(find( (p_val_group<=FDR(p_val_group,alpha)))) % ...
                %& (p_val_component<=FDR(p_val_component,alpha)))
            
alpha = 0.001;
significant_0001 = good_components(find( (p_val_group<=FDR(p_val_group,alpha)))) % ...
                %& (p_val_component<=FDR(p_val_component,alpha)))         
                
res.significant_005=significant_005;
res.significant_001=significant_001;
res.significant_0005=significant_0005;
res.significant_0001=significant_0001;
res.p_val = p_val_group;
res.all_model_order=all_model_order;
res.all_mean_null_dist=all_mean_null_dist;

save([cfg_file.filename,'_results'],'res','cfg_file');
                