function SPM_reslice(input_img,reference_img)
%SPM_RESLICE Summary of this function goes here
%   Detailed explanation goes here
load SPM_coregister_job.mat

if nargin<2
   reference_img =  '/scratch/braindata/kauttoj2/code/RSAtoolbox/Templates/MNI152_T1_2mm_brain.nii';
end

if iscell(input_img)
    
    for i=1:length(input_img)
        if i>1
            matlabbatch{i}=matlabbatch{i-1};
        end
        matlabbatch{i}.spm.spatial.coreg.write.source{1} = [input_img{i},',1'];
        matlabbatch{i}.spm.spatial.coreg.write.ref{1} = [reference_img,',1'];
    end
else
    
    matlabbatch{1}.spm.spatial.coreg.write.source{1} = [input_img,',1'];
    matlabbatch{1}.spm.spatial.coreg.write.ref{1} = [reference_img,',1'];
end

spm('defaults','fmri');
spm_jobman('initcfg');
spm_jobman('serial',matlabbatch);
