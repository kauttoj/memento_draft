function out = mni2ind(in)
%MNI2IND Summary of this function goes here
%   Detailed explanation goes here

T = [45,63,36] + [1,1,1];
T = repmat(T,[size(in,1),1]);

out = ceil(in/2 + T);

   
end

