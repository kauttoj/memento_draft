function plot_matrix_image(mat,tit)

colormapp = (autumn(256));
N_colors = size(colormapp,1);

mat = double(mat);

mat_zeros = (mat == 0 | isnan(mat));
val = mat(:);
val(val==0 | isnan(val))=[];
ma = max(val);
mi = min(val);


mat = mat - mi + 10*eps;
mat = ceil(N_colors*mat/(ma-mi))+1;
colorbar_min = mi;
colorbar_max = ma;

mat(mat_zeros)=1;
colormapp=[1,1,1;colormapp];

colorbar_ticks = round(linspace(1,N_colors,10));
a = linspace(colorbar_min,colorbar_max,10);
for i=1:length(a)
    colorbar_labels{i} = sprintf('%1.2f',a(i));
end

totalmap = colormapp;

figure('Position',[235         300        1005         794]);
image(mat);
if nargin==2
   title(tit);
end
axis square
colormap(totalmap);

if size(mat,1)>100
    a=round(linspace(1,(size(mat,1)),30));
    a=sort(unique(a),'ascend');
    set(gca,'YTick',a);
end
if size(mat,2)>100
    a=round(linspace(1,(size(mat,2)),30));
    a=sort(unique(a),'ascend');
    set(gca,'XTick',a);
end

grid on;

ax = axes('Position', [0.05 0.3 0.9 0.4], 'Visible', 'off');
h = colorbar('FontSize',12);
set(h, 'ylim',([1,N_colors]));
set(h, 'YTick',colorbar_ticks);
set(h,'YTickLabel',colorbar_labels);

end

