function [statmap,th] = my_glm(data,regressor,mask,correction,q)

if nargin<4
    do_correction = 0;
else
    do_correction = 1;
end

regressor = reshape(regressor,[length(regressor),1]);
X = [regressor,(1:length(regressor))'];

siz = size(data);
statmap.pval = ones(siz(1:3));
statmap.tval = zeros(siz(1:3));
pvals = ones(1,nnz(mask));

tic;
count = 0;
for x = 1:siz(1)
    disp(['x = ',num2str(x),'/',num2str(siz(1))]);
    for y = 1:siz(2)
        for z = 1:siz(3)
            if mask(x,y,z)>0
                count = count + 1;
                Y = squeeze(data(x,y,z,:));
                
                if sum(Y)==0
                    warning('Zero timeserie found (mask not working)');
                end
                
                Y = reshape(Y,[length(Y),1]);

                [B,DEV,STATS] = glmfit(X,Y,'normal');
                statmap.pval(x,y,z)=STATS.p(2);
                statmap.tval(x,y,z)=STATS.t(2);       
                pvals(count)=STATS.p(2);
            end
        end
    end
end

if do_correction
    disp('Computing FDR');    
    for i=1:length(q)       
        pID = fdr(pvals,q(i));
        th(i) = pID;
    end
else
    th = q;
end

a=toc;
disp(['Elapsed time ',num2str(a)])
        
        
function [pID, pN, p_masked] = fdr(pvals, q)

p = sort(pvals(:));
V = length(p);
I = (1:V)';

cVID = 1;
cVN = sum(1./(1:V));

pID = p(max(find(p<=I/V*q/cVID))); % standard FDR
pN =  p(max(find(p<=I/V*q/cVN)));  % non-parametric FDR (not used)
if isempty(pID), pID = 0; end;

if nargout > 1
    p_masked = pvals < pID;
end;
