function mat2nii(data)	

	img=data;
	nii = load_nii('MNI152_T1_2mm_brain_mask.nii');
	nii.img=img;
	nii.hdr.dime.bitpix=64;
	nii.hdr.dime.datatype=64;
	nii.hdr.dime.dim(1)=4;
	nii.hdr.dime.dim(5)=1;
	nii.hdr.dime	
	save_nii(nii,'image.nii');
    
    
    
    