function out = mat2cellstr( in )
%MAT2CELLSTR Summary of this function goes here
%   Detailed explanation goes here

    if ndims(in)>2
        warning('More than one dimension, result will be vectorized!');
    end
    in = in(:);
          
    for i=1:length(in)
        out{i}=num2str(in(i));
    end       


end

