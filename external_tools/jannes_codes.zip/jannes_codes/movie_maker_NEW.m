function handle = movie_maker_NEW(mat,kumpi,tit,volumetype,colormapp,range_limits)

% INPUT:
% mat = 3D activation map
% mask = 3D mask that lies under our activation map (optional)
% tit = title for image (optional)

% This function uses MNI 2mm anatomical image with dimensions 91x109x91

% Janne K, 2013


% path to templates (change these)
% if exist('/scratch/braindata/kauttoj2/working/templates/','dir')
%     templa = '/scratch/braindata/kauttoj2/working/templates/';
% elseif exist('triton/becs/scratch/braindata/kauttoj2/working/templates/','dir')
%     templa = 'triton/becs/scratch/braindata/kauttoj2/working/templates/';
% else
%     error('Cannot find templates');
% end

% [x,y,z]=ind2sub(size(mat),find(mat == max(mat(:))))
% mat(x,y,z) = 1000;

has_range = 1;
if nargin<6
    has_range = 0;
    if nargin<5        
        colormapp = (autumn(256));
        if nargin<4
            volumetype = 1;
            if nargin<3
                tit = '';
            end
        end
    end
end

T1_type = 1;

%hasmask=0;
% if nargin>1
%     if exist('mask','var') && ~isempty(mask)
%         hasmask=1;
%         if ~all(size(mat)==size(mask))
%             error('Image and mask must have same dimensions');
%         end
%     end
% end

%nii = load_nii('/scratch/braindata/kauttoj2/working/templates/MNI152_T1_2mm.nii');
factor = 1;
if volumetype == 1
    if T1_type==1
        
        load('MNI_T1_1mm');
        T1 = MNI_T1_1mm;%nii.img;
        
        %load('MNI_T1_1mm_mask');
        load('edge_slices_T1_1mm');
        %T1_mask = MNI_T1_1mm_mask;%nii.img;
        
        x_slicess = x_slice_1mm;
        y_slicess = y_slice_1mm;
        z_slicess = z_slice_1mm;
        
    else
        load('MNI_T1_2mm');
        T1 = MNI_T1_2mm;%nii.img;
        
        %load('MNI_T1_1mm_mask');
        load('edge_slices_T1_2mm');
        
        x_slicess = x_slice_2mm;
        y_slicess = y_slice_2mm;
        z_slicess = z_slice_2mm;
        
    end
    
    
    
    if ~all(size(mat)==size(T1))
        %error('Feature not yet available :)');
        
        s1 = size(mat);
        s2 = size(T1);
        
        a1 = s2(1)/s1(1);
        a2 = s2(2)/s1(2);
        a3 = s2(3)/s1(3);
        if abs(a1-a2) + abs(a2-a3) > 10*eps
           error('T1 image size must be a multiple of an activation image (only one scale factor)');
        end
        a = abs(round(a1)-a1);
        if a > 100*eps
            warning('Using image interpolation (scale factor NOT an integer)');
        end
        
        if a < 1e-12
            factor = round(a1);
        else
            factor = a1;
        end
        
    end
    
end



%B = imresize(A, scale)


    
    N_colors = size(colormapp,1);
    N_graycolors = 2^13;
    graymap = (gray(N_graycolors));
    T1 = double(T1);
    mi=min(T1(:));
    ma=max(T1(:));
    T1 = T1 - mi + 10*eps;
    T1 = ceil(N_graycolors*T1/(ma-mi));
    
    mat = double(mat);
    
    mat_zeros = (mat == 0 | isnan(mat));
    val = mat(:);
    val(val==0 | isnan(val))=[];
    ma = max(val);
    mi = min(val);
    
    
    if has_range
        if  ~isempty(val) && (mi<range_limits(1) || ma>range_limits(2))
            error('Outside range!');
        end
        mat = mat - range_limits(1) + 10*eps;
        mat = ceil(range_limits(2)*N_colors*mat/(range_limits(2)-range_limits(1))) + N_graycolors;
        mat(mat_zeros)=0;
        colorbar_min = range_limits(1);
        colorbar_max = range_limits(2);        
    else
        mat = mat - mi + 10*eps;
        mat = ceil(N_colors*mat/(ma-mi)) + N_graycolors;
        mat(mat_zeros)=0;
        colorbar_min = mi;
        colorbar_max = ma;
    end
    
    colorbar_ticks = round(linspace(N_graycolors+1,N_graycolors + N_colors,10));
    a = linspace(colorbar_min,colorbar_max,10);
    for i=1:length(a)
        colorbar_labels{i} = sprintf('%1.2f',a(i));
    end
    
    totalmap = [graymap;colormapp];
    
    
    z_min = 27/91;
    z_max = 72/91;
    NSlices = 16;
    
    Z_mat = round(linspace(z_min,z_max,NSlices)*size(mat,3));
    
    %Z_mat(5) = 39;
    
    Z_T1 = round(Z_mat*factor);%round(linspace(z_min,z_max,NSlices)*size(T1,3));
        
    rows = 4;%ceil(sqrt(NSlices));
    cols = 4;%ceil(sqrt(NSlices));
        
    X = 30;                  %# A3 paper size
    Y = 30;                  %# A3 paper size
    xMargin = 1;               %# left/right margins from page borders
    yMargin = 1;               %# bottom/top margins from page borders
    xSize = X - 2*xMargin;     %# figure size on paper (widht & hieght)
    ySize = Y - 2*yMargin;     %# figure size on paper (widht & hieght)
    
    handle = figure('Units','centimeters', 'Position',[5 5 xSize ySize]/2,'Name',tit,'visible','off','Menubar','none'); % 'Position',[20,20,1150,900]
    
    set(gcf, 'PaperUnits','centimeters')
    set(gcf, 'PaperSize',[X Y])
    set(gcf, 'PaperPosition',[xMargin yMargin xSize ySize])
    set(gcf, 'PaperOrientation','portrait')
    
set(handle, 'PaperPositionMode', 'auto');
%set(handle, 'PaperType', 'A4');



% T1_x  = 1-single(squeeze(sum(T1_mask,1))>0);
% T1_y = 1-single(squeeze(sum(T1_mask,2))>0);
% T1_z = 1-single(squeeze(sum(T1_mask,3))>0);

% T1_x = squeeze(T1(ceil(size(T1,1)/2)+3,:,:));
% T1_y = squeeze(T1(:,ceil(size(T1,2)/2)-3,:));
% T1_z = squeeze(T1(:,:,ceil(size(T1,3)/2)-5));



%if ~(length(unique(mat(:)))==2)
    
% create AVI object
vidObj = VideoWriter('myvideo.avi');
vidObj.Quality = 100;
vidObj.FrameRate = 5;
vidObj.VideoCompressionMethod = 'H.264';
open(vidObj);


        
        annotation('textbox',[0.1 0.94 0.8 0.05],'string',tit,'FontSize',12,'HorizontalAlignment','center','VerticalAlignment','middle','EdgeColor','none')        
                
        for i=1:NSlices
            
            %disp(['slice ' num2str(i) '/' num2str(NSlices)]);
            
            custom_subplot(rows,cols,i);
            
            image1 = squeeze(T1(:,:,Z_T1(i)));           
            image2 = squeeze(mat(:,:,Z_mat(i)));
            
            image2 = imresize(image2,size(image1),'nearest');
            ind = image2>0;
            image1(ind) = image2(ind);
            
            imshow(image1,totalmap, 'InitialMagnification','fit');
            
            title(['z = ',num2str(Z_mat(i)),'/',num2str(size(mat,3))],'FontSize',9);%' (',num2str(aa),')']);
            set(gca,'YTick',[]);
            set(gca,'XTick',[]);
            box on;
        end
        
        %ax = axes('Position', [0.05 0.3 0.9 0.4], 'Visible', 'off');
        %h = colorbar('FontSize',12);
        %set(h, 'ylim',(N_graycolors + [1,N_colors]));
        %set(h, 'YTick',colorbar_ticks);
        %set(h,'YTickLabel',colorbar_labels);
       
    
%     
% else
%     
%     %a = sort(unique(mat(:)));
%             annotation('textbox',[0.1 0.94 0.8 0.05],'string',tit,'FontSize',14,'HorizontalAlignment','center','VerticalAlignment','middle','EdgeColor','none')
%  
%     
%     for i=1:NSlices
%         
%         disp(['Plotting mask slice ' num2str(i) '/' num2str(NSlices)]);
%         
%         custom_subplot(rows,cols,i);
%         mat_slice = (squeeze(mat(:,:,Z_mat(i))));
%         if volumetype == 1
%             T1_slice = (mat2gray((squeeze(T1(:,:,Z_T1(i))))));        
%             img = imoverlay(T1_slice,upsample(mat_slice,factor),[1 0 0]);
%             imshow(img, 'InitialMagnification', 'fit');
%         else
%             imshow(upsample(img,factor), 'InitialMagnification', 'fit');
%         end
%                 
%         title(['z = ',num2str(Z_mat(i)),'/',num2str(size(mat,3))]);
%             set(gca,'YTick',[]);
%             set(gca,'XTick',[]);        
%         freezeColors;
%         box on;
%         
%     end
%     
%     %     val = mat(:);
%     %     val(val==0)=[];
%     
% end

% scale_subplots(1.12,[-0.05,-0.05])
%
% figure;
% plot(sort(val));
% xlabel('value number');
% ylabel('Z-score');
% axis tight;

