function [res,handle] = my_MVPA(data,tit,permutations,threshold)
%MY_MVPA Summary of this function goes here
%   Detailed explanation goes here

subjects = length(data);
T = size(data{1},2);
L = size(data{1},1);
multiplier = 1;

%comparison_method = 'Pearson';
%comparison_method = 'Euclidean';
comparison_method = 'Custom';
fun = @(kuva1,kuva2) sum((kuva1-kuva2).^2);



fprintf('Data has %i subjects, %i timeseries (features), %i volumes (timepoints)\n',subjects,L,T);

% dispind = round(linspace(permutations/10,permutations,10));
% kk=1;
% for perm = 1:permutations
%     if kk<11 && perm==dispind(kk)
%         fprintf('perm %i/%i\n',kk,10);
%         kk=kk+1;
%     end
%     ind1 = randperm(L);
%     %ind2 = randperm(L);
%     s = randi(subjects);
%     i = randi(T);
%     j = 4+randi(T-5);
%     j = 1 + mod(i+j,T);
%     permdist(perm) = multiplier*oma_corr2(data{s}(ind1,i),data{s}(:,j));%/sum((data(ind1,i)-data(ind2,j)).^2);
% end

disp('Computing subjectwise similarity maps');

indlist = [];
indmap = zeros(T,T);
for s=1:subjects
    corrmap{s} = zeros(T,T);
    fprintf('Subject %i\n',s);
    for i=5:(T-5)
        for j=(i+5):(T-5)
            kuva1 = data{s}(:,i);
            kuva2 = data{s}(:,j);            
            kuva1 = zscore(kuva1(:));
            kuva2 = zscore(kuva2(:));
            
            corrmap{s}(i,j)=fun(kuva1,kuva2);%oma_corr2(kuva1,kuva2);%/sum((data(:,i)-data(:,j)).^2);
            if s==1
                indmap(i,j)=1;
            end
        end
    end
    res.first_level{s}=corrmap;
end

[x,y]=ind2sub(size(indmap),find(indmap));
indlist = [x,y];
matsize = size(indlist,1);

corrmap_total = zeros(size(corrmap{1}));

for s=1:subjects
        
    corrmap_total =  corrmap_total + corrmap{s};
    
end
corrmap_total = corrmap_total/subjects;

disp('Computing permutations');
pause(eps);
permdist = zeros(1,permutations);
dispind = round(linspace(permutations/10,permutations,10));
kk=1;
for perm = 1:permutations
    if kk<11 && perm==dispind(kk)
        fprintf('%i...',kk*10);
        kk=kk+1;
    end
    a = 0;
    for s=1:subjects
        b = indlist(randi(matsize),:);
        a = a + corrmap{s}(b(1),b(2));
    end
    permdist(perm) = a/subjects;
end
fprintf('done \n');

res.perm_distribution=permdist;

pause(eps);

vals = corrmap_total(indmap~=0);

if strcmp(comparison_method,'Pearson')
    if max(vals)>=1 || min(vals)<=-1 || max(permdist>=1) || min(permdist)<=-1
        error('Pearson correlation out of bounds!');
    end
    permdist = atanh(permdist);
    vals = atanh(vals);
end

%[pvals,TH]=compute_pvalues(vals,atanh(permdist),'right');

[TH_kauppi,TH_info]=compute_pvals_kauppi(permdist,vals);    

if TH_kauppi(11)>0 %&& nnz(extentThreshold(apu>TH_kauppi(11),4))>0
    threshold = TH_kauppi(11);
    threshold_str = [', p<0.001 (fdr)'];
elseif TH_kauppi(7)>0 %&& nnz(extentThreshold(apu>TH_kauppi(7),4))>0
    threshold = TH_kauppi(7);
   threshold_str = [', p<0.005 (fdr)'];    
elseif TH_kauppi(3)>0 %&& nnz(extentThreshold(apu>TH_kauppi(3),4))>0
    threshold = TH_kauppi(3);    
   threshold_str = [', p<0.05 (fdr)'];    
elseif TH_kauppi(9)>0 %&& nnz(extentThreshold(apu>TH_kauppi(9),4))>0
   threshold = TH_kauppi(9);
   threshold_str = [', p<0.001'];    
elseif TH_kauppi(5)>0 %&& nnz(extentThreshold(apu>TH_kauppi(5),4))>0
    threshold = TH_kauppi(5);    
   threshold_str = [', p<0.005'];    
else
    error('No significant tiles in similarity map!')
end

corrmap_total(corrmap_total<threshold)=0;

fprintf('Total %i significant elements found\n',nnz(corrmap_total));
%corrmap_total = extentThreshold(corrmap_total,4);

%ind = (corrmap_total==0);
%corrmap = atanh(corrmap);
%corrmap_total(ind)=0;

colormapp = (autumn(256));
N_colors = size(colormapp,1);
mat = corrmap_total;
mat_zeros = (mat == 0 | isnan(mat));
val = mat(:);
val(val==0 | isnan(val))=[];
ma = max(val);
mi = min(val);
mat = mat - mi + 10*eps;
mat = ceil(N_colors*mat/(ma-mi) - eps);
mat(mat_zeros)=0;
colorbar_min = mi;
colorbar_max = ma;

colorbar_ticks = round(linspace(1,N_colors,10));
a = linspace(colorbar_min,colorbar_max,10);
for i=1:length(a)
    colorbar_labels{i} = sprintf('%1.2f',a(i));
end

totalmap = [1,1,1;colormapp;0,1,0];

a=sort(corrmap_total(:),'Descend');
a=a(1:10);
a(a==0)=[];
disp('Maximum points:');
for i=1:length(a)
    j=find(corrmap_total==a(i));
    [x,y]=ind2sub(size(corrmap_total),j);
    mat(j)=N_colors+2;
    fprintf('(%i, %i) ... %f\n',x,y,a(i));
end

handle = figure;
annotation('textbox',[0.1 0.94 0.8 0.05],'string',[tit,threshold_str],'FontSize',14,'HorizontalAlignment','center','VerticalAlignment','middle','EdgeColor','none')

image1 = mat;

imshow(image1,totalmap, 'InitialMagnification','fit');

%title(['z = ',num2str(Z_mat(i)),'/',num2str(size(mat,3))]);%' (',num2str(aa),')']);
%set(gca,'YTick',[]);
%set(gca,'XTick',[]);
box on;

xlabel('Timepoint')
grid on
ylabel('Timepoint')
box on;

% ax = axes('Position', [0.05 0.3 0.9 0.4], 'Visible', 'off');
% h = colorbar('FontSize',12);
% set(h, 'ylim',(1 + [1,N_colors]));
% set(h, 'YTick',colorbar_ticks);
% set(h,'YTickLabel',colorbar_labels);

[x,y]=ind2sub(size(corrmap_total),find(corrmap_total));
[a,b]=hist([x;y],unique([x,y]));
[a,c]=sort(a,'Descend');
b=b(c);

disp('Most frequent timepoints:');
for i=1:min(length(a),10)
   fprintf('%i (%i times)\n',b(i),a(i));
end

%figure;

end

