function save_nii_oma(mat,name,type,nii)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
home = pwd;

if strcmp(home(1:8),'/triton/')
    pre = '/triton/becs';
else
    pre = '';
end


a = [pre,'/scratch/braindata/shared/HarvardOxford/'];
koko = size(mat);
if nargin<4
    if all(koko(1:3)==[91,109,91])
        nii = load_nii([a,'MNI152_T1_2mm_brain.nii']);
    elseif all(koko(1:3)==[182,218,182])
        nii = load_nii([a,'MNI152_T1_1mm_brain.nii']);
    else
        error('Tuntematon koko!');
    end
end

if nargin < 3
	nii.hdr.dime.bitpix=64;
	nii.hdr.dime.datatype=64;
	nii.img = double(mat);
else
	if strcmp(type,'single')
		nii.hdr.dime.bitpix=16;
		nii.hdr.dime.datatype=16;
		nii.img = single(mat);
	elseif strcmp(type,'double')
		nii.hdr.dime.bitpix=64;
		nii.hdr.dime.datatype=64;
		nii.img = double(mat);
	else
		error('unknown datatype')
	end
end

ma = max(max(mat(:)));
mi = min(min(mat(:)));
if isnan(ma)
    ma=1000;
end
if isnan(mi)
    mi=0;
end
if mi>=ma
    mi=0;
    ma=1000;
end

nii.hdr.dime.cal_max=ma;
nii.hdr.dime.cal_min=mi;

if length(koko)==4
    nii.hdr.dime.dim(1)=4;
	nii.hdr.dime.dim(5)=koko(4);
    save_nii(nii,name);
else
    save_nii(nii,name);
end

end

