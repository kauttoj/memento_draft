function oma_legend(data)

str = [];

for i=1:length(data)
    str{i}=num2str(data(i));
end

legend(str,'Location','best');

end