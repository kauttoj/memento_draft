function save_nii_oma_SPM(mat,name)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
home = pwd;

koko = size(mat);
if length(koko)~=3 || ~all(koko(1:3)==[91,109,91])
    error('Must have dim=[91,109,91], 4D not supported!');
end

[SPMversion,template] = checkSPMversion();
if SPMversion==0
    error('SPM not found (must be 8 or 12)!')
end

mat = single(mat(91:-1:1,:,:));

old_head = spm_vol(template);
new_head=old_head;
new_head = rmfield(new_head,'pinfo');
new_head.fname = [home,filesep,name];
new_head.private.dat.fname = [home,filesep,name];
spm_write_vol(new_head,mat);

end

function [SPMversion,template] = checkSPMversion()

SPMversion = 0;
if exist('spm.m')
    SPMpath = fileparts(which('spm.m'));    
    SPMversion=spm('Ver');
    if strcmp('SPM8',SPMversion)
        fprintf('Detected SPM version is 8\n');
        SPMversion = 8;
        template = [SPMpath,filesep,'templates',filesep,'EPI.nii'];
    elseif strcmp('SPM12',SPMversion)
        fprintf('Detected SPM version is 12\n');
        SPMversion = 12;
        template = [SPMpath,filesep,'toolbox',filesep,'OldNorm',filesep,'EPI.nii'];
    end                
end

end
