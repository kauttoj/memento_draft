function timeseries_corrected = timeseries_preprocessor(timeseries,regressors,detrend_type,motion_reg_type,filtertype,filter_limits,TR)
%TIMESERIES_PREPROCESSOR Summary of this function goes here
%   Detailed explanation goes here

%timeseries = N_session x N_sub x N_comp X T
addpath('/triton/becs/scratch/braindata/kauttoj2/code/bramila_git/latest_bramila');
addpath('/triton/becs/scratch/braindata/kauttoj2/code/GIFT3.0/icatb_helper_functions')

N_ses = size(timeseries,1);
N_sub = size(timeseries,2);
N_comp = length(timeseries{1,1});

fprintf('Timeseries contains %i sessions, %i subjects and %i components\n',N_ses,N_sub,N_comp);

for ses = 1:N_ses
    for sub=1:N_sub
        for comp=1:N_comp
            
            ts = double(timeseries{ses,sub}{comp});
            
            clear cfg;
            cfg.TR=TR;
            cfg.detrend_type=detrend_type; % must be the same as applied to BOLD data
            cfg.write=0;
            cfg.vol=ts;
            ts = bramila_detrend(cfg);
            
            clear cfg;
            cfg.TR = TR;
            cfg.motionparam=regressors{ses,sub};
            %cfg.volumes_to_use = 1:T;
            cfg.write=0;
            cfg.prepro_suite = 'SPM';
            cfg.mot_derivatives=0;
            cfg.motion_reg_type=motion_reg_type;
            cfg.detrend_type =detrend_type;% 'polynomial-nodemean';
            cfg.filtertype = filtertype; % SPMhp
            cfg.filter_limits = filter_limits; % [0,0.008,1,1]
            
            reg_cfg = bramila_makemotionregress(cfg);
            X = [ones(size(reg_cfg.reg,1),1),reg_cfg.reg];
            
            ts_new = zeros(size(ts));
            for j=1:size(ts,2)
                [~,~,ts_new(:,j)] = regress(ts(:,j),X);
            end
            
            fprintf('\n\n---Ses %i, Sub %i, Comp %i: reduced mean variance by %3.1f%%\n',ses,sub,comp,100*(1-sum(var(ts_new))/sum(var(ts))));
            
            cfg.tsdata = ts_new';
            cfg.mask = true(1,size(cfg.tsdata,1));
            new_cfg = bramila_filter(cfg);
            ts_new = new_cfg.vol';
            
            timeseries{ses,sub}{comp} = ts_new;
            
        end
    end
end

timeseries_corrected = timeseries;

end

