function [mask,my_ROI] = give_searchlight(centroid,RADIUS)
%GIVE_SEARCHLIGHT Summary of this function goes here
%   Detailed explanation goes here

mask = zeros(91,109,91);

xx = centroid(1);
yy = centroid(2);
zz = centroid(3);

RADIUS = RADIUS/2;
RADIUS=RADIUS+eps;
a = ceil(RADIUS + 1);

k=0;
my_ROI = [];
for x=[-a:a],
    for y=[-a:a],
        for z=[-a:a],
            if norm([x,y,z])<=RADIUS
                k=k+1;
                my_ROI(k,1)=x;
                my_ROI(k,2)=y;
                my_ROI(k,3)=z;
                mask(xx+x,yy+y,zz+z)=k;
            end
        end
    end
end
N_roi = size(my_ROI,1);
fprintf('Your searchlight has %i voxels\n',N_roi);


end

