function str = simplify_my_label(str)
%SIMPLIFY_MY_LABEL Summary of this function goes here
%   Detailed explanation goes here


    str=strrep(str,'Left','L');
    str=strrep(str,'Right','R');
    str=strrep(str,'Inferior','Inf.');
    str=strrep(str,'Superior','Sup.');
    str=strrep(str,'Lateral','lat.');
    str=strrep(str,'division','div.');
    str=strrep(str,'anterior','ant.');
    str=strrep(str,'posterior','post.');
    str=strrep(str,' (formerly Supplementary Motor Cortex)','');
    str=strrep(str,'temporooccipital part','temp.-occ.');    

end

