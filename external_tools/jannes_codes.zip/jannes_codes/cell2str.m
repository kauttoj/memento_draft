function str = cell2str(cellstr)
%CELL2STR Summary of this function goes here
%   Detailed explanation goes here
str = [];
for i=1:length(cellstr)   
    if ~ischar(cellstr{i})
        error('Input cell includes non-string data!')
    end
    if i>1
    	str = [str,' ',cellstr{i}];
    else
        str = cellstr{i};
    end
end

end

