function makemovie_lite(datafile,times,type,filename)



T = length(times);

passed = 0;
for k=1:T          
    mat = load_nii([datafile,'.nii'],k);
    mat = mat.img;
    val = mat(:);
    val(val==0 | isnan(val))=[];
    if isempty(val)
        ma(k) = -inf;
        mi(k) = inf;
    else
        passed = 1;
        ma(k) = max(val);
        mi(k) = min(val);
    end
end

[total_mi,ind_mi]=min(mi);
[total_ma,ind_ma]=max(ma);

fprintf('Mimimum: %f (frame %i), Maximum: %f (frame %i)\n',total_mi,ind_mi,total_ma,ind_ma);

range = [total_mi,total_ma];

if passed
    
    writerObj = VideoWriter(filename,'Motion JPEG AVI');
writerObj.FrameRate = 5;
writerObj.Quality = 100;

dt = times(1);

open(writerObj);
for k=1:T    
    fprintf('frame %i/%i\n',k,T);
    aika = times(k);    
    mat = load_nii([datafile,'.nii'],k);
    mat = mat.img;    
    a = squeeze(mat);
    s = sprintf('Frame %3i, %4.0f (s), %s --> %s (min), %5i activations',k,aika,sec2min(max(0,aika-dt-5)),sec2min(max(0,aika+dt-5)),nnz(a));
    handle = volume_plotter5_inv(a,type,s,1,autumn(256),range);
    print(handle,'tempframe','-dbmp');
    a = imread('tempframe.bmp');
    writeVideo(writerObj,im2frame(a));
    close(handle);
end
close(writerObj);
else
   warning('No values to plot, quitting');
end