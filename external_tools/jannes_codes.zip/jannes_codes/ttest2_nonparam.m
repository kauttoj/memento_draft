function [res,pval] = ttest2_nonparam(sample1,sample2,iter,alpha,suunta)
%TTEST2_NONPARAM Summary of this function goes here
%   Detailed explanation goes here

n=length(sample1);
m=length(sample2);
N=n+m;

data = [sample1(:);sample2(:)];
delta = mean(data(1:n)) - mean(data((n+1):end));

iter = max(1000,iter);
delta_dist = zeros(1,iter);

for i=1:iter
    
    perm_data = data(randperm(N));
    delta_dist(i) = mean(perm_data(1:n)) - mean(perm_data((n+1):end));
    
end


if nargin<5
    
    left = prctile(delta_dist,(alpha/2)*100);
    right = prctile(delta_dist,(1-(alpha/2))*100);
    
    if delta < left || delta > right
        res = 1;
    else
        res = 0;
    end
    
    pval = 1-nnz(abs(delta)>abs(delta_dist))/iter;
    
else
    
    if delta<0 && strcmp(suunta,'positive')
        suunta = 'negative';
        warning('Changing tail direction!')
    end
    
    if delta>0 && strcmp(suunta,'negative')
        suunta = 'positive';
        warning('Changing tail direction!')
    end
    
    if strcmp(suunta,'both')
        
        left = prctile(delta_dist,(alpha/2)*100);
        right = prctile(delta_dist,(1-(alpha/2))*100);
        
        if delta < left || delta > right
            res = 1;
        else
            res = 0;
        end        
        
        pval = 1-nnz(abs(delta)>abs(delta_dist))/iter;
        
    elseif strcmp(suunta,'positive')
        
        right = prctile(delta_dist,(1-(alpha))*100);
        
        if delta > right
            res = 1;
        else
            res = 0;
        end        
        
        pval = 1 - nnz(delta>delta_dist)/iter;
        
    elseif strcmp(suunta,'negative')
        
        left = prctile(delta_dist,(alpha)*100);
        
        if delta < left
            res = 1;
        else
            res = 0;
        end
        
        pval = 1 - nnz(delta<delta_dist)/iter;
        
    else
        error('unknown tail information!')
    end
        
end

end

