function all_data = check_quantiz_mod(max_img)

disp('Run this file at ''FunImg'' folder');
% loads a 4D volume from a raw nii and compute the number of bits needed
% for each voxel
% input is a string with filename
d = dir();

all_data=[];

k=0;

%nii=load_untouch_nii(niifile);
for i=1:length(d)
    if d(i).isdir && ~strcmp(d(i).name,'..') && ~strcmp(d(i).name,'.')
        cd(d(i).name);
        if nargin>0 && max_img>0
            img = load_img_data(max_img,1);
        else
            img = load_img_data(-1,1);
        end
                
        %img=nii.img;
        kk=size(img);
        
        data=reshape(img,[],kk(4)); % every row is a voxel
        data=data';
        fprintf('%s: %i voxels\n',d(i).name,size(data,2));
        u=zeros(size(data,2),1);
        for v=1:size(data,2)   % we have to go through each voxel
            temp=length(unique(data(:,v)));
            u(v,1)=log2(temp);
        end
        
        cd ..
        
        save_nii(make_nii(reshape(u,kk(1:3))),[d(i).name,'.nii']);
        
        k=k+1;
        all_data{k,1}=u;
        all_data{k,2}=d(i).name;
                
    end
end