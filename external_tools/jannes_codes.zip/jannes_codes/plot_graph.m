function plot_graph(values,edges,nodenames,tit)

figure;
nvar = length(nodenames);

% plot nodes
set(gca,'XTickLabel',[]);
anglee = (2*pi)/nvar;
X = zeros(nvar,1); Y = zeros(nvar,1);
for i=1:nvar
    X(i) = cos(anglee*(i-1));
    Y(i) = sin(anglee*(i-1));
    ang(i) = angle(X(i)+1i*Y(i));
end
for i=1:nvar
    h=plot(X(i),Y(i),'o');
    set(h,'Color','k');
    set(h,'MarkerSize',10);
    hold on;
end
XX=X*1.1;
YY=Y*1.1;

% find reciprocal edges
N=size(edges,1);
frominx=edges(:,1);
toinx=edges(:,2);

ind = find(values);
values(ind) = values(ind) - min(values(ind))+eps;
values(ind) = 5*values(ind)/max(values(ind));

for i=1:N,
    if (values(i)>0)
        xf = X(frominx(i)); yf = Y(frominx(i));
        xt = X(toinx(i)); yt = Y(toinx(i));
        h = line([xf xt],[yf yt]);
        set(h,'LineWidth',values(i));
        set(h,'Color',[0 0 0]); % red for reciprocal edge   
    end
end
% label nodes
for i=1:nvar
    if abs(ang(i)) > pi/2
        h=text(XX(i)-0.15,YY(i),[num2str(nodenames(i)),' (',num2str(i),')']);
    else
        h=text(XX(i),YY(i),[num2str(nodenames(i)),' (',num2str(i),')']);
    end
    set(h,'FontSize',12);
end


set(gca,'Box','off');
axis('square');
axis off;

str = [sprintf('Total %i edges (maximum %i)',length(ind),N),', ',tit];
title(str,'FontSize',12);

xlim([-1.4 1.4]);
ylim([-1.4 1.4]);

% This file is part of GCCAtoolbox.  
% It is Copyright (C) Anil Seth (2005-2009) 
% 
% GCCAtoolbox is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
% 
% GCCAtoolbox is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
% 
% You should have received a copy of the GNU General Public License
% along with GCCAtoolbox.  If not, see <http://www.gnu.org/licenses/>.