function [pID,pN] = fdr_kauppi(p,q,do_plot)

if nargin<3
    do_plot=0;
end

p = sort(p(:));
V = length(p); 
I = (1:V)';
cVID = 1;
cVN = sum(1./(1:V));

if do_plot==1
   figure;hold on;
   p(p==0)=eps;
   plot(1:length(p),p,'b.-');
   plot(1:length(p),I/V*q/cVID,'r');
   plot(1:length(p),I/V*q/cVN,'g');
   plot(1:length(p),ones(1,length(p))*0.05/length(p),'k');
   axis tight;
   box on;
   xlabel('p-val index')
   ylabel('p-val')
   legend('p-vals','FDR (original)','FDR (non-param)','Bonf.','Location','best')
   set(gca,'XScale','log','YScale','log');
   title('P-value analysis (q=0.05)')   
end

pID = p(max(find(p<=I/V*q/cVID)));
pN = p(max(find(p<=I/V*q/cVN)));

if isempty(pID)
  pID = NaN;
end
if isempty(pN)
  pN = NaN;
end

end

