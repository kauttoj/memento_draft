function p_vals = compute_pvals_custom(nulldist,vals)
%ESTIMATE_TAIL_PVAL Summary of this function goes here
%   Detailed explanation goes here       
    
    nulldist=sort(nulldist,'ascend');
    
    p_vals = -ones(size(vals));    
    cut05 = prctile(nulldist,95);
    cut01 = prctile(nulldist,99);
    p_vals(vals<cut05)=1;
    
    L=length(nulldist);
    
    ind = find(vals>=cut05 & vals<cut01);
    for i=ind
       p_vals(i)=nnz(nulldist>=vals(i))/L; 
    end
        
    taildist = nulldist(nulldist>=cut01);
    
    paramEsts = gpfit(taildist);
    kHat      = paramEsts(1);   % Tail index parameter
    sigmaHat  = paramEsts(2);   % Scale parameter
    
    ygrid = linspace(min(taildist),1.1*max(taildist),5000);
    tail = gppdf(ygrid,kHat,sigmaHat);
    
    tail = 

end

