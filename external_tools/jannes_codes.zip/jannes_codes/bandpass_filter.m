function [new_data,b] = bandpass_filter( data,TR )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

Fs=1/TR;

f = 5;
%% FILTER BANDS // In Hertz

bs{1}=[0 0.01 0.027 0.036];         % slow 5
bs{2}=[0.02 0.027 0.073 0.08];      % slow 4!!!!
bs{3}=[0.06 0.073 0.198 0.21];      % slow 3
bs{4}=[0.19 0.198];                 % slow 2
bs{5}=[0.01,0.025,0.1,0.12];		    % tyypillinen alue connectivity-analyyseissä (etenkin resting state)

As{1}=[0 1 0];
As{2}=[0 1 0];
As{3}=[0 1 0];
As{4}=[0 1];
As{5}=[0 1 0];

DEVs{1}=[0.05 0.05 0.05];
DEVs{2}=[0.05 0.05 0.05];
DEVs{3}=[0.05 0.05 0.05];
DEVs{4}=[0.05 0.05];
DEVs{5}=[0.05 0.02 0.05];


    % make the filter
    [N,Fo,Ao,W] = firpmord(bs{f},As{f},DEVs{f},Fs);

%     NyqF = (1/TR)/2;
%     WnH = (0*bs{f}(4)+2*bs{f}(3)) / (2*NyqF);
%     WnL = (2*bs{f}(2)+0*bs{f}(1)) / (2*NyqF);
%     %[bb, aa] = butter(5, [WnL,WnH],'bandpass');
%     
%     [z, p, k] = butter(5,[WnL,WnH],'bandpass');
%     [sos,g]=zp2sos(z,p,k);
%     h2=dfilt.df2sos(sos,g);              
%     
%     %out1(:,f)=filtfilt(b,a,x);
%     out1(:,f)=filtfilt(sos,g,x);
    
    if(mod(N,2)==1)
        N=N+1;  % it has to be even -> b is odd -> delay is integer = N/2
    end

    b=firpm(N,Fo,Ao,W);
    
    fprintf('FIR filter band [%f,%f,%f,%f] and order %i\n',bs{f}(1),bs{f}(2),bs{f}(3),bs{f}(4),N);
    
    %freqz(b,1,1024);hold on;
    %h3=dfilt.df2(b,1);
    %hfvt=fvtool(h2,h3,'FrequencyScale','linear');
    
if iscell(data)
    
    for k=1:length(data)
        N = size(data{k},1);
        L = size(data{k},2);
        fprintf('data set %i: %i signals with duration %i\n',k,N,L);
        new_data{k} = zeros(size(data{k}));    
        
        for kk=1:N
            y = data{k}(kk,:);
            new_data{k}(kk,:) = filtfilt(b,1,y);
        end
    end

else
    
    N = size(data,1);
    L = size(data,2);
    new_data = zeros(size(data));
    fprintf('data set has %i signals with duration %i\n',N,L);
    
    for k=1:N
        y = data(k,:);                
        new_data(k,:) = filtfilt(b,1,y);        
    end
end

