function [pulse_ttime,data,ispulse] = read_log_file(filename)
%READ_LOG_FILE Summary of this function goes here
%   Detailed explanation goes here

fid = fopen(filename);
data = textscan(fid, '%s', 'Delimiter', '\n');
if all(size(data) == [1,1])
    data=data{1};
end

header = strsplit(data{4},'\t');
data = data(6:end);
    
stimulus_str{1} = 'FAILED TO PARSE';
k=0;
empty_lines=[];
for i=1:length(data)
   if strcmp(data{i},'')
       empty_lines(end+1)=i;
   end
   
   if length(data{i})>6 && strcmp(data{i}(1:6),'video:')
      k=k+1;
      stimulus_str{k} =  data{i}(7:end);
   end
end

for i=1:k
    fprintf('STIMULUS %i: %s\n',i,stimulus_str{i});
end
fprintf('\n');

data = data(1:(empty_lines(1)-1));
L=length(data);

type = zeros(1,L);
ispulse = type;
ttime = -ones(1,L);
maxcol = -1;
fprintf('Non-pulse log-entries:\n');
for i=1:L
    line=data{i};
    full_line = line;
    line = strsplit(line,'\t');
    if i==1
       id = line{1}; 
    else
       if ~strcmp(line{1},id)
          line
          error('ID mismatch') 
       end
    end
    maxcol = max(maxcol,length(line));
    type(i)=str2double(line{2});
    ttime(i)=str2double(line{6});
    if strcmp(line{3},'Pulse')
        ispulse(i) = 1;       
    else
       fprintf('line %i: %s\n',i,data{i});
    end       
    
end
header = header(1:maxcol);
s=[];
for i=1:length(header)
    s = [s,' (',num2str(i),') ',header{i}];
end

k = find(diff(ttime(ispulse>0))<0);
if ~isempty(k)
    fprintf('\nNegative TTIME (discontinuity) with volumes:\n');
    for i=(k+1)
        fprintf('.. %i\n',i)
    end
    fprintf('\n');
end

fprintf('Headers: %s\n',s);
fprintf('------- Logfile has %i volumes --------\n',nnz(ispulse));

pulse_ttime = ttime;
pulse_ttime(ispulse==0)=[];

end

